package com.vethos.app.ui

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Typeface
import android.os.Bundle
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.io.File

/** Shown instead of the app after a crash, so the error can be read/copied on the phone. Plain framework views only. */
class CrashActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val f = File(filesDir, "crash.txt")
        val report = try { if (f.exists()) f.readText() else "(no crash report)" } catch (e: Throwable) { e.toString() }
        val pad = (16 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(pad, pad, pad, pad) }
        root.addView(TextView(this).apply { this.text = "Vethos crashed last time"; textSize = 20f; typeface = Typeface.DEFAULT_BOLD })
        val body = TextView(this).apply { this.text = report; textSize = 11f; typeface = Typeface.MONOSPACE; setTextIsSelectable(true) }
        root.addView(ScrollView(this).apply { addView(body) }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        root.addView(Button(this).apply {
            this.text = "Copy error"
            setOnClickListener {
                (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("Vethos crash", report))
            }
        })
        root.addView(Button(this).apply {
            this.text = "Clear and open app"
            setOnClickListener {
                f.delete()
                startActivity(Intent(this@CrashActivity, MainActivity::class.java))
                finish()
            }
        })
        setContentView(root)
    }

    companion object {
        fun pending(c: Context) = File(c.filesDir, "crash.txt").exists()
    }
}
