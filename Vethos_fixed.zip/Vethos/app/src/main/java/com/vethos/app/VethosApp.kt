package com.vethos.app

import android.app.Application
import androidx.appcompat.app.AppCompatDelegate
import com.vethos.app.data.Store
import java.io.File

class VethosApp : Application() {
    override fun onCreate() {
        // Save any crash to files/crash.txt; the next launch shows it on screen (CrashActivity).
        val old = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            try {
                File(filesDir, "crash.txt").writeText(
                    "Android ${android.os.Build.VERSION.RELEASE} (API ${android.os.Build.VERSION.SDK_INT})\n" +
                    "${android.os.Build.MANUFACTURER} ${android.os.Build.MODEL}\n" +
                    "abis=${android.os.Build.SUPPORTED_ABIS.joinToString()}\n" +
                    "thread=${t.name}\n\n" + android.util.Log.getStackTraceString(e)
                )
            } catch (_: Throwable) { }
            old?.uncaughtException(t, e)
        }
        super.onCreate()
        Store.init(this)
        applyTheme()
    }

    companion object {
        fun applyTheme() {
            AppCompatDelegate.setDefaultNightMode(
                when (Store.theme) {
                    1 -> AppCompatDelegate.MODE_NIGHT_NO
                    2 -> AppCompatDelegate.MODE_NIGHT_YES
                    else -> AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM
                }
            )
        }
    }
}
