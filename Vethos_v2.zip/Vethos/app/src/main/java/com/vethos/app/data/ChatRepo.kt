package com.vethos.app.data

import org.json.JSONArray
import org.json.JSONObject
import java.io.File

data class Msg(val role: String, var text: String, var fb: Int = 0) // role: user | ai ; fb: 1 up, -1 down
data class Chat(val id: String, var title: String, var ts: Long, val msgs: MutableList<Msg>, var persona: String = "")

object ChatRepo {
    private var cache: MutableList<Chat>? = null
    private val file get() = File(Store.app.filesDir, "chats.json")

    fun all(): MutableList<Chat> {
        cache?.let { return it }
        val out = mutableListOf<Chat>()
        try {
            if (file.exists()) {
                val a = JSONArray(file.readText())
                for (i in 0 until a.length()) {
                    val o = a.getJSONObject(i)
                    val ms = o.getJSONArray("m")
                    val msgs = MutableList(ms.length()) {
                        val m = ms.getJSONObject(it)
                        Msg(m.getString("r"), m.getString("t"), m.optInt("f", 0))
                    }
                    out.add(Chat(o.getString("id"), o.getString("title"), o.getLong("ts"), msgs, o.optString("p", "")))
                }
            }
        } catch (_: Exception) { }
        cache = out
        return out
    }

    fun sorted(): List<Chat> = all().sortedByDescending { it.ts }
    fun get(id: String?): Chat? = all().firstOrNull { it.id == id }

    fun save(c: Chat) {
        val l = all()
        if (l.none { it.id == c.id }) l.add(c)
        c.ts = System.currentTimeMillis()
        persist()
    }

    fun delete(id: String) { all().removeAll { it.id == id }; persist() }
    fun clear() { all().clear(); persist() }

    private fun persist() {
        val a = JSONArray()
        all().forEach { c ->
            val ms = JSONArray()
            c.msgs.forEach { ms.put(JSONObject().put("r", it.role).put("t", it.text).put("f", it.fb)) }
            a.put(JSONObject().put("id", c.id).put("title", c.title).put("ts", c.ts).put("p", c.persona).put("m", ms))
        }
        file.writeText(a.toString())
    }
}
