package com.vethos.app.ui

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.fragment.app.Fragment
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.vethos.app.R
import com.vethos.app.data.Catalog
import com.vethos.app.data.Dl
import com.vethos.app.data.Downloads
import com.vethos.app.data.Engine
import com.vethos.app.data.Store
import com.vethos.app.databinding.FragmentLibraryBinding
import com.vethos.app.databinding.ItemModelBinding
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class LibraryFragment : Fragment() {
    private var _b: FragmentLibraryBinding? = null
    private val b get() = _b!!

    /** 0 = all, 1 = on device, 2 = suggested */
    private var filter = 0

    private val picker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) Downloads.importFrom(requireContext(), uri)
    }

    override fun onCreateView(i: LayoutInflater, c: ViewGroup?, s: Bundle?): View =
        FragmentLibraryBinding.inflate(i, c, false).also { _b = it }.root

    override fun onViewCreated(v: View, s: Bundle?) {
        wireMenu(b.btnMenu)
        b.btnImport.setOnClickListener { picker.launch(arrayOf("*/*")) }
        b.btnUrl.setOnClickListener {
            requireContext().inputDialog("Hugging Face link", "", "https://huggingface.co/.../model.gguf") { url ->
                val n = Downloads.fileNameFor(url)
                if (n == null) requireContext().toast("Paste a direct link to a .gguf file")
                else Downloads.start(url, n)
            }
        }
        listOf(b.chipAll, b.chipOn, b.chipSug).forEachIndexed { i, c ->
            c.setOnClickListener { filter = i; paintChips(); render(Downloads.state.value) }
        }
        paintChips()
        viewLifecycleOwner.lifecycleScope.launch {
            viewLifecycleOwner.repeatOnLifecycle(Lifecycle.State.STARTED) {
                Downloads.state.collect { render(it); delay(350) }
            }
        }
    }

    private fun paintChips() {
        listOf(b.chipAll, b.chipOn, b.chipSug).forEachIndexed { i, c ->
            val on = i == filter
            c.setBackgroundResource(if (on) R.drawable.bg_btn_primary else R.drawable.bg_chip)
            c.setTextColor(requireContext().getColor(if (on) R.color.white else R.color.v_text2))
        }
    }

    private fun header(text: String) {
        b.list.addView(TextView(requireContext()).apply {
            this.text = text
            setTextColor(requireContext().getColor(R.color.v_text))
            textSize = 19f
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            setPadding(requireContext().dp(4), requireContext().dp(24), 0, requireContext().dp(2))
        })
    }

    private fun hint(text: String) {
        b.list.addView(TextView(requireContext()).apply {
            this.text = text
            setTextColor(requireContext().getColor(R.color.v_muted))
            textSize = 14f
            setPadding(requireContext().dp(4), requireContext().dp(10), requireContext().dp(4), 0)
        })
    }

    private fun render(dl: Map<String, Dl>) {
        if (_b == null) return
        val ctx = requireContext()
        b.list.removeAllViews()
        val models = Store.models()
        val names = models.map { it.name }.toSet()
        if (Store.lastModel == null && models.isNotEmpty()) Store.lastModel = models.first().name

        if (filter != 2) {
            header("On this device")
            if (models.isEmpty()) hint("No models yet. Download one below or add a .gguf from your phone.")
            models.forEach { f ->
                val isActive = Store.lastModel == f.name
                val loaded = Engine.loadedPath == f.absolutePath
                val r = ItemModelBinding.inflate(layoutInflater, b.list, false)
                r.title.text = f.name.removeSuffix(".gguf")
                r.sub.text = "local · ${f.name.removeSuffix(".gguf")} · ${fmtSize(f.length())}"
                r.icon.setImageResource(if (isActive) R.drawable.ic_check else R.drawable.ic_chip)
                r.root.setBackgroundResource(if (isActive) R.drawable.bg_card_active else R.drawable.bg_solid)
                r.badgeActive.visibility = if (isActive) View.VISIBLE else View.GONE
                r.badgeLoaded.visibility = if (loaded) View.VISIBLE else View.GONE
                r.btns.visibility = View.VISIBLE
                r.btnPrimary.text = "Start Chat"
                r.btnPrimary.setOnClickListener {
                    Store.lastModel = f.name
                    startActivity(Intent(ctx, ChatActivity::class.java))
                }
                when {
                    loaded -> {
                        r.btnSecondary.visibility = View.VISIBLE
                        r.btnSecondary.text = "Unload"
                        r.btnSecondary.setOnClickListener { Engine.unload(); ctx.toast("Model unloaded"); render(Downloads.state.value) }
                    }
                    !isActive -> {
                        r.btnSecondary.visibility = View.VISIBLE
                        r.btnSecondary.text = "Use"
                        r.btnSecondary.setOnClickListener { Store.lastModel = f.name; ctx.toast("Model selected"); render(Downloads.state.value) }
                    }
                }
                r.root.setOnClickListener {
                    if (!isActive) { Store.lastModel = f.name; ctx.toast("Model selected"); render(Downloads.state.value) }
                }
                r.delete.setOnClickListener {
                    ctx.confirm("Delete model?", f.name, "Delete") {
                        if (Store.lastModel == f.name) { Store.lastModel = null; Engine.unload() }
                        f.delete(); Downloads.clearFinished(f.name); render(Downloads.state.value)
                    }
                }
                b.list.addView(r.root)
            }

            val busy = dl.values.filter { it.state != 2 }
            if (busy.isNotEmpty()) {
                header("Downloading")
                busy.forEach { d ->
                    val pct = if (d.total > 0) (d.done * 1000 / d.total).toInt() else -1
                    val sub = when {
                        d.state == 1 -> d.err + if (d.done > 0) " - " + fmtSize(d.done) + " saved" else ""
                        d.total > 0 -> fmtSize(d.done) + " / " + fmtSize(d.total) + " (" + (pct / 10) + "%)"
                        else -> fmtSize(d.done) + " downloaded"
                    }
                    val canResume = Downloads.urls.containsKey(d.name)
                    val r = ItemModelBinding.inflate(layoutInflater, b.list, false)
                    r.title.text = d.name
                    r.sub.text = sub
                    r.action.visibility = View.VISIBLE
                    r.action.text = if (d.state == 0) "Pause" else if (canResume) "Resume" else "Dismiss"
                    r.action.setOnClickListener {
                        if (d.state == 0) Downloads.pause(d.name)
                        else if (canResume) Downloads.start(Downloads.urls[d.name]!!, d.name)
                        else Downloads.clearFinished(d.name)
                    }
                    r.btns.visibility = View.GONE
                    if (d.state == 0) {
                        r.bar.visibility = View.VISIBLE
                        r.bar.max = 1000
                        if (pct < 0) r.bar.isIndeterminate = true else r.bar.progress = pct
                    }
                    r.root.setOnLongClickListener { Downloads.cancel(d.name, true); true }
                    b.list.addView(r.root)
                }
            }
        }

        if (filter != 1) {
            val rec = Catalog.items.filter { it.file !in names && dl[it.file] == null }
            if (rec.isNotEmpty()) {
                header("Suggested for you")
                rec.forEach { m ->
                    val r = ItemModelBinding.inflate(layoutInflater, b.list, false)
                    r.title.text = m.name
                    r.sub.text = m.desc + " · " + m.size
                    r.icon.setBackgroundResource(R.drawable.bg_ci)
                    r.action.visibility = View.VISIBLE
                    r.action.text = "Get"
                    r.action.setOnClickListener { Downloads.start(m.url, m.file) }
                    r.root.setOnClickListener { Downloads.start(m.url, m.file) }
                    b.list.addView(r.root)
                }
                hint("Tap a model to make it active. Load puts it in RAM, Unload frees the RAM. Only GGUF models work (Q4_K_M, Q4_0, Q8_0...). Smaller is faster on phones.")
            }
        }
    }

    override fun onResume() { super.onResume(); if (_b != null) render(Downloads.state.value) }
    override fun onDestroyView() { super.onDestroyView(); _b = null }
}
