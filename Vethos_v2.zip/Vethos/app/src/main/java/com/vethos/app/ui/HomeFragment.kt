package com.vethos.app.ui

import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.widget.ImageView
import androidx.core.graphics.ColorUtils
import androidx.fragment.app.Fragment
import com.vethos.app.data.Personas
import com.vethos.app.data.Store
import com.vethos.app.databinding.FragmentHomeBinding
import com.vethos.app.databinding.ItemPersonaBinding
import java.io.File

class HomeFragment : Fragment() {
    private var _b: FragmentHomeBinding? = null
    private val b get() = _b!!

    override fun onCreateView(i: LayoutInflater, c: ViewGroup?, s: Bundle?): View =
        FragmentHomeBinding.inflate(i, c, false).also { _b = it }.root

    override fun onViewCreated(v: View, s: Bundle?) {
        wireMenu(b.btnMenu)
        b.modelCard.setOnClickListener { (activity as MainActivity).select(1) }
        b.viewAll.setOnClickListener { startActivity(Intent(requireContext(), PersonasActivity::class.java)) }
        b.homeSend.setOnClickListener { sendFromHome() }
        b.homeInput.setOnEditorActionListener { _, action, _ ->
            if (action == EditorInfo.IME_ACTION_SEND) { sendFromHome(); true } else false
        }
    }

    private fun sendFromHome() {
        val t = b.homeInput.text.toString().trim()
        val i = Intent(requireContext(), ChatActivity::class.java)
        if (t.isNotEmpty()) i.putExtra("preset", t).putExtra("autosend", true)
        b.homeInput.setText("")
        startActivity(i)
    }

    private fun renderBots() {
        b.bots.removeAllViews()
        Personas.all().forEach { p ->
            val r = ItemPersonaBinding.inflate(layoutInflater, b.bots, false)
            val ic = Personas.icons[p.ico.coerceIn(0, Personas.icons.lastIndex)]
            r.icon.setImageResource(ic.res)
            r.icon.imageTintList = android.content.res.ColorStateList.valueOf(ic.tint)
            r.icon.background = GradientDrawable().apply {
                cornerRadius = requireContext().dp(14).toFloat()
                setColor(ColorUtils.setAlphaComponent(ic.tint, 36))
                setStroke(requireContext().dp(1), ColorUtils.setAlphaComponent(ic.tint, 70))
            }
            r.title.text = p.name
            r.sub.text = p.desc
            r.root.setOnClickListener {
                startActivity(Intent(requireContext(), ChatActivity::class.java).putExtra("persona", p.id))
            }
            b.bots.addView(r.root)
        }
    }

    override fun onResume() {
        super.onResume()
        val f = Store.lastModel?.let { File(Store.modelsDir, it) }
        if (f != null && f.exists()) {
            val n = f.name.removeSuffix(".gguf")
            b.modelName.text = n
            b.modelSub.text = "Active model · ${n.uppercase()} · ${fmtSize(f.length())}"
        } else {
            b.modelName.text = "No model selected"
            b.modelSub.text = "Tap to download or add one"
        }
        renderBots()
    }

    override fun onDestroyView() { super.onDestroyView(); _b = null }
}
