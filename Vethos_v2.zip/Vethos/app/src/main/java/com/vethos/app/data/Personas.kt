package com.vethos.app.data

import android.graphics.Color
import com.vethos.app.R
import org.json.JSONArray
import org.json.JSONObject

data class Persona(val id: String, var name: String, var desc: String, var prompt: String, var ico: Int)

class PIcon(val res: Int, val tint: Int)

object Personas {
    val icons = listOf(
        PIcon(R.drawable.ic_chat, Color.parseColor("#0E9AA7")),
        PIcon(R.drawable.ic_code, Color.parseColor("#7C5CFA")),
        PIcon(R.drawable.ic_heart, Color.parseColor("#16A34A")),
        PIcon(R.drawable.ic_book, Color.parseColor("#C9623F")),
        PIcon(R.drawable.ic_hash, Color.parseColor("#C9623F")),
        PIcon(R.drawable.ic_dollar, Color.parseColor("#C9623F")),
        PIcon(R.drawable.ic_flask, Color.parseColor("#C9623F")),
        PIcon(R.drawable.ic_edit, Color.parseColor("#C9623F")),
    )

    private val prefs get() = Store.app.getSharedPreferences("vethos", 0)
    private var cache: MutableList<Persona>? = null

    private fun defaults() = mutableListOf(
        Persona("general", "General Assistant", "Everyday questions, ideas and planning",
            "You are Vethos, a helpful, concise assistant running offline on the user's phone. Answer everyday questions clearly and help with ideas and planning.", 0),
        Persona("coder", "Coder", "Debugging, code and architecture",
            "You are an expert software engineer. Help with debugging, writing clean code and designing software. Give short explanations and put code in code blocks.", 1),
        Persona("doctor", "Doctor", "General health information",
            "You give general health information in simple words. You are not a doctor: remind the user to see a medical professional for diagnosis or emergencies.", 2),
        Persona("teacher", "Teacher", "Study help, notes and exam prep",
            "You are a patient teacher. Explain topics step by step, give simple examples, and help with notes and exam preparation.", 3),
        Persona("math", "Math Mentor", "Step-by-step problem solving",
            "You are a math mentor. Solve problems step by step, show your working, and check the answer at the end.", 4),
        Persona("finance", "Finance Pro", "Money, budgets and business basics",
            "You explain money, budgeting and business basics clearly. Give practical tips and mention that this is general information, not financial advice.", 5),
        Persona("research", "Research Pal", "Science and deep dives",
            "You are a curious research assistant. Explain science and complex topics in depth, in clear language, and say when you are unsure.", 6),
        Persona("writer", "Writer", "Writing, rewriting and translation",
            "You are a skilled writer and editor. Help write, rewrite, summarise and translate text while keeping the user's tone.", 7),
    )

    fun all(): MutableList<Persona> {
        cache?.let { return it }
        val out = mutableListOf<Persona>()
        try {
            val raw = prefs.getString("personas", null)
            if (raw != null) {
                val a = JSONArray(raw)
                for (i in 0 until a.length()) {
                    val o = a.getJSONObject(i)
                    out.add(Persona(o.getString("id"), o.getString("name"), o.optString("desc"), o.optString("prompt"), o.optInt("ico", 0)))
                }
            }
        } catch (_: Exception) { out.clear() }
        if (out.isEmpty()) out.addAll(defaults())
        cache = out
        return out
    }

    fun get(id: String?): Persona? = if (id.isNullOrEmpty()) null else all().firstOrNull { it.id == id }

    var selectedId: String
        get() = prefs.getString("persona", "general")!!
        set(v) = prefs.edit().putString("persona", v).apply()

    fun current(): Persona = get(selectedId) ?: all().first()

    fun save() {
        val a = JSONArray()
        all().forEach {
            a.put(JSONObject().put("id", it.id).put("name", it.name).put("desc", it.desc).put("prompt", it.prompt).put("ico", it.ico))
        }
        prefs.edit().putString("personas", a.toString()).apply()
    }

    fun add(name: String, desc: String, prompt: String): Persona {
        val p = Persona("p" + System.currentTimeMillis(), name, desc, prompt, all().size % icons.size)
        all().add(p); save()
        return p
    }

    fun delete(id: String) {
        if (all().size <= 1) return
        all().removeAll { it.id == id }
        if (selectedId == id) selectedId = all().first().id
        save()
    }
}
