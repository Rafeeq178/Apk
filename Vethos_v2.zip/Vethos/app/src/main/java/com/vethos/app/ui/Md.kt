package com.vethos.app.ui

import android.content.Context
import android.graphics.Typeface
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.style.BackgroundColorSpan
import android.text.style.ForegroundColorSpan
import android.text.style.RelativeSizeSpan
import android.text.style.StyleSpan
import android.text.style.TypefaceSpan
import com.vethos.app.R

/** Tiny markdown renderer: **bold** and `code`. Unfinished markers (while streaming) stay as plain text. */
object Md {
    private val tok = Regex("""\*\*(.+?)\*\*|`([^`\n]+)`""")

    fun render(src: String): SpannableStringBuilder {
        val out = SpannableStringBuilder()
        var last = 0
        for (m in tok.findAll(src)) {
            out.append(src, last, m.range.first)
            val start = out.length
            val bold = m.groupValues[1]
            if (bold.isNotEmpty()) {
                out.append(bold)
                out.setSpan(StyleSpan(Typeface.BOLD), start, out.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            } else {
                out.append(m.groupValues[2])
                out.setSpan(TypefaceSpan("monospace"), start, out.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                out.setSpan(BackgroundColorSpan(0x1F888888), start, out.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            }
            last = m.range.last + 1
        }
        out.append(src, last, src.length)
        return out
    }

    /** Rendered text followed by the small orange "live" dot. */
    fun withCursor(ctx: Context, src: String, on: Boolean): CharSequence {
        val sb = render(src)
        val s = sb.length
        sb.append(" ●")
        val c = ctx.getColor(R.color.v_blue)
        sb.setSpan(ForegroundColorSpan(if (on) c else (c and 0x00FFFFFF) or 0x44000000), s, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        sb.setSpan(RelativeSizeSpan(0.6f), s, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        return sb
    }
}
