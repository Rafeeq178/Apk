package com.vethos.app.ui

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.vethos.app.data.Persona
import com.vethos.app.data.Personas
import com.vethos.app.databinding.ActivityPersonasBinding
import com.vethos.app.databinding.DialogPersonaBinding
import com.vethos.app.databinding.ItemPersonaBinding

class PersonasActivity : AppCompatActivity() {
    private lateinit var b: ActivityPersonasBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityPersonasBinding.inflate(layoutInflater)
        setContentView(b.root)
        b.btnMenu.setOnClickListener { finish() }
        b.btnNew.setOnClickListener { edit(null) }
        render()
    }

    private fun render() {
        b.list.removeAllViews()
        val card = android.widget.LinearLayout(this).apply {
            orientation = android.widget.LinearLayout.VERTICAL
            setBackgroundResource(com.vethos.app.R.drawable.bg_card)
        }
        Personas.all().forEachIndexed { idx, p ->
            val r = ItemPersonaBinding.inflate(layoutInflater, card, false)
            val ic = Personas.icons[p.ico.coerceIn(0, Personas.icons.lastIndex)]
            r.icon.setImageResource(ic.res)
            r.icon.imageTintList = android.content.res.ColorStateList.valueOf(getColor(com.vethos.app.R.color.v_blue))
            r.title.text = p.name
            r.sub.text = p.desc
            r.trail.setImageResource(com.vethos.app.R.drawable.ic_edit)
            r.trail.setBackgroundResource(0)
            r.trail.imageTintList = android.content.res.ColorStateList.valueOf(getColor(com.vethos.app.R.color.v_muted))
            r.trail.setPadding(dp(8), dp(8), dp(8), dp(8))
            (r.root.layoutParams as android.widget.LinearLayout.LayoutParams).apply { topMargin = 0 }
            r.root.setBackgroundResource(0)
            r.root.setOnClickListener { edit(p) }
            card.addView(r.root)
            if (idx < Personas.all().lastIndex) card.addView(android.view.View(this).apply {
                setBackgroundColor(getColor(com.vethos.app.R.color.v_line))
            }, android.widget.LinearLayout.LayoutParams(-1, 1).apply { marginStart = dp(76); marginEnd = dp(16) })
        }
        b.list.addView(card)
    }

    private fun edit(p: Persona?) {
        val d = DialogPersonaBinding.inflate(layoutInflater)
        d.name.setText(p?.name ?: "")
        d.desc.setText(p?.desc ?: "")
        d.prompt.setText(p?.prompt ?: "")
        val dlg = MaterialAlertDialogBuilder(this)
            .setTitle(if (p == null) "New personality" else "Edit personality")
            .setView(d.root)
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Save") { _, _ ->
                val name = d.name.text.toString().trim()
                val desc = d.desc.text.toString().trim()
                val prompt = d.prompt.text.toString().trim().ifEmpty { "You are a helpful assistant." }
                if (name.isEmpty()) { toast("Give it a name"); return@setPositiveButton }
                if (p == null) Personas.add(name, desc, prompt)
                else { p.name = name; p.desc = desc; p.prompt = prompt; Personas.save() }
                render()
            }
        if (p != null && Personas.all().size > 1) {
            dlg.setNeutralButton("Delete") { _, _ ->
                confirm("Delete personality?", p.name, "Delete") { Personas.delete(p.id); render() }
            }
        }
        dlg.show()
    }
}
