package com.vethos.app.ui

import android.content.Context
import android.text.format.DateFormat
import android.view.ViewGroup
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.Toast
import com.google.android.material.dialog.MaterialAlertDialogBuilder

fun Context.dp(v: Int) = (v * resources.displayMetrics.density).toInt()
fun Context.toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

fun fmtSize(b: Long): String =
    if (b >= (1L shl 30)) "%.2f GB".format(b / 1073741824.0) else "%d MB".format(b / 1048576)

fun fmtDate(ts: Long): String = DateFormat.format("d MMM, h:mm a", ts).toString()

fun Context.confirm(title: String, msg: String, ok: String, onOk: () -> Unit) {
    MaterialAlertDialogBuilder(this).setTitle(title).setMessage(msg)
        .setNegativeButton("Cancel", null).setPositiveButton(ok) { _, _ -> onOk() }.show()
}

fun Context.inputDialog(title: String, initial: String, hint: String, multiline: Boolean = false, onOk: (String) -> Unit) {
    val et = EditText(this).apply {
        setText(initial); setHint(hint); setSelection(initial.length)
        if (multiline) { minLines = 4; maxLines = 8; gravity = android.view.Gravity.TOP }
    }
    val box = FrameLayout(this).apply {
        setPadding(dp(22), dp(8), dp(22), 0)
        addView(et, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
    }
    MaterialAlertDialogBuilder(this).setTitle(title).setView(box)
        .setNegativeButton("Cancel", null).setPositiveButton("Save") { _, _ -> onOk(et.text.toString()) }.show()
}

fun Context.choose(title: String, items: List<String>, checked: Int, onPick: (Int) -> Unit) {
    MaterialAlertDialogBuilder(this).setTitle(title)
        .setSingleChoiceItems(items.toTypedArray(), checked) { d, i -> onPick(i); d.dismiss() }
        .setNegativeButton("Cancel", null).show()
}

/** Hooks up a round header button so it opens the side drawer of MainActivity. */
fun androidx.fragment.app.Fragment.wireMenu(btn: android.view.View) {
    btn.setOnClickListener { (activity as? MainActivity)?.openDrawer() }
}

class SheetRow(val icon: Int, val title: String, val sub: String? = null, val checked: Boolean = false, val onClick: () -> Unit)

/** Bottom sheet with a title, a close button and a list of rows. */
fun Context.showSheet(title: String, rows: List<SheetRow>) {
    val dlg = com.google.android.material.bottomsheet.BottomSheetDialog(this)
    val inf = android.view.LayoutInflater.from(this)
    val sb = com.vethos.app.databinding.SheetListBinding.inflate(inf)
    sb.title.text = title
    sb.close.setOnClickListener { dlg.dismiss() }
    rows.forEach { r ->
        val rb = com.vethos.app.databinding.ItemSheetBinding.inflate(inf, sb.list, false)
        rb.icon.setImageResource(r.icon)
        rb.title.text = r.title
        if (r.sub.isNullOrEmpty()) rb.sub.visibility = android.view.View.GONE else rb.sub.text = r.sub
        rb.check.visibility = if (r.checked) android.view.View.VISIBLE else android.view.View.GONE
        rb.root.setOnClickListener { dlg.dismiss(); r.onClick() }
        sb.list.addView(rb.root)
    }
    dlg.setContentView(sb.root)
    (sb.root.parent as? android.view.View)?.setBackgroundColor(android.graphics.Color.TRANSPARENT)
    dlg.behavior.state = com.google.android.material.bottomsheet.BottomSheetBehavior.STATE_EXPANDED
    dlg.behavior.skipCollapsed = true
    dlg.show()
}
