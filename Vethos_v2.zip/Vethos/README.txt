VETHOS - native Android app (Kotlin, no WebView, no ads)

Termux build:
  1. pkg install git openjdk-17 gradle   (plus Android SDK + NDK + cmake)
  2. ./setup.sh          # clones llama.cpp and prepares its Android lib
  3. gradle assembleRelease
  APK: app/build/outputs/apk/release/

Needs Android 10+ (API 29), arm64 phone.

v2 changes
  - Settings crash fixed: the settings layout had a view with id "root", which clashes with ViewBinding's
    .root and caused "The specified child already has a parent". It is now called "content".
  - New UI matching the reference recordings (gradient background, pill nav, side drawer, personalities,
    new Library / Insights / Settings screens).
  - Chat: live typing animation with a blinking dot, thumbs / copy / share / regenerate actions,
    options sheet, personality sheet, voice input, export chat.
  - Settings that are saved but not yet applied by the engine: Creativity, Repetition penalty, CPU threads,
    Multi-thread, GPU, Context size (llama.android's sendUserPrompt only takes the prompt and max tokens).
