/* Vethos service worker: app shell offline cache. Model files are stored separately by downloader.js */
const C='vethos-shell-v10',F=['./','index.html','style.css','downloader.js','app.js','manifest.json','icon.svg','icons/icon-192.png','icons/icon-512.png','icons/apple-touch-icon.png','icons/favicon-32.png'];
self.addEventListener('install',e=>{e.waitUntil((async()=>{
 const c=await caches.open(C);
 /* ek file na mile to poora install fail na ho: har file alag alag cache hoti hai */
 await Promise.all(F.map(u=>c.add(new Request(u,{cache:'reload'})).catch(()=>{})));
 await self.skipWaiting()})())});
self.addEventListener('activate',e=>{e.waitUntil(caches.keys().then(k=>Promise.all(k.filter(x=>x.startsWith('vethos-shell')&&x!==C).map(x=>caches.delete(x)))).then(()=>self.clients.claim()))});
self.addEventListener('fetch',e=>{const r=e.request;if(r.method!=='GET'||new URL(r.url).origin!==location.origin)return;
 /* network-first (4s timeout): update turant lage, cache offline ke liye */
 e.respondWith((async()=>{const h=await caches.match(r);try{const res=await Promise.race([fetch(r),new Promise((_,j)=>setTimeout(j,4000))]);if(res.ok){const k=res.clone();caches.open(C).then(c=>c.put(r,k))}return res}catch(_){return h||fetch(r)}})())});
