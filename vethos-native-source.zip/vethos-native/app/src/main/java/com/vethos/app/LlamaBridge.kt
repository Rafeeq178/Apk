package com.vethos.app

/** JNI bridge to llama.cpp. The native library is built from app/src/main/cpp/llama.cpp. */
object LlamaBridge {
    init { System.loadLibrary("vethos_llama") }
    external fun nativeVersion(): String
    external fun nativeLoad(path: String, threads: Int, context: Int): Boolean
    external fun nativeUnload()
    external fun nativeGenerate(prompt: String, maxTokens: Int): String
}
