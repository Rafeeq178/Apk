package com.vethos.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusDirection
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.util.UUID

private val Paper = Color(0xFFF9F9F6)
private val Surface = Color(0xFFFFFFFF)
private val Ink = Color(0xFF242421)
private val Muted = Color(0xFF777771)
private val Line = Color(0xFFE8E7E1)
private val Accent = Color(0xFFC77D60)
private val Dark = Color(0xFF242421)

private data class ModelInfo(val name: String, val path: String, val size: Long)
private data class Message(val role: String, val text: String)
private data class Personality(val id: String, val name: String, val desc: String, val prompt: String)

private val personalities = listOf(
    Personality("gen", "General Assistant", "Everyday questions, ideas and planning", "Be a friendly, practical everyday assistant. Give the direct answer first, then short reasoning."),
    Personality("coder", "Coder", "Debugging, code and architecture", "Act as a senior software engineer and patient mentor. Give correct, readable code in fenced blocks. Explain root causes and practical fixes."),
    Personality("teacher", "Teacher", "Study help, notes and exam prep", "Act as a patient teacher. Explain from basics using simple words and examples. End with key points or a practice question when useful."),
    Personality("math", "Math Mentor", "Step-by-step problem solving", "Act as a math tutor. Solve step by step, show calculations, verify the result, and end with Answer: ..."),
    Personality("writer", "Writer", "Writing, rewriting and translation", "Act as a professional writer and editor. Match the requested language and tone. Preserve the user's meaning and facts."),
    Personality("res", "Research Pal", "Science and deep dives", "Act as a careful research assistant. Separate facts from uncertainty and never invent sources or statistics."),
    Personality("fin", "Finance Pro", "Money, budgets and business basics", "Explain budgeting and finance in simple terms, use PKR unless asked otherwise, and clearly describe risks."),
    Personality("doctor", "Health Guide", "General health information", "Provide cautious general health information, do not diagnose, and advise urgent care for emergency symptoms.")
)

class MainActivity : ComponentActivity() {
    private val modelState = mutableStateOf<ModelInfo?>(null)
    private val loadedState = mutableStateOf(false)
    private val statusState = mutableStateOf("Choose a GGUF model to begin")
    private val chatState = mutableStateListOf<Message>()
    private val screenState = mutableStateOf("Home")
    private val selectedPersonality = mutableStateOf(personalities.first())
    private val generating = mutableStateOf(false)
    private val modelFilePicker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) importModel(uri)
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getPreferences(MODE_PRIVATE)
        val savedPath = prefs.getString("model_path", null)
        if (savedPath != null && File(savedPath).exists()) {
            modelState.value = ModelInfo(prefs.getString("model_name", File(savedPath).name) ?: File(savedPath).name, savedPath, prefs.getLong("model_size", File(savedPath).length()))
            statusState.value = "Model available. Tap Load model to put it into RAM."
        }
        setContent { VethosApp() }
    }

    private fun importModel(uri: Uri) {
        lifecycleScope.launch {
            statusState.value = "Copying model into app storage… keep the app open"
            try {
                val name = queryName(uri).ifBlank { "model.gguf" }
                if (!name.lowercase().endsWith(".gguf")) throw IllegalArgumentException("Please choose a .gguf model file.")
                val folder = File(filesDir, "models").apply { mkdirs() }
                val target = File(folder, name.replace(Regex("[^A-Za-z0-9._-]"), "_"))
                withContext(Dispatchers.IO) {
                    contentResolver.openInputStream(uri).use { input ->
                        requireNotNull(input) { "Unable to read selected file" }
                        FileOutputStream(target).use { output -> input.copyTo(output, 1024 * 1024) }
                    }
                }
                modelState.value = ModelInfo(name, target.absolutePath, target.length())
                getPreferences(MODE_PRIVATE).edit().putString("model_path", target.absolutePath).putString("model_name", name).putLong("model_size", target.length()).apply()
                statusState.value = "Model added. Tap Load model to put it into RAM."
                loadedState.value = false
            } catch (e: Exception) { statusState.value = "Import failed: ${e.message ?: "unknown error"}" }
        }
    }
    private fun queryName(uri: Uri): String {
        contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) return c.getString(0) ?: "model.gguf"
        }
        return "model.gguf"
    }
    private fun loadModel() {
        val model = modelState.value ?: run { statusState.value = "Add a GGUF model first"; return }
        lifecycleScope.launch {
            statusState.value = "Loading model… large models can take time"
            val ok = withContext(Dispatchers.IO) { runCatching { LlamaBridge.nativeLoad(model.path, (Runtime.getRuntime().availableProcessors() - 1).coerceAtLeast(2), 2048) }.getOrDefault(false) }
            loadedState.value = ok
            statusState.value = if (ok) "Model loaded · runs locally on this device" else "Could not load model. Check available RAM and choose a smaller GGUF (Q4_K_M recommended)."
        }
    }
    private fun unloadModel() { lifecycleScope.launch(Dispatchers.IO) { runCatching { LlamaBridge.nativeUnload() }; loadedState.value = false; statusState.value = "Model unloaded · RAM freed" } }
    private fun sendMessage(text: String) {
        val promptText = text.trim()
        if (promptText.isEmpty() || generating.value) return
        if (!loadedState.value) { statusState.value = "Load a model before sending messages"; screenState.value = "Models"; return }
        chatState.add(Message("user", promptText))
        generating.value = true
        val persona = selectedPersonality.value
        val history = chatState.takeLast(12).joinToString("\n") { if (it.role == "user") "User: ${it.text}" else "Assistant: ${it.text}" }
        val prompt = "<|im_start|>system\nYou are ${persona.name}, a private AI assistant running offline on a phone. Always answer in the same language as the user, including Roman Urdu if used. ${persona.prompt}\n<|im_end|>\n" + history + "\n<|im_start|>assistant\n"
        lifecycleScope.launch {
            val response = withContext(Dispatchers.IO) { runCatching { LlamaBridge.nativeGenerate(prompt, 512) }.getOrElse { "Generation failed: ${it.message}" } }
            chatState.add(Message("assistant", response.trim().ifEmpty { "(No text generated. Try a different GGUF model or prompt format.)" }))
            generating.value = false
        }
    }

    @Composable private fun VethosApp() {
        MaterialTheme(colorScheme = lightColorScheme(primary = Ink, background = Paper, surface = Surface, onSurface = Ink)) {
            Scaffold(containerColor = Paper, bottomBar = { if (screenState.value != "Chat") BottomNav(screenState.value) { screenState.value = it } }) { pad ->
                Column(Modifier.fillMaxSize().padding(pad)) {
                    Header(screenState.value, onBack = { screenState.value = "Home" }, onMenu = { screenState.value = "Home" })
                    when (screenState.value) {
                        "Home" -> HomeScreen()
                        "Models" -> ModelsScreen()
                        "Personalities" -> PersonalitiesScreen()
                        "Settings" -> SettingsScreen()
                        "Insights" -> InsightsScreen()
                        "Chat" -> ChatScreen()
                        else -> HomeScreen()
                    }
                }
            }
        }
    }
    @Composable private fun Header(title: String, onBack: () -> Unit, onMenu: () -> Unit) {
        Row(Modifier.fillMaxWidth().height(58.dp).padding(horizontal = 14.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(if (title == "Home") "☰" else "‹", fontSize = 27.sp, modifier = Modifier.clickable { if (title == "Home") onMenu() else onBack() }.padding(end = 18.dp))
            Text(if (title == "Home") "Vethos" else title, fontSize = 19.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
            Text("V", color = Color.White, fontWeight = FontWeight.Bold, modifier = Modifier.background(Accent, CircleShape).padding(horizontal = 13.dp, vertical = 8.dp))
        }
        HorizontalDivider(color = Line, thickness = .6.dp)
    }
    @Composable private fun HomeScreen() {
        LazyColumn(Modifier.fillMaxSize().padding(horizontal = 18.dp), contentPadding = PaddingValues(top = 18.dp, bottom = 18.dp)) {
            item {
                Spacer(Modifier.height(22.dp)); Text("V  E  T  H  O  S", color = Accent, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Text("What can we do for you?", fontSize = 29.sp, lineHeight = 35.sp, fontWeight = FontWeight.Medium, modifier = Modifier.padding(top = 16.dp))
                Text("Offline AI that stays on your device", color = Muted, fontSize = 14.sp, modifier = Modifier.padding(top = 7.dp, bottom = 22.dp))
                CardBox {
                    Text(modelState.value?.name ?: "Pick your AI model", fontWeight = FontWeight.SemiBold, fontSize = 17.sp)
                    Text(if (loadedState.value) "Active · loaded into RAM" else statusState.value, color = Muted, fontSize = 13.sp, modifier = Modifier.padding(top = 5.dp, bottom = 14.dp))
                    DarkButton(if (modelState.value == null) "Choose GGUF model" else if (loadedState.value) "Open chat" else "Manage model") {
                        if (modelState.value == null) modelFilePicker.launch(arrayOf("*/*")) else screenState.value = if (loadedState.value) "Chat" else "Models"
                    }
                }
                SectionTitle("Personalities")
            }
            items(personalities) { p -> RowCard(p.name, p.desc, selectedPersonality.value.id == p.id) { selectedPersonality.value = p; screenState.value = "Chat" } }
            item { Spacer(Modifier.height(16.dp)); Text("Private by design · no account required", color = Muted, fontSize = 12.sp) }
        }
    }
    @Composable private fun ModelsScreen() {
        Column(Modifier.fillMaxSize().padding(18.dp)) {
            CardBox {
                Text("Local GGUF model", fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
                Text(modelState.value?.name ?: "No model selected", modifier = Modifier.padding(top = 8.dp), fontSize = 14.sp)
                Text(modelState.value?.let { "${formatBytes(it.size)} · stored inside app" } ?: "Choose a .gguf file from your phone storage.", color = Muted, fontSize = 13.sp, modifier = Modifier.padding(top = 4.dp, bottom = 14.dp))
                DarkButton("Add model from phone storage") { modelFilePicker.launch(arrayOf("*/*")) }
                Spacer(Modifier.height(9.dp))
                if (!loadedState.value) LightButton("Load model into RAM", enabled = modelState.value != null) { loadModel() }
                else LightButton("Unload model · free RAM") { unloadModel() }
            }
            Spacer(Modifier.height(12.dp))
            Text(statusState.value, color = Muted, fontSize = 13.sp, modifier = Modifier.padding(4.dp))
            Spacer(Modifier.height(10.dp))
            Text("Tips", fontSize = 15.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(vertical = 8.dp))
            Text("• Start with a 1B–3B Q4_K_M GGUF on phones.\n• Loading requires enough free RAM; close other apps first.\n• The app copies the selected file into its private storage, so keep extra storage space available.\n• Split GGUF files are not supported by this first build.\n• Once loaded, text generation works offline.", color = Muted, fontSize = 13.sp, lineHeight = 20.sp)
        }
    }
    @Composable private fun PersonalitiesScreen() {
        LazyColumn(Modifier.fillMaxSize().padding(horizontal = 18.dp), contentPadding = PaddingValues(vertical = 14.dp)) {
            item { Text("Choose how your model responds", color = Muted, fontSize = 14.sp, modifier = Modifier.padding(bottom = 14.dp)) }
            items(personalities) { p -> RowCard(p.name, p.desc, selectedPersonality.value.id == p.id) { selectedPersonality.value = p } }
        }
    }
    @Composable private fun SettingsScreen() {
        Column(Modifier.fillMaxSize().padding(18.dp)) {
            CardBox {
                Text("Vethos", fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
                Text("Native Android · on-device inference", color = Muted, fontSize = 13.sp, modifier = Modifier.padding(top = 5.dp))
            }
            Spacer(Modifier.height(12.dp))
            CardBox {
                Text("Privacy", fontWeight = FontWeight.SemiBold)
                Text("Prompts and responses are processed on-device after the model is loaded. No telemetry or account system is included in this project.", color = Muted, fontSize = 13.sp, lineHeight = 19.sp, modifier = Modifier.padding(top = 8.dp))
            }
            Spacer(Modifier.height(12.dp))
            LightButton("Unload model and free RAM", enabled = loadedState.value) { unloadModel() }
        }
    }
    @Composable private fun InsightsScreen() {
        Column(Modifier.fillMaxSize().padding(18.dp)) {
            Text("Performance", fontSize = 26.sp, fontWeight = FontWeight.Medium)
            Spacer(Modifier.height(14.dp))
            CardBox {
                StatRow("Inference engine", "llama.cpp · CPU")
                StatRow("Model", modelState.value?.name ?: "None selected")
                StatRow("Status", if (loadedState.value) "Loaded" else "Not loaded")
                StatRow("Model size", modelState.value?.let { formatBytes(it.size) } ?: "—")
            }
        }
    }
    @Composable private fun ChatScreen() {
        val focus = LocalFocusManager.current
        var input by remember { mutableStateOf("") }
        Column(Modifier.fillMaxSize()) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 9.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(selectedPersonality.value.name, fontWeight = FontWeight.SemiBold)
                    Text(if (loadedState.value) "On-device model" else "Model not loaded", color = Muted, fontSize = 12.sp)
                }
                Text("Change", color = Accent, modifier = Modifier.clickable { screenState.value = "Personalities" }.padding(8.dp))
            }
            HorizontalDivider(color = Line)
            if (chatState.isEmpty()) {
                Column(Modifier.fillMaxWidth().weight(1f).padding(26.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("How can I help?", fontSize = 25.sp, fontWeight = FontWeight.Medium)
                    Text("Your conversation stays on this device.", color = Muted, fontSize = 13.sp, modifier = Modifier.padding(top = 8.dp))
                }
            } else LazyColumn(Modifier.weight(1f).fillMaxWidth().padding(horizontal = 14.dp), contentPadding = PaddingValues(vertical = 12.dp)) {
                items(chatState) { msg ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (msg.role == "user") Arrangement.End else Arrangement.Start) {
                        Column(Modifier.padding(vertical = 5.dp).widthIn(max = 320.dp).background(if (msg.role == "user") Color(0xFFEDEBE5) else Surface, RoundedCornerShape(18.dp)).padding(13.dp)) {
                            Text(if (msg.role == "user") "You" else "Vethos", fontSize = 11.sp, color = Muted, fontWeight = FontWeight.SemiBold)
                            Spacer(Modifier.height(5.dp)); Text(msg.text, fontSize = 15.sp, lineHeight = 22.sp)
                        }
                    }
                }
                if (generating.value) item { Text("Generating…", color = Muted, modifier = Modifier.padding(10.dp)) }
            }
            Column(Modifier.fillMaxWidth().background(Paper).padding(horizontal = 12.dp, vertical = 8.dp)) {
                Row(Modifier.fillMaxWidth().background(Surface, RoundedCornerShape(22.dp)).padding(10.dp), verticalAlignment = Alignment.Bottom) {
                    BasicTextField(value = input, onValueChange = { input = it }, modifier = Modifier.weight(1f).padding(9.dp), textStyle = androidx.compose.ui.text.TextStyle(color = Ink, fontSize = 15.sp), minLines = 1, maxLines = 5, keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send), keyboardActions = KeyboardActions(onSend = { focus.moveFocus(FocusDirection.Down); sendMessage(input); input = "" }), decorationBox = { inner -> if (input.isEmpty()) Text("Message Vethos…", color = Muted); inner() })
                    Text("↑", fontSize = 24.sp, color = Color.White, modifier = Modifier.padding(start = 6.dp).background(Dark, CircleShape).clickable { sendMessage(input); input = "" }.padding(horizontal = 14.dp, vertical = 7.dp))
                }
                Text("AI can make mistakes · runs locally", color = Muted, fontSize = 10.sp, modifier = Modifier.align(Alignment.CenterHorizontally).padding(top = 6.dp))
            }
        }
    }
    @Composable private fun BottomNav(current: String, onSelect: (String) -> Unit) {
        Row(Modifier.fillMaxWidth().background(Surface).padding(horizontal = 8.dp, vertical = 7.dp), horizontalArrangement = Arrangement.SpaceAround) {
            listOf("Home" to "⌂", "Models" to "▦", "Personalities" to "◉", "Insights" to "▥", "Settings" to "⚙").forEach { (label, icon) ->
                Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.clickable { onSelect(label) }.padding(horizontal = 3.dp, vertical = 2.dp)) {
                    Text(icon, color = if (current == label) Accent else Muted, fontSize = 20.sp)
                    Text(label, color = if (current == label) Ink else Muted, fontSize = 9.sp)
                }
            }
        }
    }
    @Composable private fun CardBox(content: @Composable ColumnScope.() -> Unit) {
        Column(Modifier.fillMaxWidth().background(Surface, RoundedCornerShape(20.dp)).padding(17.dp), content = content)
    }
    @Composable private fun DarkButton(label: String, onClick: () -> Unit) {
        Button(onClick = onClick, modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp), shape = RoundedCornerShape(14.dp), colors = ButtonDefaults.buttonColors(containerColor = Dark, contentColor = Color.White)) { Text(label, fontWeight = FontWeight.Medium) }
    }
    @Composable private fun LightButton(label: String, enabled: Boolean = true, onClick: () -> Unit) {
        OutlinedButton(onClick = onClick, enabled = enabled, modifier = Modifier.fillMaxWidth().heightIn(min = 46.dp), shape = RoundedCornerShape(14.dp), colors = ButtonDefaults.outlinedButtonColors(contentColor = Ink)) { Text(label) }
    }
    @Composable private fun SectionTitle(title: String) { Text(title, fontSize = 14.sp, color = Muted, fontWeight = FontWeight.Medium, modifier = Modifier.padding(top = 20.dp, bottom = 9.dp)) }
    @Composable private fun RowCard(title: String, subtitle: String, selected: Boolean = false, onClick: () -> Unit) {
        Row(Modifier.fillMaxWidth().padding(bottom = 7.dp).background(Surface, RoundedCornerShape(15.dp)).clickable(onClick = onClick).padding(13.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(39.dp).background(if (selected) Color(0xFFF1E3DC) else Color(0xFFF0F0EB), CircleShape), contentAlignment = Alignment.Center) { Text(title.take(1), color = if (selected) Accent else Ink, fontWeight = FontWeight.SemiBold) }
            Column(Modifier.weight(1f).padding(start = 11.dp)) { Text(title, fontWeight = FontWeight.Medium, fontSize = 14.sp); Text(subtitle, color = Muted, fontSize = 12.sp, lineHeight = 16.sp) }
            if (selected) Text("✓", color = Accent, fontWeight = FontWeight.Bold)
        }
    }
    @Composable private fun StatRow(label: String, value: String) { Row(Modifier.fillMaxWidth().padding(vertical = 9.dp), horizontalArrangement = Arrangement.SpaceBetween) { Text(label, color = Muted, fontSize = 13.sp); Text(value, fontSize = 13.sp, fontWeight = FontWeight.Medium) } }
    private fun formatBytes(bytes: Long): String = if (bytes >= 1_000_000_000) "%.2f GB".format(bytes / 1_000_000_000.0) else "%.0f MB".format(bytes / 1_000_000.0)
}
