package com.vethos.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusDirection
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Brush
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.util.UUID

private val Paper = Color(0xFFFAF9F5)
private val Card = Color(0xFFFFFFFF)
private val Surface = Card
private val Ink = Color(0xFF1F1A17)
private val Muted = Color(0xFF7A716A)
private val Line = Color(0xFFE8E4DA)
private val Terracotta = Color(0xFFC9623F)
private val Peach = Color(0xFFE08A5F)
private val Accent = Terracotta
private val Dark = Terracotta

private data class ModelInfo(val name: String, val path: String, val size: Long)
private data class Message(val role: String, val text: String)
private data class Personality(val id: String, val name: String, val desc: String, val prompt: String)

private val personalities = listOf(
    Personality("gen", "General Assistant", "Everyday questions, ideas and planning", "Be a friendly, practical everyday assistant. Give the direct answer first, then short reasoning."),
    Personality("coder", "Coder", "Debugging, code and architecture", "Act as a senior software engineer and patient mentor. Give correct, readable code in fenced blocks. Explain root causes and practical fixes."),
    Personality("teacher", "Teacher", "Study help, notes and exam prep", "Act as a patient teacher. Explain from basics using simple words and examples. End with key points or a practice question when useful."),
    Personality("math", "Math Mentor", "Step-by-step problem solving", "Act as a math tutor. Solve step by step, show calculations, verify the result, and end with Answer: ..."),
    Personality("writer", "Writer", "Writing, rewriting and translation", "Act as a professional writer and editor. Match the requested language and tone. Preserve the user's meaning and facts."),
    Personality("res", "Research Pal", "Science and deep dives", "Act as a careful research assistant. Separate facts from uncertainty and never invent sources or statistics."),
    Personality("fin", "Finance Pro", "Money, budgets and business basics", "Explain budgeting and finance in simple terms, use PKR unless asked otherwise, and clearly describe risks."),
    Personality("doctor", "Health Guide", "General health information", "Provide cautious general health information, do not diagnose, and advise urgent care for emergency symptoms.")
)

class MainActivity : ComponentActivity() {
    private val modelState = mutableStateOf<ModelInfo?>(null)
    private val loadedState = mutableStateOf(false)
    private val statusState = mutableStateOf("Choose a GGUF model to begin")
    private val chatState = mutableStateListOf<Message>()
    private val screenState = mutableStateOf("Home")
    private val selectedPersonality = mutableStateOf(personalities.first())
    private val generating = mutableStateOf(false)
    private val modelFilePicker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) importModel(uri)
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getPreferences(MODE_PRIVATE)
        val savedPath = prefs.getString("model_path", null)
        if (savedPath != null && File(savedPath).exists()) {
            modelState.value = ModelInfo(prefs.getString("model_name", File(savedPath).name) ?: File(savedPath).name, savedPath, prefs.getLong("model_size", File(savedPath).length()))
            statusState.value = "Model available. Tap Load model to put it into RAM."
        }
        setContent { VethosApp() }
    }

    private fun importModel(uri: Uri) {
        lifecycleScope.launch {
            statusState.value = "Copying model into app storage… keep the app open"
            try {
                val name = queryName(uri).ifBlank { "model.gguf" }
                if (!name.lowercase().endsWith(".gguf")) throw IllegalArgumentException("Please choose a .gguf model file.")
                val folder = File(filesDir, "models").apply { mkdirs() }
                val target = File(folder, name.replace(Regex("[^A-Za-z0-9._-]"), "_"))
                withContext(Dispatchers.IO) {
                    contentResolver.openInputStream(uri).use { input ->
                        requireNotNull(input) { "Unable to read selected file" }
                        FileOutputStream(target).use { output -> input.copyTo(output, 1024 * 1024) }
                    }
                }
                modelState.value = ModelInfo(name, target.absolutePath, target.length())
                getPreferences(MODE_PRIVATE).edit().putString("model_path", target.absolutePath).putString("model_name", name).putLong("model_size", target.length()).apply()
                statusState.value = "Model added. Tap Load model to put it into RAM."
                loadedState.value = false
            } catch (e: Exception) { statusState.value = "Import failed: ${e.message ?: "unknown error"}" }
        }
    }
    private fun queryName(uri: Uri): String {
        contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) return c.getString(0) ?: "model.gguf"
        }
        return "model.gguf"
    }
    private fun loadModel() {
        val model = modelState.value ?: run { statusState.value = "Add a GGUF model first"; return }
        lifecycleScope.launch {
            statusState.value = "Loading model… large models can take time"
            val ok = withContext(Dispatchers.IO) { runCatching { LlamaBridge.nativeLoad(model.path, (Runtime.getRuntime().availableProcessors() - 1).coerceAtLeast(2), 2048) }.getOrDefault(false) }
            loadedState.value = ok
            statusState.value = if (ok) "Model loaded · runs locally on this device" else "Could not load model. Check available RAM and choose a smaller GGUF (Q4_K_M recommended)."
        }
    }
    private fun unloadModel() { lifecycleScope.launch(Dispatchers.IO) { runCatching { LlamaBridge.nativeUnload() }; loadedState.value = false; statusState.value = "Model unloaded · RAM freed" } }
    private fun sendMessage(text: String) {
        val promptText = text.trim()
        if (promptText.isEmpty() || generating.value) return
        if (!loadedState.value) { statusState.value = "Load a model before sending messages"; screenState.value = "Models"; return }
        chatState.add(Message("user", promptText))
        generating.value = true
        val persona = selectedPersonality.value
        val history = chatState.takeLast(12).joinToString("\n") { if (it.role == "user") "User: ${it.text}" else "Assistant: ${it.text}" }
        val prompt = "<|im_start|>system\nYou are ${persona.name}, a private AI assistant running offline on a phone. Always answer in the same language as the user, including Roman Urdu if used. ${persona.prompt}\n<|im_end|>\n" + history + "\n<|im_start|>assistant\n"
        lifecycleScope.launch {
            val response = withContext(Dispatchers.IO) { runCatching { LlamaBridge.nativeGenerate(prompt, 512) }.getOrElse { "Generation failed: ${it.message}" } }
            chatState.add(Message("assistant", response.trim().ifEmpty { "(No text generated. Try a different GGUF model or prompt format.)" }))
            generating.value = false
        }
    }

    @Composable private fun VethosApp() {
        MaterialTheme(colorScheme = lightColorScheme(primary = Terracotta, background = Paper, surface = Card, onSurface = Ink)) {
            Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFFFFF9F5), Paper, Color(0xFFF7F3EC))))) {
                Column(Modifier.fillMaxSize()) {
                    Header(screenState.value, onBack = { screenState.value = "Home" }, onMenu = { screenState.value = "Home" })
                    Box(Modifier.weight(1f)) {
                        when (screenState.value) {
                            "Home" -> HomeScreen()
                            "Models" -> ModelsScreen()
                            "Personalities" -> PersonalitiesScreen()
                            "Settings" -> SettingsScreen()
                            "Insights" -> InsightsScreen()
                            "Chat" -> ChatScreen()
                            else -> HomeScreen()
                        }
                    }
                    if (screenState.value != "Chat") BottomNav(screenState.value) { screenState.value = it }
                }
            }
        }
    }
    @Composable private fun Header(title: String, onBack: () -> Unit, onMenu: () -> Unit) {
        Row(Modifier.fillMaxWidth().statusBarsPadding().height(62.dp).padding(horizontal = 18.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(42.dp).background(Card, CircleShape).clickable { if (title == "Home") onMenu() else onBack() }, contentAlignment = Alignment.Center) {
                Text(if (title == "Home") "☰" else "‹", color = Ink, fontSize = 24.sp)
            }
            Column(Modifier.weight(1f).padding(start = 12.dp)) {
                Text(if (title == "Home") "Vethos" else title, fontSize = 21.sp, fontWeight = FontWeight.Bold, color = Ink)
                if (title == "Home") Text("YOUR PRIVATE AI SPACE", fontSize = 9.sp, letterSpacing = 1.5.sp, color = Muted)
            }
            Box(Modifier.size(40.dp).background(Brush.linearGradient(listOf(Terracotta, Peach)), CircleShape), contentAlignment = Alignment.Center) {
                Text("V", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
    @Composable private fun HomeScreen() {
        LazyColumn(Modifier.fillMaxSize().padding(horizontal = 18.dp), contentPadding = PaddingValues(top = 10.dp, bottom = 22.dp)) {
            item {
                Text("A LITTLE MORE\nPOSSIBILITY.", fontSize = 31.sp, lineHeight = 35.sp, fontWeight = FontWeight.Bold, color = Ink, modifier = Modifier.padding(top = 16.dp))
                Text("What can we do for you today?", color = Muted, fontSize = 14.sp, modifier = Modifier.padding(top = 8.dp, bottom = 20.dp))
                Column(Modifier.fillMaxWidth().background(Brush.linearGradient(listOf(Color(0xFFB4512F), Color(0xFFE08A5F))), RoundedCornerShape(28.dp)).padding(20.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("✦  YOUR LOCAL AI", color = Color.White.copy(alpha = .86f), fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                        Spacer(Modifier.weight(1f)); Text(if (loadedState.value) "● LIVE" else "● READY", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }
                    Text(modelState.value?.name ?: "Meet your AI model", color = Color.White, fontSize = 21.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 18.dp))
                    Text(if (loadedState.value) "Active · loaded into RAM" else if (modelState.value == null) "A private assistant that lives on your device." else statusState.value, color = Color.White.copy(alpha = .88f), fontSize = 13.sp, lineHeight = 19.sp, modifier = Modifier.padding(top = 6.dp, bottom = 17.dp))
                    Button(onClick = { if (modelState.value == null) modelFilePicker.launch(arrayOf("*/*")) else screenState.value = if (loadedState.value) "Chat" else "Models" }, shape = RoundedCornerShape(50), colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Terracotta), contentPadding = PaddingValues(horizontal = 20.dp, vertical = 11.dp)) {
                        Text(if (modelState.value == null) "Choose GGUF model  →" else if (loadedState.value) "Start a conversation  →" else "Manage your model  →", fontWeight = FontWeight.Bold)
                    }
                }
                SectionTitle("Choose your assistant")
            }
            items(personalities) { p -> RowCard(p.name, p.desc, selectedPersonality.value.id == p.id) { selectedPersonality.value = p; screenState.value = if (loadedState.value) "Chat" else "Models" } }
            item { Text("PRIVATE BY DESIGN  ·  NO ACCOUNT REQUIRED", color = Muted, fontSize = 10.sp, letterSpacing = 1.sp, modifier = Modifier.padding(top = 12.dp, bottom = 10.dp)) }
        }
    }
    @Composable private fun ModelsScreen() {
        LazyColumn(Modifier.fillMaxSize().padding(horizontal = 18.dp), contentPadding = PaddingValues(vertical = 16.dp)) {
            item {
                SectionTitle("Your on-device model")
                CardBox {
                    Text("Local GGUF model", fontSize = 19.sp, fontWeight = FontWeight.Bold)
                    Text(modelState.value?.name ?: "No model selected", modifier = Modifier.padding(top = 12.dp), fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                    Text(modelState.value?.let { "${formatBytes(it.size)} · stored privately on this device" } ?: "Choose a .gguf file from your phone storage.", color = Muted, fontSize = 13.sp, modifier = Modifier.padding(top = 5.dp, bottom = 16.dp))
                    DarkButton("＋  Add model from phone storage") { modelFilePicker.launch(arrayOf("*/*")) }
                    Spacer(Modifier.height(9.dp))
                    if (!loadedState.value) LightButton("Load model into RAM", enabled = modelState.value != null) { loadModel() } else LightButton("Unload model · free RAM") { unloadModel() }
                }
                Text(statusState.value, color = Muted, fontSize = 13.sp, modifier = Modifier.padding(12.dp))
                SectionTitle("Helpful tips")
                CardBox { Text("• Start with a 1B–3B Q4_K_M GGUF on phones.\n\n• Loading requires enough free RAM; close other apps first.\n\n• The app copies the selected file into private storage.\n\n• Split GGUF files are not supported in this build.\n\n• Once loaded, text generation works offline.", color = Muted, fontSize = 13.sp, lineHeight = 21.sp) }
            }
        }
    }
    @Composable private fun PersonalitiesScreen() {
        LazyColumn(Modifier.fillMaxSize().padding(horizontal = 18.dp), contentPadding = PaddingValues(vertical = 14.dp)) {
            item { Text("Pick the personality that fits your moment.", color = Muted, fontSize = 14.sp, modifier = Modifier.padding(bottom = 14.dp)) }
            items(personalities) { p -> RowCard(p.name, p.desc, selectedPersonality.value.id == p.id) { selectedPersonality.value = p } }
        }
    }
    @Composable private fun SettingsScreen() {
        Column(Modifier.fillMaxSize().padding(18.dp)) {
            SectionTitle("About Vethos")
            CardBox { Text("Vethos", fontSize = 22.sp, fontWeight = FontWeight.Bold); Text("Native Android · on-device inference", color = Muted, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp)) }
            SectionTitle("Privacy & security")
            CardBox { Text("Your conversations stay yours.", fontWeight = FontWeight.SemiBold); Text("Prompts and responses are processed on-device after the model is loaded. No telemetry or account system is included in this project.", color = Muted, fontSize = 13.sp, lineHeight = 20.sp, modifier = Modifier.padding(top = 8.dp)) }
            Spacer(Modifier.height(14.dp)); LightButton("Unload model and free RAM", enabled = loadedState.value) { unloadModel() }
        }
    }
    @Composable private fun InsightsScreen() {
        Column(Modifier.fillMaxSize().padding(18.dp)) {
            Text("Your device,\nyour intelligence.", fontSize = 28.sp, lineHeight = 33.sp, fontWeight = FontWeight.Bold)
            SectionTitle("Performance overview")
            CardBox {
                StatRow("Inference engine", "llama.cpp · CPU"); HorizontalDivider(color = Line)
                StatRow("Model", modelState.value?.name ?: "None selected"); HorizontalDivider(color = Line)
                StatRow("Status", if (loadedState.value) "Loaded" else "Not loaded"); HorizontalDivider(color = Line)
                StatRow("Model size", modelState.value?.let { formatBytes(it.size) } ?: "—")
            }
        }
    }
    @Composable private fun ChatScreen() {
        val focus = LocalFocusManager.current
        var input by remember { mutableStateOf("") }
        Column(Modifier.fillMaxSize()) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(38.dp).background(Brush.linearGradient(listOf(Terracotta, Peach)), CircleShape), contentAlignment = Alignment.Center) { Text("V", color = Color.White, fontWeight = FontWeight.Bold) }
                Column(Modifier.weight(1f).padding(start = 10.dp)) { Text(selectedPersonality.value.name, fontWeight = FontWeight.Bold); Text(if (loadedState.value) "●  On-device · private" else "Model not loaded", color = Muted, fontSize = 11.sp) }
                Text("Change", color = Terracotta, fontWeight = FontWeight.SemiBold, modifier = Modifier.clickable { screenState.value = "Personalities" }.padding(8.dp))
            }
            HorizontalDivider(color = Line)
            if (chatState.isEmpty()) {
                Column(Modifier.fillMaxWidth().weight(1f).padding(26.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
                    Box(Modifier.size(76.dp).background(Brush.linearGradient(listOf(Peach, Terracotta)), CircleShape), contentAlignment = Alignment.Center) { Text("✦", color = Color.White, fontSize = 34.sp) }
                    Text("How can I help?", fontSize = 25.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 18.dp))
                    Text("Ask anything. Your conversation stays on this device.", color = Muted, fontSize = 13.sp, modifier = Modifier.padding(top = 8.dp))
                }
            } else LazyColumn(Modifier.weight(1f).fillMaxWidth().padding(horizontal = 16.dp), contentPadding = PaddingValues(vertical = 12.dp)) {
                items(chatState) { msg ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (msg.role == "user") Arrangement.End else Arrangement.Start) {
                        Column(Modifier.padding(vertical = 5.dp).widthIn(max = 330.dp).background(if (msg.role == "user") Terracotta else Card, if (msg.role == "user") RoundedCornerShape(topStart = 22.dp, bottomStart = 22.dp, bottomEnd = 22.dp) else RoundedCornerShape(topEnd = 22.dp, bottomStart = 22.dp, bottomEnd = 22.dp)).padding(15.dp)) {
                            Text(if (msg.role == "user") "YOU" else "VETHOS", fontSize = 9.sp, color = if (msg.role == "user") Color.White.copy(alpha = .75f) else Muted, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                            Spacer(Modifier.height(5.dp)); Text(msg.text, color = if (msg.role == "user") Color.White else Ink, fontSize = 15.sp, lineHeight = 22.sp)
                        }
                    }
                }
                if (generating.value) item { Text("Vethos is thinking…", color = Muted, modifier = Modifier.padding(12.dp)) }
            }
            Column(Modifier.fillMaxWidth().background(Paper).navigationBarsPadding().padding(horizontal = 12.dp, vertical = 8.dp)) {
                Row(Modifier.fillMaxWidth().background(Card, RoundedCornerShape(30.dp)).padding(7.dp), verticalAlignment = Alignment.Bottom) {
                    BasicTextField(value = input, onValueChange = { input = it }, modifier = Modifier.weight(1f).padding(horizontal = 12.dp, vertical = 12.dp), textStyle = androidx.compose.ui.text.TextStyle(color = Ink, fontSize = 15.sp), minLines = 1, maxLines = 5, keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send), keyboardActions = KeyboardActions(onSend = { focus.clearFocus(); sendMessage(input); input = "" }), decorationBox = { inner -> if (input.isEmpty()) Text("Message Vethos…", color = Muted); inner() })
                    Box(Modifier.size(44.dp).background(Terracotta, CircleShape).clickable { sendMessage(input); input = "" }, contentAlignment = Alignment.Center) { Text("↑", fontSize = 24.sp, color = Color.White, fontWeight = FontWeight.Bold) }
                }
                Text("✧  AI can make mistakes · runs locally", color = Muted, fontSize = 10.sp, modifier = Modifier.align(Alignment.CenterHorizontally).padding(top = 7.dp))
            }
        }
    }
    @Composable private fun BottomNav(current: String, onSelect: (String) -> Unit) {
        Row(Modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal = 15.dp, vertical = 9.dp).height(66.dp).background(Card, RoundedCornerShape(50.dp)).padding(5.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            listOf("Home" to "⌂", "Models" to "▦", "Personalities" to "✧", "Insights" to "▥", "Settings" to "⚙").forEach { (label, icon) ->
                val active = current == label
                Row(Modifier.weight(if (active) 1.7f else 1f).fillMaxHeight().background(if (active) Terracotta else Color.Transparent, CircleShape).clickable { onSelect(label) }.padding(horizontal = 5.dp), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
                    Text(icon, color = if (active) Color.White else Muted, fontSize = 19.sp)
                    if (active) Text(label, color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(start = 5.dp), maxLines = 1)
                }
            }
        }
    }
    @Composable private fun CardBox(content: @Composable ColumnScope.() -> Unit) {
        Column(Modifier.fillMaxWidth().background(Card, RoundedCornerShape(24.dp)).padding(18.dp), content = content)
    }
    @Composable private fun DarkButton(label: String, onClick: () -> Unit) {
        Button(onClick = onClick, modifier = Modifier.fillMaxWidth().height(49.dp), shape = RoundedCornerShape(50.dp), colors = ButtonDefaults.buttonColors(containerColor = Terracotta, contentColor = Color.White), elevation = ButtonDefaults.buttonElevation(defaultElevation = 5.dp)) { Text(label, fontWeight = FontWeight.SemiBold) }
    }
    @Composable private fun LightButton(label: String, enabled: Boolean = true, onClick: () -> Unit) {
        OutlinedButton(onClick = onClick, enabled = enabled, modifier = Modifier.fillMaxWidth().height(48.dp), shape = RoundedCornerShape(50.dp), border = androidx.compose.foundation.BorderStroke(1.dp, Line), colors = ButtonDefaults.outlinedButtonColors(contentColor = Ink)) { Text(label, fontWeight = FontWeight.SemiBold) }
    }
    @Composable private fun SectionTitle(title: String) { Text(title.uppercase(), fontSize = 11.sp, letterSpacing = 1.2.sp, color = Muted, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 22.dp, bottom = 11.dp)) }
    @Composable private fun RowCard(title: String, subtitle: String, selected: Boolean = false, onClick: () -> Unit) {
        Row(Modifier.fillMaxWidth().padding(bottom = 9.dp).background(Card, RoundedCornerShape(22.dp)).clickable(onClick = onClick).padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(44.dp).background(if (selected) Color(0xFFFBEDE6) else Color(0xFFF3EFE8), RoundedCornerShape(15.dp)), contentAlignment = Alignment.Center) { Text(title.take(1), color = Terracotta, fontWeight = FontWeight.Bold, fontSize = 17.sp) }
            Column(Modifier.weight(1f).padding(start = 12.dp)) { Text(title, fontWeight = FontWeight.SemiBold, fontSize = 14.sp, color = Ink); Text(subtitle, color = Muted, fontSize = 12.sp, lineHeight = 16.sp, modifier = Modifier.padding(top = 3.dp)) }
            if (selected) Text("✓", color = Terracotta, fontWeight = FontWeight.Bold, fontSize = 18.sp)
            else Text("›", color = Muted, fontSize = 23.sp)
        }
    }
    @Composable private fun StatRow(label: String, value: String) { Row(Modifier.fillMaxWidth().padding(vertical = 13.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) { Text(label, color = Muted, fontSize = 13.sp); Text(value, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = Ink) } }
    private fun formatBytes(bytes: Long): String = if (bytes >= 1_000_000_000) "%.2f GB".format(bytes / 1_000_000_000.0) else "%.0f MB".format(bytes / 1_000_000.0)
}
