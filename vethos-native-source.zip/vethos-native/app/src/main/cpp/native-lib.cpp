#include <jni.h>
#include <string>
#include <vector>
#include <mutex>
#include <android/log.h>
#include "llama.h"

#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, "VethosLlama", __VA_ARGS__)
static std::mutex g_mutex;
static llama_model *g_model = nullptr;
static llama_context *g_ctx = nullptr;
static llama_sampler *g_sampler = nullptr;
static int g_n_past = 0;

static std::string jstr(JNIEnv *env, jstring s) {
    if (!s) return {};
    const char *p = env->GetStringUTFChars(s, nullptr);
    std::string out = p ? p : "";
    if (p) env->ReleaseStringUTFChars(s, p);
    return out;
}
static std::vector<llama_token> tokenize(const std::string &text, bool add_bos) {
    const llama_vocab *vocab = llama_model_get_vocab(g_model);
    int n = llama_tokenize(vocab, text.c_str(), (int)text.size(), nullptr, 0, add_bos, true);
    if (n >= 0) n = -n;
    std::vector<llama_token> tokens((size_t)(-n));
    int actual = llama_tokenize(vocab, text.c_str(), (int)text.size(), tokens.data(), (int)tokens.size(), add_bos, true);
    if (actual < 0) { tokens.resize((size_t)(-actual)); llama_tokenize(vocab, text.c_str(), (int)text.size(), tokens.data(), (int)tokens.size(), add_bos, true); }
    else tokens.resize((size_t)actual);
    return tokens;
}
extern "C" JNIEXPORT jstring JNICALL Java_com_vethos_app_LlamaBridge_nativeVersion(JNIEnv *env, jobject) {
    return env->NewStringUTF("llama.cpp native backend");
}
extern "C" JNIEXPORT jboolean JNICALL Java_com_vethos_app_LlamaBridge_nativeLoad(JNIEnv *env, jobject, jstring path, jint threads, jint context) {
    std::lock_guard<std::mutex> lock(g_mutex);
    if (g_sampler) { llama_sampler_free(g_sampler); g_sampler = nullptr; }
    if (g_ctx) { llama_free(g_ctx); g_ctx = nullptr; }
    if (g_model) { llama_model_free(g_model); g_model = nullptr; }
    llama_backend_init();
    llama_model_params mp = llama_model_default_params();
    mp.n_gpu_layers = 0;
    const std::string p = jstr(env, path);
    g_model = llama_model_load_from_file(p.c_str(), mp);
    if (!g_model) { LOGE("model load failed: %s", p.c_str()); return JNI_FALSE; }
    llama_context_params cp = llama_context_default_params();
    cp.n_ctx = (uint32_t)context;
    cp.n_batch = 512;
    cp.n_threads = threads > 0 ? threads : 4;
    cp.n_threads_batch = cp.n_threads;
    g_ctx = llama_init_from_model(g_model, cp);
    if (!g_ctx) { llama_model_free(g_model); g_model = nullptr; return JNI_FALSE; }
    g_sampler = llama_sampler_chain_init(llama_sampler_chain_default_params());
    llama_sampler_chain_add(g_sampler, llama_sampler_init_top_k(40));
    llama_sampler_chain_add(g_sampler, llama_sampler_init_top_p(0.9f, 1));
    llama_sampler_chain_add(g_sampler, llama_sampler_init_temp(0.7f));
    llama_sampler_chain_add(g_sampler, llama_sampler_init_dist(LLAMA_DEFAULT_SEED));
    g_n_past = 0;
    return JNI_TRUE;
}
extern "C" JNIEXPORT void JNICALL Java_com_vethos_app_LlamaBridge_nativeUnload(JNIEnv *, jobject) {
    std::lock_guard<std::mutex> lock(g_mutex);
    if (g_sampler) { llama_sampler_free(g_sampler); g_sampler = nullptr; }
    if (g_ctx) { llama_free(g_ctx); g_ctx = nullptr; }
    if (g_model) { llama_model_free(g_model); g_model = nullptr; }
    g_n_past = 0;
}
extern "C" JNIEXPORT jstring JNICALL Java_com_vethos_app_LlamaBridge_nativeGenerate(JNIEnv *env, jobject, jstring prompt, jint maxTokens) {
    std::lock_guard<std::mutex> lock(g_mutex);
    if (!g_model || !g_ctx || !g_sampler) return env->NewStringUTF("[No model loaded. Open Models and load a GGUF file.]");
    llama_memory_clear(llama_get_memory(g_ctx), true);
    g_n_past = 0;
    std::string input = jstr(env, prompt);
    auto toks = tokenize(input, true);
    if (toks.empty()) return env->NewStringUTF("");
    llama_batch batch = llama_batch_get_one(toks.data(), (int)toks.size());
    if (llama_decode(g_ctx, batch) != 0) return env->NewStringUTF("[Prompt too long or insufficient memory. Try a smaller context/model.]");
    std::string output;
    const llama_vocab *vocab = llama_model_get_vocab(g_model);
    for (int i = 0; i < maxTokens; ++i) {
        llama_token token = llama_sampler_sample(g_sampler, g_ctx, -1);
        if (llama_vocab_is_eog(vocab, token)) break;
        char piece[4096];
        int n = llama_token_to_piece(vocab, token, piece, sizeof(piece), 0, true);
        if (n > 0) output.append(piece, (size_t)n);
        llama_sampler_accept(g_sampler, token);
        llama_token next = token;
        llama_batch b = llama_batch_get_one(&next, 1);
        if (llama_decode(g_ctx, b) != 0) break;
    }
    return env->NewStringUTF(output.c_str());
}
