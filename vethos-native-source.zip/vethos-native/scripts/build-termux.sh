#!/data/data/com.termux/files/usr/bin/bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
if [ ! -d app/src/main/cpp/llama.cpp ]; then bash scripts/fetch-llama.sh; fi
if ! command -v gradle >/dev/null 2>&1; then
  echo "Gradle is missing. Run: pkg install gradle openjdk-17 git cmake ninja ndk-sysroot"
  exit 1
fi
if [ -z "${ANDROID_HOME:-}" ] && [ -d "$HOME/android-sdk" ]; then export ANDROID_HOME="$HOME/android-sdk"; fi
if [ -z "${ANDROID_HOME:-}" ]; then
  echo "ANDROID_HOME is not set. Install Android SDK/NDK and set ANDROID_HOME first."
  echo "Example: export ANDROID_HOME=\$HOME/android-sdk"
  exit 1
fi
gradle --no-daemon assembleDebug
APK="$ROOT/app/build/outputs/apk/debug/app-debug.apk"
if [ -f "$APK" ]; then
  mkdir -p "$ROOT/output"
  cp "$APK" "$ROOT/output/Vethos-debug.apk"
  echo "APK created: $ROOT/output/Vethos-debug.apk"
fi
