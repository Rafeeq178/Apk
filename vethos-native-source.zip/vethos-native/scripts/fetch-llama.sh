#!/data/data/com.termux/files/usr/bin/bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
DEST="$ROOT/app/src/main/cpp/llama.cpp"
if [ -d "$DEST/.git" ]; then
  git -C "$DEST" fetch --depth=1 origin master
  git -C "$DEST" checkout FETCH_HEAD
else
  rm -rf "$DEST"
  git clone --depth 1 https://github.com/ggml-org/llama.cpp.git "$DEST"
fi
echo "llama.cpp source ready: $DEST"
