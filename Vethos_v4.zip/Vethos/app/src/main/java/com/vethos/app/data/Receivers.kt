package com.vethos.app.data

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.vethos.app.ui.MainActivity
import com.vethos.app.ui.RemindersActivity

object Notify {
    private const val CH_REM = "reminders"
    private const val CH_BRIEF = "brief"

    private fun channels(ctx: Context) {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH_REM, "Reminders", NotificationManager.IMPORTANCE_HIGH))
        nm.createNotificationChannel(NotificationChannel(CH_BRIEF, "Daily brief", NotificationManager.IMPORTANCE_DEFAULT))
    }

    private fun open(ctx: Context, cls: Class<*>, code: Int): PendingIntent =
        PendingIntent.getActivity(
            ctx, code,
            Intent(ctx, cls).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

    private fun post(ctx: Context, id: Int, n: android.app.Notification) {
        try { NotificationManagerCompat.from(ctx).notify(id, n) } catch (_: SecurityException) { }
    }

    fun reminder(ctx: Context, r: Reminder, missed: Boolean = false) {
        channels(ctx)
        val n = NotificationCompat.Builder(ctx, CH_REM)
            .setSmallIcon(android.R.drawable.ic_popup_reminder)
            .setContentTitle(if (missed) "Missed reminder" else "Reminder")
            .setContentText(r.text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(r.text))
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_REMINDER)
            .setContentIntent(open(ctx, RemindersActivity::class.java, 2))
            .build()
        post(ctx, 2000 + r.id, n)
    }

    fun brief(ctx: Context, text: String) {
        channels(ctx)
        val n = NotificationCompat.Builder(ctx, CH_BRIEF)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("Your daily brief")
            .setContentText(text.lineSequence().firstOrNull { it.isNotBlank() } ?: "Good day!")
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setAutoCancel(true)
            .setContentIntent(open(ctx, MainActivity::class.java, 3))
            .build()
        post(ctx, 3000, n)
    }
}

/** Fires reminders and the daily brief. Not exported: only this app can trigger it. */
class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        try {
            when (intent.action) {
                Scheduler.ACTION_REMIND -> {
                    val r = RemindersRepo.get(intent.getIntExtra("id", -1)) ?: return
                    if (r.done) return
                    Notify.reminder(ctx, r)
                    RemindersRepo.markDone(r.id)
                }
                Scheduler.ACTION_BRIEF -> {
                    if (Store.briefOn) {
                        Notify.brief(ctx, Brief.build())
                        Scheduler.scheduleBrief()
                    }
                }
            }
        } catch (_: Throwable) { }
    }
}

/** Android forgets alarms after a reboot or an app update: set them again. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        val a = intent.action
        if (a == Intent.ACTION_BOOT_COMPLETED || a == Intent.ACTION_MY_PACKAGE_REPLACED) {
            try { Scheduler.rescheduleAll() } catch (_: Throwable) { }
        }
    }
}
