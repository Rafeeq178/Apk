package com.vethos.app.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.ViewGroup
import android.widget.LinearLayout
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.vethos.app.R
import com.vethos.app.data.Note
import com.vethos.app.data.NotesRepo

class NotesActivity : AppCompatActivity() {
    private lateinit var s: Screen
    private lateinit var list: LinearLayout
    private var query = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        s = Screen(this, "Notes", listOf<Pair<Int, () -> Unit>>(R.drawable.ic_plus to { edit(null) }))
        val search = s.input("Search notes")
        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(c: CharSequence?, a: Int, b: Int, d: Int) {}
            override fun onTextChanged(c: CharSequence?, a: Int, b: Int, d: Int) {}
            override fun afterTextChanged(e: Editable?) { query = e?.toString() ?: ""; render() }
        })
        s.body.addView(search, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(4) })
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        s.body.addView(list, LinearLayout.LayoutParams(-1, -2))
    }

    override fun onResume() { super.onResume(); render() }

    private fun render() {
        list.removeAllViews()
        val notes = NotesRepo.search(query)
        if (notes.isEmpty()) {
            list.addView(android.widget.TextView(this).apply {
                text = if (query.isBlank()) "No notes yet. Tap + or type  /note your text  in a chat." else "No note matches your search."
                setTextColor(getColor(R.color.v_muted)); textSize = 14.5f
                setPadding(dp(6), dp(18), dp(6), 0)
            })
            return
        }
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundResource(R.drawable.bg_card)
            elevation = dp(1).toFloat()
        }
        list.addView(card, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(12) })
        // reuse Screen.row so the look is identical: it adds to the given card
        notes.forEach { n ->
            s.row(card, if (n.pinned) R.drawable.ic_pin else R.drawable.ic_book, n.title,
                n.body.replace('\n', ' ').take(140) + "\n" + fmtDate(n.ts), onLong = { menu(n) }) { edit(n) }
        }
    }

    private fun edit(n: Note?) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(8), dp(22), 0)
        }
        val title = s.input("Title (optional)")
        val body = s.input("Write your note", multiline = true)
        title.setText(n?.title ?: ""); body.setText(n?.body ?: "")
        box.addView(title, ViewGroup.LayoutParams(-1, -2))
        box.addView(body, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })
        val dlg = MaterialAlertDialogBuilder(this)
            .setTitle(if (n == null) "New note" else "Edit note")
            .setView(box)
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Save") { _, _ ->
                val b = body.text.toString()
                if (b.isBlank() && title.text.isBlank()) { toast("Nothing to save"); return@setPositiveButton }
                if (n == null) NotesRepo.add(title.text.toString(), b) else NotesRepo.update(n, title.text.toString(), b)
                render()
            }
        dlg.show()
    }

    private fun menu(n: Note) {
        showSheet(n.title, listOf(
            SheetRow(R.drawable.ic_edit, "Edit") { edit(n) },
            SheetRow(R.drawable.ic_pin, if (n.pinned) "Unpin" else "Pin to top") { NotesRepo.setPinned(n, !n.pinned); render() },
            SheetRow(R.drawable.ic_chat, "Use in a chat") {
                startActivity(Intent(this, ChatActivity::class.java).putExtra("preset", n.body.take(1500)))
            },
            SheetRow(R.drawable.ic_copy, "Copy") {
                (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("Note", n.body))
                toast("Copied")
            },
            SheetRow(R.drawable.ic_share, "Share") {
                startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, n.body), "Share"))
            },
            SheetRow(R.drawable.ic_trash, "Delete") { confirm("Delete note?", n.title, "Delete") { NotesRepo.delete(n.id); render() } },
        ))
    }
}
