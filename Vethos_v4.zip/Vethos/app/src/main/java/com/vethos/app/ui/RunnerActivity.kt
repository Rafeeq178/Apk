package com.vethos.app.ui

import android.annotation.SuppressLint
import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.InputFilter
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.webkit.ConsoleMessage
import android.webkit.JsPromptResult
import android.webkit.JsResult
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebStorage
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.vethos.app.R
import com.vethos.app.data.Assemble
import com.vethos.app.data.AppsRepo
import com.vethos.app.data.Templates
import com.vethos.app.data.WebApp
import org.json.JSONObject
import java.io.ByteArrayInputStream

/**
 * Offline HTML/CSS/JS runner. The page runs in a WebView with NO network and NO bridge to the app,
 * so code from an AI answer can not reach your files, contacts or the internet.
 */
class RunnerActivity : AppCompatActivity() {
    private lateinit var s: Screen
    private lateinit var web: WebView
    private lateinit var editor: EditText
    private lateinit var editorBox: View
    private lateinit var previewBox: View
    private lateinit var consoleScroll: ScrollView
    private lateinit var consoleText: TextView
    private lateinit var consoleBtn: TextView
    private val modeBtns = ArrayList<TextView>()

    private var app: WebApp? = null
    private var dirty = false
    private var live = true
    private var mode = 1 // 0 code, 1 split, 2 preview
    private var errors = 0
    private val logs = ArrayList<String>()
    @Volatile private var curBase = "https://scratch.vethos.local/"
    private val handler = Handler(Looper.getMainLooper())
    private val reload = Runnable { run() }

    private val export = registerForActivityResult(ActivityResultContracts.CreateDocument("text/html")) { uri ->
        if (uri != null) writeTextUri(uri, editor.text.toString())
    }

    private val back = object : OnBackPressedCallback(true) {
        override fun handleOnBackPressed() {
            if (!dirty) { finish(); return }
            MaterialAlertDialogBuilder(this@RunnerActivity)
                .setTitle("Unsaved changes")
                .setMessage("Save this app before leaving?")
                .setPositiveButton("Save") { _, _ -> save { finish() } }
                .setNegativeButton("Discard") { _, _ -> finish() }
                .setNeutralButton("Cancel", null)
                .show()
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        app = AppsRepo.get(intent.getStringExtra("id"))
        val fromChat = handoff
        handoff = null
        val code = savedInstanceState?.getString("code") ?: app?.html ?: fromChat ?: Templates.BLANK
        dirty = savedInstanceState?.getBoolean("dirty") ?: false

        s = Screen(this, app?.name ?: "New app", listOf<Pair<Int, () -> Unit>>(
            R.drawable.ic_play to { run() },
            R.drawable.ic_check to { save() },
            R.drawable.ic_more to { menu() },
        ), scrolls = false)
        onBackPressedDispatcher.addCallback(this, back)

        // mode switch + console button
        val bar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        listOf("Code", "Split", "Preview").forEachIndexed { i, label ->
            val t = TextView(this).apply {
                text = label
                gravity = Gravity.CENTER
                textSize = 14f
                typeface = Typeface.DEFAULT_BOLD
                setOnClickListener { setMode(i) }
            }
            modeBtns.add(t)
            bar.addView(t, LinearLayout.LayoutParams(0, dp(38), 1f).apply { marginEnd = dp(6) })
        }
        consoleBtn = TextView(this).apply {
            text = "Console"
            gravity = Gravity.CENTER
            textSize = 14f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(getColor(R.color.v_text2))
            setBackgroundResource(R.drawable.bg_chip)
            setPadding(dp(14), 0, dp(14), 0)
            setOnClickListener {
                consoleScroll.visibility = if (consoleScroll.visibility == View.VISIBLE) View.GONE else View.VISIBLE
            }
        }
        bar.addView(consoleBtn, LinearLayout.LayoutParams(-2, dp(38)))
        s.body.addView(bar, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })

        // preview + console
        web = WebView(this)
        val box = FrameLayout(this)
        box.addView(web, FrameLayout.LayoutParams(-1, -1))
        consoleText = TextView(this).apply {
            setTextColor(getColor(R.color.v_code_text))
            textSize = 12f
            typeface = Typeface.MONOSPACE
            setPadding(dp(10), dp(8), dp(10), dp(8))
            setTextIsSelectable(true)
        }
        consoleScroll = ScrollView(this).apply {
            setBackgroundColor(getColor(R.color.v_code_bg))
            visibility = View.GONE
            addView(consoleText)
        }
        box.addView(consoleScroll, FrameLayout.LayoutParams(-1, dp(150), Gravity.BOTTOM))
        previewBox = box
        s.body.addView(box, LinearLayout.LayoutParams(-1, 0, 1f))

        // editor
        editor = EditText(this).apply {
            isSaveEnabled = false
            setBackgroundResource(R.drawable.bg_code)
            setTextColor(getColor(R.color.v_code_text))
            setHintTextColor(getColor(R.color.v_code_muted))
            hint = "Write HTML, CSS and JavaScript here"
            typeface = Typeface.MONOSPACE
            textSize = 13f
            gravity = Gravity.TOP or Gravity.START
            setPadding(dp(12), dp(12), dp(12), dp(12))
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
            filters = arrayOf(InputFilter.LengthFilter(MAX_CODE))
            setText(code)
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(c: CharSequence?, a: Int, b: Int, d: Int) {}
                override fun onTextChanged(c: CharSequence?, a: Int, b: Int, d: Int) {}
                override fun afterTextChanged(e: Editable?) {
                    dirty = true
                    if (live) { handler.removeCallbacks(reload); handler.postDelayed(reload, 700) }
                }
            })
        }
        editorBox = editor
        s.body.addView(editor, LinearLayout.LayoutParams(-1, 0, 1f).apply { topMargin = dp(8) })

        setupWeb()
        setMode(1)
        // setText above marked the editor dirty; a fresh open is not a change
        dirty = savedInstanceState?.getBoolean("dirty") ?: false
        run()
    }

    private fun applyBase() {
        curBase = "https://" + (app?.id ?: "scratch") + ".vethos.local/"
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupWeb() {
        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = false
            allowContentAccess = false
            blockNetworkLoads = true
            javaScriptCanOpenWindowsAutomatically = false
            setSupportZoom(true)
            builtInZoomControls = true
            displayZoomControls = false
            setGeolocationEnabled(false)
        }
        web.setBackgroundColor(Color.WHITE)
        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? {
                val sc = request.url.scheme ?: ""
                if (sc == "data" || sc == "blob" || sc == "about") return null
                val u = request.url.toString()
                if (!u.endsWith("/favicon.ico")) handler.post { addLog("\u26D4 Blocked (runner is offline): $u") }
                return WebResourceResponse("text/plain", "utf-8", 403, "Blocked", emptyMap(), ByteArrayInputStream(ByteArray(0)))
            }

            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val u = request.url.toString()
                if (u.startsWith(curBase) && u.contains('#')) {
                    view.evaluateJavascript("location.hash=" + JSONObject.quote(u.substringAfter('#')), null)
                } else if (request.hasGesture()) {
                    toast("Links are blocked: the runner is offline")
                }
                return true
            }
        }
        web.webChromeClient = object : WebChromeClient() {
            override fun onConsoleMessage(m: ConsoleMessage): Boolean {
                val lvl = m.messageLevel()
                val tag = when (lvl) {
                    ConsoleMessage.MessageLevel.ERROR -> "\u2716"
                    ConsoleMessage.MessageLevel.WARNING -> "\u26A0"
                    else -> "\u203A"
                }
                if (lvl == ConsoleMessage.MessageLevel.ERROR) errors++
                addLog("$tag ${m.message()}" + if (m.lineNumber() > 0) "  (line ${m.lineNumber()})" else "")
                return true
            }

            override fun onJsAlert(view: WebView, url: String?, message: String?, result: JsResult): Boolean {
                if (isFinishing) { result.cancel(); return true }
                MaterialAlertDialogBuilder(this@RunnerActivity).setMessage(message)
                    .setPositiveButton("OK") { _, _ -> result.confirm() }
                    .setOnCancelListener { result.cancel() }.show()
                return true
            }

            override fun onJsConfirm(view: WebView, url: String?, message: String?, result: JsResult): Boolean {
                if (isFinishing) { result.cancel(); return true }
                MaterialAlertDialogBuilder(this@RunnerActivity).setMessage(message)
                    .setPositiveButton("OK") { _, _ -> result.confirm() }
                    .setNegativeButton("Cancel") { _, _ -> result.cancel() }
                    .setOnCancelListener { result.cancel() }.show()
                return true
            }

            override fun onJsPrompt(view: WebView, url: String?, message: String?, defaultValue: String?, result: JsPromptResult): Boolean {
                if (isFinishing) { result.cancel(); return true }
                val et = EditText(this@RunnerActivity).apply { setText(defaultValue ?: "") }
                MaterialAlertDialogBuilder(this@RunnerActivity).setMessage(message).setView(et)
                    .setPositiveButton("OK") { _, _ -> result.confirm(et.text.toString()) }
                    .setNegativeButton("Cancel") { _, _ -> result.cancel() }
                    .setOnCancelListener { result.cancel() }.show()
                return true
            }
        }
    }

    private fun addLog(line: String) {
        logs.add(line)
        if (logs.size > 200) logs.removeAt(0)
        consoleText.text = logs.joinToString("\n")
        consoleScroll.post { consoleScroll.fullScroll(View.FOCUS_DOWN) }
        refreshConsoleBtn()
    }

    private fun refreshConsoleBtn() {
        consoleBtn.text = if (errors > 0) "Console ($errors \u2716)" else "Console"
        consoleBtn.setTextColor(getColor(if (errors > 0) R.color.v_danger else R.color.v_text2))
    }

    private fun run() {
        handler.removeCallbacks(reload)
        applyBase()
        logs.clear(); errors = 0
        consoleText.text = ""
        refreshConsoleBtn()
        web.loadDataWithBaseURL(curBase, Assemble.document(editor.text.toString()), "text/html", "UTF-8", null)
    }

    private fun setMode(m: Int) {
        mode = m
        previewBox.visibility = if (m == 0) View.GONE else View.VISIBLE
        editorBox.visibility = if (m == 2) View.GONE else View.VISIBLE
        modeBtns.forEachIndexed { i, t ->
            val on = i == m
            t.setBackgroundResource(if (on) R.drawable.bg_chip_on else R.drawable.bg_chip)
            t.setTextColor(getColor(if (on) R.color.white else R.color.v_text2))
        }
        if (m != 0) run()
    }

    private fun save(after: (() -> Unit)? = null) {
        val code = editor.text.toString()
        val cur = app
        if (cur != null) {
            cur.html = code
            AppsRepo.save(cur)
            dirty = false
            toast("Saved")
            after?.invoke()
        } else {
            inputDialog("Name your app", "My app", "App name") { n ->
                val a = AppsRepo.create(n.trim().ifEmpty { "My app" }.take(60), code)
                app = a
                s.titleView.text = a.name
                dirty = false
                toast("Saved to Apps")
                after?.invoke()
            }
        }
    }

    private fun menu() {
        val cur = app
        val rows = ArrayList<SheetRow>()
        rows.add(SheetRow(R.drawable.ic_edit, if (cur == null) "Name and save" else "Rename") {
            if (cur == null) save() else inputDialog("Rename app", cur.name, "App name") { n ->
                val nn = n.trim()
                if (nn.isNotEmpty()) { cur.name = nn.take(60); AppsRepo.save(cur); s.titleView.text = cur.name }
            }
        })
        rows.add(SheetRow(R.drawable.ic_play, "Live preview", if (live) "On: updates while you type" else "Off: tap Run to update", live) {
            live = !live
            toast(if (live) "Live preview on" else "Live preview off")
        })
        rows.add(SheetRow(R.drawable.ic_copy, "Copy code") {
            (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager)
                .setPrimaryClip(ClipData.newPlainText("Vethos code", editor.text.toString()))
            toast("Copied")
        })
        rows.add(SheetRow(R.drawable.ic_share, "Share code") {
            startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, editor.text.toString()), "Share"))
        })
        rows.add(SheetRow(R.drawable.ic_dl, "Export as .html file") {
            export.launch(safeFileName(cur?.name ?: "app", ".html"))
        })
        rows.add(SheetRow(R.drawable.ic_close, "Clear console") { logs.clear(); errors = 0; consoleText.text = ""; refreshConsoleBtn() })
        if (cur != null) rows.add(SheetRow(R.drawable.ic_trash, "Delete app") {
            confirm("Delete app?", cur.name, "Delete") {
                try { WebStorage.getInstance().deleteOrigin(curBase.trimEnd('/')) } catch (_: Throwable) { }
                AppsRepo.delete(cur.id)
                dirty = false
                finish()
            }
        })
        showSheet("App", rows)
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        val t = editor.text.toString()
        if (t.length < 80_000) outState.putString("code", t)
        outState.putBoolean("dirty", dirty)
    }

    override fun onPause() { super.onPause(); web.onPause(); web.pauseTimers() }
    override fun onResume() { super.onResume(); web.onResume(); web.resumeTimers() }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        try {
            web.stopLoading()
            (web.parent as? android.view.ViewGroup)?.removeView(web)
            web.destroy()
        } catch (_: Throwable) { }
        super.onDestroy()
    }

    companion object {
        private const val MAX_CODE = 200_000
        private var handoff: String? = null

        fun isRunnable(lang: String): Boolean = lang.trim().lowercase().let { it == "html" || it == "htm" || it == "svg" }

        fun openCode(ctx: Context, html: String) {
            handoff = html
            start(ctx, Intent(ctx, RunnerActivity::class.java))
        }

        fun openBlocks(ctx: Context, blocks: List<Pair<String, String>>) = openCode(ctx, Assemble.fromBlocks(blocks))

        fun openApp(ctx: Context, id: String) = start(ctx, Intent(ctx, RunnerActivity::class.java).putExtra("id", id))

        private fun start(ctx: Context, i: Intent) {
            if (ctx !is Activity) i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            ctx.startActivity(i)
        }
    }
}
