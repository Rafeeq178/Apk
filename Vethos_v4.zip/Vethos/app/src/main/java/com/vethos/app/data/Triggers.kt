package com.vethos.app.data

import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

/**
 * An automation rule: WHEN a message matches [pattern] THEN run [tool] with [arg].
 * arg can use {input} (whole message), {match} (matched text) and {1}..{9} (regex groups).
 * mode 0 = give the result to the AI as extra information, mode 1 = answer directly without the AI.
 */
data class Trigger(
    val id: String, var name: String, var pattern: String, var regex: Boolean,
    var tool: String, var arg: String, var mode: Int, var on: Boolean
)

object Triggers {
    class Hit(val t: Trigger, val arg: String)

    private var cache: MutableList<Trigger>? = null
    private val prefs get() = Store.app.getSharedPreferences("vethos", 0)

    private fun defaults() = mutableListOf(
        Trigger(UUID.randomUUID().toString(), "Read links", """https?://[^\s<>"']+""", true, "fetch", "{match}", 0, true),
        Trigger(UUID.randomUUID().toString(), "Date and time",
            "what time,what's the time,current time,today's date,todays date,what date,what day is,aaj ki date,time kya,date kya",
            false, "time", "", 0, true),
        Trigger(UUID.randomUUID().toString(), "Quick math",
            """^(?=.*\d)(?=.*(?:[+*/^×÷%]|\s-\s|\dx\d))[\d\s.+\-*/^()%x×÷=]+$""", true, "calc", "{input}", 1, true),
        Trigger(UUID.randomUUID().toString(), "Web search (search: topic)",
            """^\s*(?:search|web search|google|find online)\s*:\s*(.+)$""", true, "search", "{1}", 0, true),
    )

    @Synchronized
    fun all(): MutableList<Trigger> {
        cache?.let { return it }
        val out = mutableListOf<Trigger>()
        val raw = prefs.getString("triggers", null)
        if (raw == null) {
            out.addAll(defaults())
            cache = out
            save()
            return out
        }
        try {
            val a = JSONArray(raw)
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                out.add(Trigger(o.getString("id"), o.optString("name"), o.optString("p"), o.optBoolean("rx"),
                    o.optString("tool"), o.optString("arg"), o.optInt("mode"), o.optBoolean("on", true)))
            }
        } catch (_: Exception) { }
        cache = out
        return out
    }

    @Synchronized
    fun save() {
        val a = JSONArray()
        all().forEach {
            a.put(JSONObject().put("id", it.id).put("name", it.name).put("p", it.pattern).put("rx", it.regex)
                .put("tool", it.tool).put("arg", it.arg).put("mode", it.mode).put("on", it.on))
        }
        prefs.edit().putString("triggers", a.toString()).apply()
    }

    @Synchronized
    fun add(t: Trigger) { all().add(t); save() }

    @Synchronized
    fun delete(id: String) { all().removeAll { it.id == id }; save() }

    @Synchronized
    fun reset() { all().clear(); all().addAll(defaults()); save() }

    fun newId() = UUID.randomUUID().toString()

    /** Returns an error text if the rule is not valid, otherwise null. */
    fun validate(name: String, pattern: String, regex: Boolean, tool: String): String? {
        if (name.isBlank()) return "Give the rule a name"
        if (pattern.isBlank()) return "Write what to look for"
        if (Tools.byId(tool) == null) return "Choose a tool"
        if (regex) try { Regex(pattern) } catch (e: Exception) { return "This pattern is not valid" }
        return null
    }

    @Synchronized
    fun match(text: String): List<Hit> {
        val out = ArrayList<Hit>()
        for (t in all()) {
            if (!t.on) continue
            val g: List<String>? = try { groups(t, text) } catch (_: Exception) { null }
            if (g == null) continue
            out.add(Hit(t, fill(t.arg, text, g)))
        }
        return out
    }

    private fun groups(t: Trigger, text: String): List<String>? {
        if (t.regex) {
            val m = Regex(t.pattern, RegexOption.IGNORE_CASE).find(text) ?: return null
            return m.groupValues
        }
        val low = text.lowercase()
        for (k in t.pattern.split(',')) {
            val kw = k.trim().lowercase()
            if (kw.isNotEmpty() && low.contains(kw)) return listOf(kw)
        }
        return null
    }

    private fun fill(tpl: String, input: String, g: List<String>): String {
        var s = tpl.replace("{input}", input).replace("{match}", g.getOrElse(0) { "" })
        for (n in 1..9) s = s.replace("{$n}", g.getOrElse(n) { "" })
        return s
    }
}
