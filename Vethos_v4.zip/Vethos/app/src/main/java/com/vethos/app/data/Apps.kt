package com.vethos.app.data

import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID

/** A saved HTML/CSS/JS app that runs in the offline runner. */
data class WebApp(val id: String, var name: String, var html: String, var ts: Long)

object AppsRepo {
    private var cache: MutableList<WebApp>? = null
    private val file get() = File(Store.app.filesDir, "apps.json")

    @Synchronized
    fun all(): MutableList<WebApp> {
        cache?.let { return it }
        val out = mutableListOf<WebApp>()
        try {
            if (file.exists()) {
                val a = JSONArray(file.readText())
                for (i in 0 until a.length()) {
                    val o = a.getJSONObject(i)
                    out.add(WebApp(o.getString("id"), o.optString("name", "App"), o.optString("html"), o.optLong("ts")))
                }
            }
        } catch (_: Exception) { }
        cache = out
        return out
    }

    @Synchronized fun sorted(): List<WebApp> = all().sortedByDescending { it.ts }
    @Synchronized fun get(id: String?): WebApp? = if (id.isNullOrEmpty()) null else all().firstOrNull { it.id == id }

    @Synchronized
    fun create(name: String, html: String): WebApp {
        val a = WebApp(UUID.randomUUID().toString().replace("-", "").take(12), name.trim().ifEmpty { "My app" }.take(60), html, System.currentTimeMillis())
        all().add(a)
        persist()
        return a
    }

    @Synchronized
    fun save(a: WebApp) {
        if (all().none { it.id == a.id }) all().add(a)
        a.ts = System.currentTimeMillis()
        persist()
    }

    @Synchronized fun delete(id: String) { all().removeAll { it.id == id }; persist() }

    private fun persist() {
        val a = JSONArray()
        all().forEach { a.put(JSONObject().put("id", it.id).put("name", it.name).put("html", it.html).put("ts", it.ts)) }
        Disk.write(file, a.toString())
    }
}

/** Turns code from an AI answer (html / css / js blocks) into one runnable HTML page. */
object Assemble {
    private const val META = "<meta charset=\"utf-8\"><meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">"

    private fun isHtml(l: String) = l == "html" || l == "htm" || l == "xhtml"
    private fun isCss(l: String) = l == "css"
    private fun isJs(l: String) = l == "js" || l == "javascript"

    fun fromBlocks(blocks: List<Pair<String, String>>): String {
        val bl = blocks.map { it.first.trim().lowercase() to it.second }
        val svg = bl.firstOrNull { it.first == "svg" }
        var html = bl.firstOrNull { isHtml(it.first) }?.second
            ?: svg?.second
            ?: return document("")
        val css = bl.filter { isCss(it.first) }.joinToString("\n") { it.second }
        val js = bl.filter { isJs(it.first) }.joinToString("\n") { it.second }
        html = document(html)
        if (css.isNotBlank() && !html.contains("<style", true)) {
            html = injectBefore(html, "</head>", "<style>\n$css\n</style>")
        }
        if (js.isNotBlank() && !Regex("<script(?![^>]*\\bsrc\\b)", RegexOption.IGNORE_CASE).containsMatchIn(html)) {
            html = injectBefore(html, "</body>", "<script>\n$js\n</script>")
        }
        return html
    }

    private fun injectBefore(html: String, tag: String, add: String): String {
        val i = html.lastIndexOf(tag, ignoreCase = true)
        return if (i >= 0) html.substring(0, i) + add + "\n" + html.substring(i) else html + "\n" + add
    }

    /** Makes sure the code is a full page with a mobile viewport. */
    fun document(code: String): String {
        val low = code.lowercase()
        if (!low.contains("<html") && !low.contains("<!doctype")) {
            return "<!DOCTYPE html><html><head>$META</head><body>\n$code\n</body></html>"
        }
        if (low.contains("name=\"viewport\"") || low.contains("name='viewport'") || low.contains("name=viewport")) return code
        val head = Regex("<head[^>]*>", RegexOption.IGNORE_CASE).find(code)
        if (head != null) return code.substring(0, head.range.last + 1) + META + code.substring(head.range.last + 1)
        val h = Regex("<html[^>]*>", RegexOption.IGNORE_CASE).find(code)
        if (h != null) return code.substring(0, h.range.last + 1) + "<head>$META</head>" + code.substring(h.range.last + 1)
        return META + code
    }
}

/** Starter pages for the Apps screen. (No dollar signs here, this is a plain Kotlin string.) */
object Templates {
    val BLANK = """<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>My app</title>
<style>
  body { font-family: sans-serif; margin: 0; padding: 24px; background: #faf9f5; color: #1f1a17; }
  button { padding: 10px 18px; border: 0; border-radius: 12px; background: #c9623f; color: #fff; font-size: 16px; }
</style>
</head>
<body>
<h2>Hello from Vethos</h2>
<p id="out">Tap the button.</p>
<button onclick="document.getElementById('out').textContent = 'It works! ' + new Date().toLocaleTimeString()">Click me</button>
</body>
</html>
"""

    val TODO = """<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>To-do</title>
<style>
  body { font-family: sans-serif; margin: 0; padding: 20px; background: #faf9f5; color: #1f1a17; }
  input { width: 70%; padding: 12px; border: 1px solid #ccc; border-radius: 12px; font-size: 16px; }
  button { padding: 12px 16px; border: 0; border-radius: 12px; background: #c9623f; color: #fff; font-size: 16px; }
  li { padding: 10px 0; border-bottom: 1px solid #eee; font-size: 17px; }
  li.done { text-decoration: line-through; color: #999; }
</style>
</head>
<body>
<h2>To-do</h2>
<input id="t" placeholder="New task"> <button onclick="add()">Add</button>
<ul id="list"></ul>
<script>
var items = [];
try { items = JSON.parse(localStorage.getItem('todo') || '[]'); } catch (e) { items = []; }
function save() { try { localStorage.setItem('todo', JSON.stringify(items)); } catch (e) {} }
function draw() {
  var ul = document.getElementById('list');
  ul.innerHTML = '';
  items.forEach(function (it, i) {
    var li = document.createElement('li');
    li.textContent = it.text;
    if (it.done) li.className = 'done';
    li.onclick = function () { it.done = !it.done; save(); draw(); };
    ul.appendChild(li);
  });
}
function add() {
  var f = document.getElementById('t');
  if (!f.value.trim()) return;
  items.push({ text: f.value.trim(), done: false });
  f.value = '';
  save(); draw();
}
draw();
</script>
</body>
</html>
"""

    val STOPWATCH = """<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Stopwatch</title>
<style>
  body { font-family: sans-serif; text-align: center; padding: 40px 20px; background: #faf9f5; color: #1f1a17; }
  #time { font-size: 56px; font-weight: bold; margin: 30px 0; }
  button { padding: 14px 26px; margin: 6px; border: 0; border-radius: 14px; background: #c9623f; color: #fff; font-size: 18px; }
</style>
</head>
<body>
<h2>Stopwatch</h2>
<div id="time">00:00.0</div>
<button onclick="startStop()" id="b">Start</button>
<button onclick="reset()">Reset</button>
<script>
var start = 0, elapsed = 0, timer = null;
function show() {
  var t = elapsed + (timer ? Date.now() - start : 0);
  var m = Math.floor(t / 60000), s = Math.floor(t / 1000) % 60, d = Math.floor(t / 100) % 10;
  document.getElementById('time').textContent = (m < 10 ? '0' : '') + m + ':' + (s < 10 ? '0' : '') + s + '.' + d;
}
function startStop() {
  if (timer) { elapsed += Date.now() - start; clearInterval(timer); timer = null; document.getElementById('b').textContent = 'Start'; }
  else { start = Date.now(); timer = setInterval(show, 100); document.getElementById('b').textContent = 'Stop'; }
}
function reset() { if (timer) { clearInterval(timer); timer = null; } elapsed = 0; document.getElementById('b').textContent = 'Start'; show(); }
</script>
</body>
</html>
"""

    val items = listOf("Blank page" to BLANK, "To-do list" to TODO, "Stopwatch" to STOPWATCH)
}
