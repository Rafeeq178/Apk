package com.vethos.app.ui

import android.Manifest
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.format.DateFormat
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.vethos.app.R
import com.vethos.app.data.Reminder
import com.vethos.app.data.RemindersRepo
import com.vethos.app.data.Scheduler
import com.vethos.app.data.TimeParse
import java.util.Calendar

class RemindersActivity : AppCompatActivity() {
    private lateinit var s: Screen

    private val askNotif = registerForActivityResult(ActivityResultContracts.RequestPermission()) { render() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        s = Screen(this, "Reminders", listOf<Pair<Int, () -> Unit>>(R.drawable.ic_plus to { pickDateTime() }))
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) askNotif.launch(Manifest.permission.POST_NOTIFICATIONS)
    }

    override fun onResume() { super.onResume(); render() }

    private fun render() {
        s.body.removeAllViews()
        if (!NotificationManagerCompat.from(this).areNotificationsEnabled()) {
            s.card(4).also { c ->
                s.row(c, R.drawable.ic_bell, "Notifications are off", "Tap to turn them on so reminders can alert you") {
                    startActivity(Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, packageName))
                }
            }
        }
        if (!Scheduler.canExact()) {
            s.card(8).also { c ->
                s.row(c, R.drawable.ic_pin, "Exact timing is off", "Reminders may arrive a few minutes late. Tap to allow exact alarms") {
                    try {
                        startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:$packageName")))
                    } catch (_: Exception) { toast("Open Android settings > Apps > Vethos > Alarms") }
                }
            }
        }
        val quick = s.input("e.g. 10m drink water, 18:30 call mom, tomorrow 9am gym")
        s.body.addView(quick, android.widget.LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(12) })
        s.button("Add reminder", R.drawable.ic_plus) {
            val t = quick.text.toString()
            val p = TimeParse.parse(t)
            when {
                t.isBlank() -> toast("Type a time and a message")
                p == null -> toast("I could not find a time. Try: 10m drink water")
                p.at <= System.currentTimeMillis() -> toast("That time has already passed")
                else -> { RemindersRepo.add(p.text, p.at); toast("Reminder set"); render() }
            }
        }

        val up = RemindersRepo.upcoming()
        s.section("UPCOMING")
        if (up.isEmpty()) s.hint("Nothing scheduled.", 6)
        else {
            val c = s.card(8)
            up.forEach { r -> s.row(c, R.drawable.ic_bell, r.text, whenText(r.at), onLong = { menu(r) }) { menu(r) } }
        }
        val done = RemindersRepo.finished().take(15)
        if (done.isNotEmpty()) {
            s.section("DONE")
            val c = s.card(8)
            done.forEach { r -> s.row(c, R.drawable.ic_check, r.text, whenText(r.at), onLong = { menu(r) }) { menu(r) } }
            s.button("Clear done", null, primary = false) { RemindersRepo.clearDone(); render() }
        }
    }

    private fun whenText(ts: Long) = DateFormat.format("EEE d MMM, h:mm a", ts).toString()

    private fun menu(r: Reminder) {
        showSheet(r.text, listOf(
            SheetRow(R.drawable.ic_bell, "Snooze 10 minutes") { RemindersRepo.snooze(r.id, 10); render() },
            SheetRow(R.drawable.ic_bell, "Snooze 1 hour") { RemindersRepo.snooze(r.id, 60); render() },
            SheetRow(R.drawable.ic_trash, "Delete") { RemindersRepo.delete(r.id); render() },
        ))
    }

    /** + button: message first, then date, then time. */
    private fun pickDateTime() {
        inputDialog("Remind me to...", "", "e.g. Pay the bill") { msg ->
            val text = msg.trim()
            if (text.isEmpty()) { toast("Write what to remind"); return@inputDialog }
            val now = Calendar.getInstance()
            DatePickerDialog(this, { _, y, m, d ->
                TimePickerDialog(this, { _, h, mi ->
                    val c = Calendar.getInstance().apply { set(y, m, d, h, mi, 0); set(Calendar.MILLISECOND, 0) }
                    if (c.timeInMillis <= System.currentTimeMillis()) toast("That time has already passed")
                    else { RemindersRepo.add(text, c.timeInMillis); toast("Reminder set"); render() }
                }, now.get(Calendar.HOUR_OF_DAY), now.get(Calendar.MINUTE), DateFormat.is24HourFormat(this)).show()
            }, now.get(Calendar.YEAR), now.get(Calendar.MONTH), now.get(Calendar.DAY_OF_MONTH)).show()
        }
    }
}
