package com.vethos.app.data

/**
 * Offline helpers that fit a long file into the small context of a phone model:
 *  - condense(): picks the most important sentences from the WHOLE file (keeps their order)
 *  - relevant(): picks the parts of the file that match the user's question
 */
object Summarizer {
    private val stop = setOf(
        "the", "and", "for", "are", "but", "not", "you", "all", "can", "had", "her", "was", "one", "our", "out", "has",
        "have", "that", "this", "with", "from", "they", "been", "were", "will", "would", "there", "their", "what", "when",
        "which", "who", "whom", "your", "about", "into", "than", "then", "them", "these", "those", "its", "also", "more",
        "some", "such", "only", "other", "how", "why", "where", "while", "does", "did", "doing", "being", "very", "just",
        "over", "under", "between", "through", "after", "before", "because", "each", "any", "may", "might", "should",
        "could", "hai", "hain", "ka", "ki", "ke", "ko", "se", "mein", "par", "aur", "yeh", "woh", "nahi", "nahin", "kya",
        "tha", "thi", "bhi", "kar", "karo", "koi", "kia", "hay", "hota", "hoti", "hote"
    )
    private val word = Regex("\\p{L}{3,}")
    private val splitter = Regex("(?<=[.!?\u06D4\u061F])\\s+|\\n+")

    private fun terms(s: String): List<String> =
        word.findAll(s.lowercase()).map { it.value }.filter { it !in stop }.toList()

    private fun sentences(text: String): List<String> =
        text.split(splitter).map { it.trim() }.filter { it.length >= 12 }.map { it.take(500) }

    fun condense(text: String, budget: Int): String {
        if (text.length <= budget) return text
        val sents = sentences(text)
        if (sents.isEmpty()) return text.take(budget)
        val freq = HashMap<String, Int>()
        for (s in sents) for (t in terms(s)) freq[t] = (freq[t] ?: 0) + 1
        val scored = sents.mapIndexed { i, s ->
            val t = terms(s)
            var sc = if (t.isEmpty()) 0.0 else t.sumOf { (freq[it] ?: 0).toDouble() } / Math.sqrt(t.size + 2.0)
            if (i < 3) sc *= 1.6 // the opening usually says what the file is about
            Triple(i, s, sc)
        }.sortedByDescending { it.third }
        val keep = HashSet<Int>()
        var used = 0
        val limit = budget - 70
        for ((i, s, _) in scored) {
            if (used + s.length + 1 > limit) continue
            keep.add(i)
            used += s.length + 1
            if (used >= limit - 40) break
        }
        if (keep.isEmpty()) return text.take(budget)
        return keep.sorted().joinToString("\n") { sents[it] } + "\n[...condensed: the key sentences of the whole file]"
    }

    fun relevant(text: String, question: String, budget: Int): String {
        if (text.length <= budget) return text
        val qt = terms(question).toSet()
        if (qt.isEmpty()) return condense(text, budget)
        val chunks = chunk(text, 700)
        if (chunks.isEmpty()) return text.take(budget)
        val scores = chunks.map { c ->
            val tl = terms(c)
            tl.count { it in qt } + 2 * tl.filter { it in qt }.toSet().size
        }
        if (scores.all { it == 0 }) return condense(text, budget)
        val order = chunks.indices.sortedByDescending { scores[it] }
        val keep = ArrayList<Int>()
        var used = 0
        val limit = budget - 70
        for (i in order) {
            if (scores[i] == 0) break
            val c = chunks[i]
            if (used + c.length + 6 > limit) continue
            keep.add(i)
            used += c.length + 6
        }
        if (keep.isEmpty()) return chunks[order[0]].take(budget)
        keep.sort()
        return "[Parts of the file that match the question]\n" + keep.joinToString("\n[...]\n") { chunks[it] }
    }

    private fun chunk(text: String, size: Int): List<String> {
        val out = ArrayList<String>()
        val cur = StringBuilder()
        for (p in text.split(Regex("\\n"))) {
            var s = p.trim()
            if (s.isEmpty()) continue
            while (s.length > size) {
                if (cur.isNotEmpty()) { out.add(cur.toString()); cur.setLength(0) }
                out.add(s.substring(0, size))
                s = s.substring(size)
            }
            if (cur.isNotEmpty() && cur.length + s.length + 1 > size) { out.add(cur.toString()); cur.setLength(0) }
            if (cur.isNotEmpty()) cur.append('\n')
            cur.append(s)
        }
        if (cur.isNotEmpty()) out.add(cur.toString())
        return out
    }
}
