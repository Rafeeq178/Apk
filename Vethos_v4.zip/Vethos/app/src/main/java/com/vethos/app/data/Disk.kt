package com.vethos.app.data

import java.io.File

/** Small safe-write helper: write to a temp file first, then rename, so a crash never leaves half a file. */
object Disk {
    fun write(f: File, text: String) {
        val tmp = File(f.path + ".tmp")
        tmp.writeText(text)
        if (!tmp.renameTo(f)) {
            f.writeText(text)
            tmp.delete()
        }
    }
}
