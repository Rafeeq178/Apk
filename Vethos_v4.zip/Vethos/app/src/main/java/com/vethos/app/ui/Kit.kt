package com.vethos.app.ui

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.provider.OpenableColumns
import android.text.TextUtils
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.vethos.app.R
import com.vethos.app.databinding.ItemToggleBinding

fun Context.displayName(uri: Uri): String {
    var n = "file"
    try {
        contentResolver.query(uri, null, null, null, null)?.use {
            if (it.moveToFirst()) {
                val i = it.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (i >= 0) it.getString(i)?.let { s -> n = s }
            }
        }
    } catch (_: Exception) { }
    return n
}

/** Reads a picked text file (max ~600 KB). */
fun Context.readTextUri(uri: Uri, maxBytes: Int = 600_000): String {
    val ins = contentResolver.openInputStream(uri) ?: throw IllegalArgumentException("Could not open this file")
    return ins.use {
        val out = java.io.ByteArrayOutputStream()
        val buf = ByteArray(16 * 1024)
        var total = 0
        while (total < maxBytes) {
            val n = it.read(buf, 0, minOf(buf.size, maxBytes - total))
            if (n < 0) break
            out.write(buf, 0, n); total += n
        }
        val b = out.toByteArray()
        for (k in 0 until minOf(b.size, 4096)) if (b[k].toInt() == 0) throw IllegalArgumentException("This is not a text file")
        String(b, Charsets.UTF_8)
    }
}

fun Context.writeTextUri(uri: Uri, text: String) {
    try {
        contentResolver.openOutputStream(uri, "wt")?.use { it.write(text.toByteArray(Charsets.UTF_8)) }
        toast("Saved")
    } catch (e: Exception) {
        toast("Could not save: " + (e.message ?: "error"))
    }
}

fun safeFileName(s: String, ext: String): String =
    s.replace(Regex("[^\\w .-]"), "_").trim().ifEmpty { "file" }.take(60) + ext

/** A simple screen built in code: header (back button, title, round actions) and a list area. Same look as the rest of the app. */
class Screen(
    val act: AppCompatActivity,
    title: String,
    actions: List<Pair<Int, () -> Unit>> = emptyList(),
    scrolls: Boolean = true,
) {
    val root = LinearLayout(act)
    val titleView = TextView(act)
    val body = LinearLayout(act)

    private val cText get() = act.getColor(R.color.v_text)
    private val muted get() = act.getColor(R.color.v_muted)

    init {
        root.orientation = LinearLayout.VERTICAL
        val head = LinearLayout(act).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(act.dp(16), act.dp(12), act.dp(16), act.dp(10))
        }
        head.addView(ImageView(act).apply {
            setBackgroundResource(R.drawable.bg_hbtn)
            elevation = act.dp(2).toFloat()
            setPadding(act.dp(12), act.dp(12), act.dp(12), act.dp(12))
            setImageResource(R.drawable.ic_back)
            imageTintList = ColorStateList.valueOf(cText)
            setOnClickListener { act.onBackPressedDispatcher.onBackPressed() }
        }, LinearLayout.LayoutParams(act.dp(44), act.dp(44)))
        titleView.apply {
            this.text = title
            textSize = 22f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(cText)
            isSingleLine = true
            ellipsize = TextUtils.TruncateAt.END
        }
        head.addView(titleView, LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = act.dp(14) })
        for ((icon, fn) in actions) {
            head.addView(ImageView(act).apply {
                setImageResource(icon)
                imageTintList = ColorStateList.valueOf(cText)
                setPadding(act.dp(10), act.dp(10), act.dp(10), act.dp(10))
                setOnClickListener { fn() }
            }, LinearLayout.LayoutParams(act.dp(44), act.dp(44)))
        }
        root.addView(head, LinearLayout.LayoutParams(-1, -2))

        body.orientation = LinearLayout.VERTICAL
        if (scrolls) {
            val sv = ScrollView(act).apply {
                clipToPadding = false
                isVerticalScrollBarEnabled = false
                setPadding(0, 0, 0, act.dp(30))
            }
            body.setPadding(act.dp(16), 0, act.dp(16), 0)
            sv.addView(body, FrameLayout.LayoutParams(-1, -2))
            root.addView(sv, LinearLayout.LayoutParams(-1, 0, 1f))
        } else {
            body.setPadding(act.dp(12), 0, act.dp(12), act.dp(8))
            root.addView(body, LinearLayout.LayoutParams(-1, 0, 1f))
        }
        act.setContentView(root)
        // Android 15 draws apps edge to edge: keep the content clear of the status bar, nav bar and keyboard.
        if (Build.VERSION.SDK_INT >= 35) {
            ViewCompat.setOnApplyWindowInsetsListener(root) { v, ins ->
                val b = ins.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.ime())
                v.setPadding(b.left, b.top, b.right, b.bottom)
                ins
            }
        }
    }

    fun card(top: Int = 12): LinearLayout {
        val c = LinearLayout(act).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundResource(R.drawable.bg_card)
            elevation = act.dp(1).toFloat()
        }
        body.addView(c, LinearLayout.LayoutParams(-1, -2).apply { topMargin = act.dp(top) })
        return c
    }

    fun section(title: String) {
        body.addView(TextView(act).apply {
            this.text = title
            setTextColor(muted)
            textSize = 13.5f
            letterSpacing = 0.08f
            typeface = Typeface.DEFAULT_BOLD
            setPadding(act.dp(6), act.dp(22), 0, act.dp(2))
        })
    }

    fun hint(t: String, top: Int = 12): TextView {
        val tv = TextView(act).apply {
            this.text = t
            setTextColor(muted)
            textSize = 14f
            setPadding(act.dp(6), 0, act.dp(6), 0)
        }
        body.addView(tv, LinearLayout.LayoutParams(-1, -2).apply { topMargin = act.dp(top) })
        return tv
    }

    private fun divider(card: LinearLayout) {
        if (card.childCount > 0) card.addView(View(act).apply {
            setBackgroundColor(act.getColor(R.color.v_line))
        }, LinearLayout.LayoutParams(-1, 1).apply { marginStart = act.dp(16); marginEnd = act.dp(16) })
    }

    /** A tappable row inside a card: icon, title, optional second line and a chevron. Returns the title and sub views. */
    class RowViews(val root: LinearLayout, val title: TextView, val sub: TextView)

    fun row(
        card: LinearLayout, icon: Int?, title: String, sub: String? = null, chevron: Boolean = true,
        onLong: (() -> Unit)? = null, onClick: () -> Unit,
    ): RowViews {
        divider(card)
        val r = LinearLayout(act).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            minimumHeight = act.dp(58)
            setPadding(act.dp(16), act.dp(10), act.dp(14), act.dp(10))
            isClickable = true
            isFocusable = true
            val tv = TypedValue()
            if (act.theme.resolveAttribute(android.R.attr.selectableItemBackground, tv, true)) setBackgroundResource(tv.resourceId)
            setOnClickListener { onClick() }
            if (onLong != null) setOnLongClickListener { onLong(); true }
        }
        if (icon != null) r.addView(ImageView(act).apply {
            setImageResource(icon)
            imageTintList = ColorStateList.valueOf(act.getColor(R.color.v_blue))
        }, LinearLayout.LayoutParams(act.dp(22), act.dp(22)).apply { marginEnd = act.dp(14) })
        val col = LinearLayout(act).apply { orientation = LinearLayout.VERTICAL }
        val t = TextView(act).apply {
            this.text = title
            setTextColor(cText)
            textSize = 16f
            typeface = Typeface.DEFAULT_BOLD
            maxLines = 2
            ellipsize = TextUtils.TruncateAt.END
        }
        val s = TextView(act).apply {
            this.text = sub ?: ""
            setTextColor(muted)
            textSize = 13.5f
            maxLines = 3
            ellipsize = TextUtils.TruncateAt.END
            visibility = if (sub.isNullOrEmpty()) View.GONE else View.VISIBLE
        }
        col.addView(t)
        col.addView(s, LinearLayout.LayoutParams(-1, -2).apply { topMargin = act.dp(2) })
        r.addView(col, LinearLayout.LayoutParams(0, -2, 1f))
        if (chevron) r.addView(ImageView(act).apply {
            setImageResource(R.drawable.ic_chev)
            imageTintList = ColorStateList.valueOf(act.getColor(R.color.v_muted2))
        }, LinearLayout.LayoutParams(act.dp(20), act.dp(20)))
        card.addView(r, LinearLayout.LayoutParams(-1, -2))
        return RowViews(r, t, s)
    }

    fun toggle(card: LinearLayout, icon: Int, title: String, sub: String?, on: Boolean, onChange: (Boolean) -> Unit) {
        divider(card)
        val r = ItemToggleBinding.inflate(act.layoutInflater, card, false)
        r.icon.setImageResource(icon)
        r.icon.imageTintList = ColorStateList.valueOf(act.getColor(R.color.v_blue))
        r.title.text = title
        if (sub != null) { r.sub.text = sub; r.sub.visibility = View.VISIBLE }
        r.sw.isChecked = on
        r.sw.setOnCheckedChangeListener { _, v -> onChange(v) }
        r.root.setOnClickListener { r.sw.toggle() }
        card.addView(r.root)
    }

    fun button(label: String, icon: Int?, primary: Boolean = true, onClick: () -> Unit): TextView {
        val b = TextView(act).apply {
            this.text = label
            gravity = Gravity.CENTER
            textSize = 16.5f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(if (primary) act.getColor(R.color.white) else cText)
            setBackgroundResource(if (primary) R.drawable.bg_btn_primary else R.drawable.bg_chip)
            compoundDrawablePadding = act.dp(8)
            if (icon != null) {
                setCompoundDrawablesRelativeWithIntrinsicBounds(icon, 0, 0, 0)
                compoundDrawableTintList = ColorStateList.valueOf(if (primary) act.getColor(R.color.white) else cText)
            }
            isClickable = true
            setOnClickListener { onClick() }
        }
        body.addView(b, LinearLayout.LayoutParams(-1, act.dp(54)).apply { topMargin = act.dp(12) })
        return b
    }

    fun input(hint: String, multiline: Boolean = false): EditText = EditText(act).apply {
        this.hint = hint
        setTextColor(cText)
        setHintTextColor(act.getColor(R.color.v_muted2))
        textSize = 16f
        setBackgroundResource(R.drawable.bg_chip_sug)
        setPadding(act.dp(16), act.dp(12), act.dp(16), act.dp(12))
        if (multiline) {
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE or android.text.InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
            minLines = 3; maxLines = 8; gravity = Gravity.TOP
        } else {
            inputType = android.text.InputType.TYPE_CLASS_TEXT
            isSingleLine = true
        }
    }
}
