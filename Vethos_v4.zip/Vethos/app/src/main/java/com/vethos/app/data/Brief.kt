package com.vethos.app.data

import android.text.format.DateFormat
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

/** The text of the daily brief: date, reminders, pinned notes and chats. Works fully offline. */
object Brief {
    fun build(): String {
        val now = Calendar.getInstance()
        val h = now.get(Calendar.HOUR_OF_DAY)
        val greet = when {
            h < 5 -> "Good night"
            h < 12 -> "Good morning"
            h < 17 -> "Good afternoon"
            h < 21 -> "Good evening"
            else -> "Good night"
        }
        val sb = StringBuilder()
        sb.append(greet).append("!\n")
        sb.append(SimpleDateFormat("EEEE, d MMMM yyyy", Locale.getDefault()).format(now.time)).append('\n')

        val dayStart = (now.clone() as Calendar).apply {
            set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        }.timeInMillis
        val dayEnd = dayStart + 24L * 3_600_000L
        val nowMs = System.currentTimeMillis()

        val pending = RemindersRepo.upcoming()
        val missed = pending.filter { it.at < nowMs }
        val today = pending.filter { it.at >= nowMs && it.at < dayEnd }
        val later = pending.count { it.at >= dayEnd }

        if (missed.isNotEmpty()) {
            sb.append("\nMissed (${missed.size})\n")
            missed.take(5).forEach { sb.append("• ${time(it.at)} ${it.text}\n") }
        }
        if (today.isNotEmpty()) {
            sb.append("\nToday (${today.size})\n")
            today.take(8).forEach { sb.append("• ${time(it.at)} ${it.text}\n") }
        } else {
            sb.append("\nNo reminders for the rest of today.\n")
        }
        if (later > 0) sb.append("$later more reminder(s) coming up.\n")

        val pinned = NotesRepo.sorted().filter { it.pinned }.take(3)
        if (pinned.isNotEmpty()) {
            sb.append("\nPinned notes\n")
            pinned.forEach { sb.append("• ${it.title}\n") }
        }
        val notes = NotesRepo.all().size
        if (notes > 0) sb.append("\nYou have $notes note(s).\n")
        return sb.toString().trim()
    }

    private fun time(ts: Long): String = DateFormat.format("h:mm a", ts).toString()
}
