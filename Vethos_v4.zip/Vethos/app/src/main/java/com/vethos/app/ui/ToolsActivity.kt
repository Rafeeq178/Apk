package com.vethos.app.ui

import android.Manifest
import android.app.TimePickerDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.text.format.DateFormat
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.vethos.app.R
import com.vethos.app.data.Brief
import com.vethos.app.data.Calc
import com.vethos.app.data.NotesRepo
import com.vethos.app.data.RemindersRepo
import com.vethos.app.data.Scheduler
import com.vethos.app.data.Store
import com.vethos.app.data.Tools
import com.vethos.app.data.Triggers
import com.vethos.app.data.AppsRepo

/** One place for everything extra: notes, reminders, calculator, file summary, web, voice, daily brief, automation, apps. */
class ToolsActivity : AppCompatActivity() {
    private lateinit var s: Screen

    private val askNotif = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    private val pickFile = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            val i = Intent(this, ChatActivity::class.java).setData(uri)
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION).putExtra("autosend", true)
            startActivity(i)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        s = Screen(this, "Tools")
    }

    override fun onResume() { super.onResume(); build() }

    private fun needNotifications() {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) askNotif.launch(Manifest.permission.POST_NOTIFICATIONS)
    }

    private fun build() {
        s.body.removeAllViews()

        s.section("EVERYDAY TOOLS")
        val tools = s.card(8)
        s.row(tools, R.drawable.ic_note, "Notes", NotesRepo.all().size.toString() + " saved") { startActivity(Intent(this, NotesActivity::class.java)) }
        s.row(tools, R.drawable.ic_bell, "Reminders", RemindersRepo.upcoming().size.toString() + " upcoming") { startActivity(Intent(this, RemindersActivity::class.java)) }
        s.row(tools, R.drawable.ic_calc, "Calculator", "Percent, brackets, sqrt, sin, log...") { calculator() }
        s.row(tools, R.drawable.ic_clip, "Summarize a file", "PDF, Word, PowerPoint, text or code") {
            pickFile.launch(arrayOf("application/pdf", "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                "application/vnd.openxmlformats-officedocument.presentationml.presentation", "text/*", "*/*"))
        }
        s.row(tools, R.drawable.ic_globe, "Web search and links", "Type  search: topic  or paste a link in a chat") {
            startActivity(Intent(this, ChatActivity::class.java).putExtra("preset", "search: "))
        }
        s.row(tools, R.drawable.ic_code, "Apps (HTML runner)", AppsRepo.all().size.toString() + " saved") { startActivity(Intent(this, AppsActivity::class.java)) }

        s.section("DAILY BRIEF")
        val brief = s.card(8)
        s.toggle(brief, R.drawable.ic_sun, "Daily brief notification", "Date, today's reminders and pinned notes", Store.briefOn) { v ->
            Store.briefOn = v
            if (v) { needNotifications(); Scheduler.scheduleBrief() } else Scheduler.cancelBrief()
        }
        val tr = s.row(brief, R.drawable.ic_hist, "Time", timeText(), chevron = true) {}
        tr.root.setOnClickListener {
            TimePickerDialog(this, { _, h, m ->
                Store.briefHour = h; Store.briefMin = m
                if (Store.briefOn) Scheduler.scheduleBrief()
                tr.sub.text = timeText()
            }, Store.briefHour, Store.briefMin, DateFormat.is24HourFormat(this)).show()
        }
        s.row(brief, R.drawable.ic_play, "Preview brief now", null) {
            MaterialAlertDialogBuilder(this).setTitle("Daily brief").setMessage(Brief.build()).setPositiveButton("OK", null).show()
        }

        s.section("VOICE")
        val voice = s.card(8)
        s.toggle(voice, R.drawable.ic_speaker, "Speak answers aloud", "Reads each new answer", Store.autoSpeak) { Store.autoSpeak = it }
        s.toggle(voice, R.drawable.ic_mic, "Send voice input automatically", "No need to tap send after speaking", Store.autoSendVoice) { Store.autoSendVoice = it }
        val rates = listOf("Slow (75%)" to 75, "Normal" to 100, "Fast (125%)" to 125, "Very fast (150%)" to 150)
        val rr = s.row(voice, R.drawable.ic_play, "Speaking speed", rates.firstOrNull { it.second == Store.ttsRate }?.first ?: "Normal") {}
        rr.root.setOnClickListener {
            choose("Speaking speed", rates.map { it.first }, rates.indexOfFirst { it.second == Store.ttsRate }) {
                Store.ttsRate = rates[it].second
                rr.sub.text = rates[it].first
            }
        }
        s.hint("The voice language is set in Settings > Voice language.", 6)

        s.section("AUTOMATION AND AI")
        val auto = s.card(8)
        s.row(auto, R.drawable.ic_bolt, "Automation rules", Triggers.all().count { it.on }.toString() + " active") { startActivity(Intent(this, TriggersActivity::class.java)) }
        s.toggle(auto, R.drawable.ic_flask, "Let the AI use tools (experimental)",
            "Small models may use them wrongly. Notes and reminders always ask you first.", Store.toolsAi) { Store.toolsAi = it }

        s.section("CHAT COMMANDS")
        val help = TextView(this).apply {
            text = Tools.helpText()
            setTextColor(getColor(R.color.v_text2))
            textSize = 13.5f
            setTextIsSelectable(true)
            setPadding(dp(16), dp(14), dp(16), dp(14))
        }
        s.card(8).addView(help)
    }

    private fun timeText(): String =
        DateFormat.format("h:mm a", java.util.Calendar.getInstance().apply {
            set(java.util.Calendar.HOUR_OF_DAY, Store.briefHour); set(java.util.Calendar.MINUTE, Store.briefMin)
        }.timeInMillis).toString()

    private fun calculator() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(22), dp(8), dp(22), 0) }
        val et: EditText = s.input("e.g. 15% of 2400 + sqrt(81)")
        val out = TextView(this).apply {
            textSize = 26f
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            setTextColor(getColor(R.color.v_text))
            setPadding(dp(4), dp(14), dp(4), dp(4))
            setTextIsSelectable(true)
            text = "="
        }
        et.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(c: CharSequence?, a: Int, b: Int, d: Int) {}
            override fun onTextChanged(c: CharSequence?, a: Int, b: Int, d: Int) {}
            override fun afterTextChanged(e: Editable?) {
                val t = e?.toString().orEmpty()
                if (t.isBlank()) { out.text = "="; out.setTextColor(getColor(R.color.v_text)); return }
                try {
                    out.text = "= " + Calc.eval(t); out.setTextColor(getColor(R.color.v_text))
                } catch (x: Exception) {
                    out.text = x.message ?: "Error"; out.setTextColor(getColor(R.color.v_muted))
                }
            }
        })
        box.addView(et)
        box.addView(out)
        MaterialAlertDialogBuilder(this).setTitle("Calculator").setView(box)
            .setNegativeButton("Close", null)
            .setPositiveButton("Copy result") { _, _ ->
                val r = out.text.toString().removePrefix("= ")
                (getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager).setPrimaryClip(android.content.ClipData.newPlainText("Result", r))
                toast("Copied")
            }.show()
    }
}
