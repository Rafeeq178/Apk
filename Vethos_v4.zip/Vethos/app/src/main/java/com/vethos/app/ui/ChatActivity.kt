package com.vethos.app.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.SystemClock
import android.speech.RecognizerIntent
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.vethos.app.R
import com.vethos.app.data.Chat
import com.vethos.app.data.ChatRepo
import com.vethos.app.data.Engine
import com.vethos.app.data.Msg
import com.vethos.app.data.NotesRepo
import com.vethos.app.data.Persona
import com.vethos.app.data.Personas
import com.vethos.app.data.Store
import com.vethos.app.data.Tool
import com.vethos.app.data.ToolResult
import com.vethos.app.data.Tools
import com.vethos.app.data.Voice
import com.vethos.app.databinding.ActivityChatBinding
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import kotlin.coroutines.resume
import kotlinx.coroutines.withContext
import java.io.File
import java.util.UUID

class ChatActivity : AppCompatActivity() {
    private lateinit var b: ActivityChatBinding
    private lateinit var chat: Chat
    private lateinit var persona: Persona
    private lateinit var adapter: ChatAdapter
    private var gen: Job? = null
    private var typer: Job? = null
    private var ready = false
    private var pendingSend: String? = null
    private var attached: Attach.Picked? = null
    private var speakToken = 0

    // live typing state
    private val target = StringBuilder()
    private var shown = 0
    private var generating = false
    private var autoFollow = true

    private val speech = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val t = r.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
        if (r.resultCode == RESULT_OK && !t.isNullOrBlank()) {
            b.input.setText(t); b.input.setSelection(t.length)
            if (Store.autoSendVoice) send(null)
        }
    }

    private val pickFile = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) attachFile(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityChatBinding.inflate(layoutInflater)
        setContentView(b.root)

        val existing = ChatRepo.get(intent.getStringExtra("id"))
        chat = existing ?: Chat(UUID.randomUUID().toString(), "New chat", System.currentTimeMillis(), mutableListOf())
        persona = if (existing != null) {
            Personas.get(existing.persona) ?: Personas.current()
        } else {
            Personas.get(intent.getStringExtra("persona")) ?: Personas.current()
        }
        chat.persona = persona.id
        if (existing == null) Personas.selectedId = persona.id

        adapter = ChatAdapter(chat.msgs, ::copy, ::feedback, ::share, ::speak) { regenerate() }
        val lm = LinearLayoutManager(this)
        b.rv.layoutManager = lm
        b.rv.adapter = adapter
        b.rv.itemAnimator = null
        b.rv.addOnScrollListener(object : RecyclerView.OnScrollListener() {
            override fun onScrollStateChanged(rv: RecyclerView, state: Int) {
                if (state == RecyclerView.SCROLL_STATE_DRAGGING) autoFollow = false
                else if (state == RecyclerView.SCROLL_STATE_IDLE && !rv.canScrollVertically(1)) autoFollow = true
            }
        })
        applyPersona()

        b.btnBack.setOnClickListener { finish() }
        b.btnHistory.setOnClickListener { startActivity(Intent(this, HistoryActivity::class.java)) }
        b.btnMore.setOnClickListener { showOptions() }
        b.btnAttach.setOnClickListener { pickFile.launch(arrayOf("*/*")) }
        b.attachClose.setOnClickListener { attached = null; b.attachBar.visibility = View.GONE }
        b.btnMic.setOnClickListener { listen() }
        b.send.setOnClickListener { if (gen?.isActive == true) gen?.cancel() else send(null) }

        val preset = intent.getStringExtra("preset")?.takeIf { it.isNotEmpty() }
        if (preset != null) {
            if (intent.getBooleanExtra("autosend", false)) pendingSend = preset
            else { b.input.setText(preset); b.input.setSelection(preset.length) }
        }

        listOf("Help me plan my day", "Explain inflation in simple words", "Give me 5 ideas for a small online business")
            .forEach { q ->
                b.sugs.addView(TextView(this).apply {
                    text = q
                    setBackgroundResource(R.drawable.bg_chip_sug)
                    setTextColor(getColor(R.color.v_text))
                    textSize = 15f
                    elevation = dp(1).toFloat()
                    setPadding(dp(18), dp(12), dp(18), dp(12))
                    setOnClickListener { send(q) }
                }, LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(12) })
            }

        refreshHero()
        scrollBottom()
        loadModel()
        intent.data?.let { attachFile(it, intent.getBooleanExtra("autosend", false)) }
    }

    private fun applyPersona() {
        b.title.text = persona.name
        b.heroTitle.text = persona.name
        b.heroSub.text = persona.desc
        val ic = Personas.icons[persona.ico.coerceIn(0, Personas.icons.lastIndex)]
        b.heroIcon.setImageResource(ic.res)
    }

    private fun refreshHero() {
        val empty = chat.msgs.isEmpty() && !adapter.thinking
        b.hero.visibility = if (empty) View.VISIBLE else View.GONE
        b.rv.visibility = if (empty) View.INVISIBLE else View.VISIBLE
    }

    private fun scrollBottom() = b.rv.post {
        if (adapter.itemCount > 0) b.rv.scrollToPosition(adapter.itemCount - 1)
    }

    private fun showBanner(text: String, onClick: (() -> Unit)?) {
        b.banner.text = text
        b.banner.visibility = View.VISIBLE
        b.banner.setOnClickListener { onClick?.invoke() }
    }

    private fun modelFile(): File? = Store.lastModel?.let { File(Store.modelsDir, it) }?.takeIf { it.exists() }

    private fun loadModel(force: Boolean = false, history: List<Msg> = chat.msgs) {
        val f = modelFile()
        if (f == null) {
            b.sub.text = "No model"
            showBanner("No model yet. Tap here to open the Library.") {
                startActivity(
                    Intent(this, MainActivity::class.java).putExtra("tab", 1)
                        .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                )
                finish()
            }
            return
        }
        b.sub.text = f.name.removeSuffix(".gguf")
        b.banner.visibility = View.GONE
        b.loading.visibility = View.VISIBLE
        ready = false
        val system = buildSystem(history)
        lifecycleScope.launch {
            try {
                withContext(Dispatchers.Default) { Engine.load(this@ChatActivity, f.absolutePath, chat.id, system, force) }
                ready = true
                pendingSend?.let { pendingSend = null; send(it) }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Throwable) {
                showBanner("Could not load this model: " + (e.message ?: "unknown error"), null)
            } finally {
                b.loading.visibility = View.GONE
            }
        }
    }

    private fun buildSystem(history: List<Msg>): String {
        val sb = StringBuilder(persona.prompt.ifBlank { Store.systemPrompt })
        val best = Store.steer("best")
        if (best.isNotEmpty()) sb.append("\n\nExamples of answers the user liked:\n").append(best.joinToString("\n---\n"))
        val bad = Store.steer("bad")
        if (bad.isNotEmpty()) sb.append("\n\nAvoid answers like these (the user disliked them):\n").append(bad.joinToString("\n---\n"))
        if (Store.toolsAi) sb.append("\n\n").append(Tools.AI_INSTRUCTIONS)
        val mem = Store.memory
        if (history.isNotEmpty() && mem > 0) {
            sb.append("\n\nEarlier in this conversation:\n")
            history.takeLast(mem).forEach {
                sb.append(if (it.role == "user") "User: " else "Assistant: ").append(Attach.display(it.text).take(400)).append('\n')
            }
        }
        return sb.toString()
    }

    private fun listen() {
        try {
            speech.launch(
                Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                    .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    .putExtra(RecognizerIntent.EXTRA_LANGUAGE, Store.voiceLang)
            )
        } catch (e: Exception) {
            toast("Voice input isn't available on this phone")
        }
    }

    private fun attachFile(uri: android.net.Uri, thenSend: Boolean = false) {
        lifecycleScope.launch {
            try {
                val p = withContext(Dispatchers.IO) { Attach.read(this@ChatActivity, uri) }
                attached = p
                b.attachName.text = p.name + if (p.truncated) "  (long file: the most relevant parts are used)" else ""
                b.attachBar.visibility = View.VISIBLE
                if (thenSend) send(null)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Throwable) {
                toast(e.message ?: "Could not read this file")
            }
        }
    }

    private fun send(preset: String?) {
        val q = (preset ?: b.input.text.toString()).trim()
        val file = attached
        if (q.isEmpty() && file == null) return
        if (gen?.isActive == true) return
        // commands like /calc, /note, /remind work even before a model is loaded
        val slash = if (file == null) Tools.parseSlash(q) else null
        if (slash == null && !ready) {
            if (b.loading.visibility == View.VISIBLE) { pendingSend = q; b.input.setText("") }
            else toast("Select a model first")
            return
        }
        b.input.setText("")
        val userText = if (file != null) Attach.wrap(file, q) else q
        attached = null
        b.attachBar.visibility = View.GONE
        chat.msgs.add(Msg("user", userText))
        if (chat.title == "New chat") chat.title = (if (q.isNotEmpty()) q else "File: " + file?.name).take(40)
        adapter.notifyItemInserted(chat.msgs.lastIndex)
        if (file != null) { generate(userText); return }
        toolsThenGenerate(q, slash, chat.msgs.lastIndex)
    }

    private fun showThinking(on: Boolean) {
        if (adapter.thinking == on) return
        adapter.thinking = on
        if (on) adapter.notifyItemInserted(chat.msgs.size) else adapter.notifyItemRemoved(chat.msgs.size)
    }

    private fun addAi(text: String) {
        chat.msgs.add(Msg("ai", text))
        adapter.notifyDataSetChanged()
        setBusy(false)
        refreshHero()
        scrollBottom()
        if (Store.keepHistory) ChatRepo.save(chat)
    }

    /**
     * Runs tools first (slash commands, automation rules, links), then either shows the tool's answer
     * or hands the question plus the tool result to the model.
     */
    private fun toolsThenGenerate(q: String, slash: Pair<Tool, String>?, userIdx: Int) {
        showThinking(true); setBusy(true); refreshHero(); scrollBottom()
        gen = lifecycleScope.launch {
            val plan = try {
                Tools.plan(q, slash, ready)
            } catch (e: CancellationException) {
                showThinking(false); setBusy(false)
                throw e
            } catch (e: Throwable) {
                Tools.Plan(reply = "Tool error: " + (e.message ?: e.javaClass.simpleName))
            }
            showThinking(false)
            val reply = plan.reply
            if (reply != null) { addAi(reply); return@launch }
            val prompt = plan.prompt ?: q
            if (prompt != q && userIdx in chat.msgs.indices) {
                chat.msgs[userIdx].text = prompt // keep the tool result with the question so Regenerate works
                adapter.notifyItemChanged(userIdx)
            }
            generate(prompt)
        }
    }

    private fun generate(prompt: String, hop: Int = 0) {
        showThinking(true)
        refreshHero(); scrollBottom(); setBusy(true)
        autoFollow = true
        target.setLength(0); shown = 0; generating = true
        val t0 = SystemClock.uptimeMillis()
        gen = lifecycleScope.launch {
            var ai: Msg? = null
            var tFirst = 0L
            var cancelled = false
            try {
                Engine.send(this@ChatActivity, prompt, Store.maxTokens).collect { tok ->
                    if (ai == null) {
                        tFirst = SystemClock.uptimeMillis()
                        Store.lastFirst = (tFirst - t0) / 1000f
                        val m = Msg("ai", "")
                        ai = m
                        adapter.thinking = false
                        adapter.streaming = true
                        chat.msgs.add(m)
                        adapter.notifyDataSetChanged()
                        startTyper()
                    }
                    target.append(tok)
                    ai!!.text = target.toString()
                }
                generating = false
                typer?.join() // let the typing animation finish
            } catch (e: CancellationException) {
                cancelled = true
                throw e
            } catch (e: Throwable) {
                toast("Error: " + (e.message ?: "generation failed"))
            } finally {
                generating = false
                typer?.cancel()
                ai?.text = target.toString()
                if (!cancelled && ai != null && tFirst > 0) {
                    val secs = (SystemClock.uptimeMillis() - tFirst) / 1000f
                    if (secs > 0.3f) Store.lastTps = (target.length / 4f) / secs
                }
                adapter.thinking = false
                adapter.streaming = false
                adapter.endLive()
                adapter.notifyDataSetChanged()
                setBusy(false)
                refreshHero()
                if (Store.keepHistory) ChatRepo.save(chat)
                scrollBottom()
                val done = ai
                if (!cancelled && done != null) afterAnswer(done, hop)
            }
        }
    }

    /** After an answer: let the AI call a tool (experimental), or read the answer aloud. */
    private fun afterAnswer(m: Msg, hop: Int) {
        if (Store.toolsAi && hop < 2) {
            val call = Tools.findModelCall(m.text)
            if (call != null) { runModelTool(m, call, hop); return }
        }
        if (Store.autoSpeak && m.text.isNotBlank()) speakMsg(chat.msgs.indexOf(m))
    }

    private fun runModelTool(m: Msg, call: Tools.Call, hop: Int) {
        m.text = "\uD83D\uDD27 " + call.tool.label + ": " + call.arg.take(120)
        adapter.notifyDataSetChanged()
        gen = lifecycleScope.launch {
            setBusy(true)
            // tools that change data (notes, reminders) always ask the user first
            val ok = !call.tool.writes || askAllow(call)
            val r = if (ok) Tools.run(call.tool, call.arg) else ToolResult(false, "The user did not allow this action.")
            generate("Tool result (" + call.tool.id + "):\n" + Tools.clip(r.text) + "\n\nNow answer the user's last request using this result.", hop + 1)
        }
    }

    private suspend fun askAllow(call: Tools.Call): Boolean = suspendCancellableCoroutine { cont ->
        val d = MaterialAlertDialogBuilder(this)
            .setTitle("Allow this action?")
            .setMessage("The AI wants to use \"" + call.tool.label + "\":\n\n" + call.arg.take(300))
            .setNegativeButton("Deny") { _, _ -> if (cont.isActive) cont.resume(false) }
            .setPositiveButton("Allow") { _, _ -> if (cont.isActive) cont.resume(true) }
            .setOnCancelListener { if (cont.isActive) cont.resume(false) }
            .show()
        cont.invokeOnCancellation { try { d.dismiss() } catch (_: Throwable) { } }
    }

    /** Reveals the received text a few characters per frame, with a blinking dot at the end. */
    private fun startTyper() {
        typer?.cancel()
        typer = lifecycleScope.launch {
            var lastShown = -1
            var lastOn = true
            while (true) {
                delay(22)
                val backlog = target.length - shown
                if (backlog > 0) shown += minOf(backlog, 1 + backlog / 10)
                if (!generating && shown >= target.length) break
                val on = shown < target.length || (SystemClock.uptimeMillis() / 450) % 2 == 0L
                if (shown != lastShown || on != lastOn) {
                    lastShown = shown; lastOn = on
                    adapter.updateLive(b.rv, target.substring(0, shown), on)
                    if (autoFollow && b.rv.canScrollVertically(1)) b.rv.scrollBy(0, 400)
                }
            }
        }
    }

    private fun setBusy(busy: Boolean) {
        b.send.setImageResource(if (busy) R.drawable.ic_stop else R.drawable.ic_send)
    }

    private fun speak(pos: Int) {
        if (adapter.speakingPos == pos && Voice.speaking) { Voice.stop(); return }
        speakMsg(pos)
    }

    private fun speakMsg(pos: Int) {
        val m = chat.msgs.getOrNull(pos) ?: return
        val tok = ++speakToken
        adapter.speakingPos = pos
        Voice.speak(this, m.text) {
            runOnUiThread {
                if (tok == speakToken && !isDestroyed) {
                    val old = adapter.speakingPos
                    adapter.speakingPos = -1
                    if (old in chat.msgs.indices) adapter.notifyItemChanged(old)
                }
            }
        }
        adapter.notifyItemChanged(pos)
    }

    private fun saveLastToNotes() {
        val last = chat.msgs.lastOrNull { it.role == "ai" && it.text.isNotBlank() }
        if (last == null) { toast("No answer to save yet"); return }
        NotesRepo.add("", last.text)
        toast("Saved to Notes")
    }

    private fun copy(m: Msg) {
        (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager)
            .setPrimaryClip(ClipData.newPlainText("Vethos", m.text))
        toast("Copied")
    }

    private fun share(m: Msg) = shareText(m.text)

    private fun shareText(text: String) {
        startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, text), "Share"))
    }

    private fun feedback(pos: Int, v: Int) {
        val m = chat.msgs.getOrNull(pos) ?: return
        m.fb = if (m.fb == v) 0 else v
        if (m.fb != 0) {
            val q = chat.msgs.take(pos).lastOrNull { it.role == "user" }?.text ?: ""
            Store.addSteer(if (v > 0) "best" else "bad", "Q: " + q.take(200) + "\nA: " + m.text.take(300))
            toast(if (v > 0) "Saved as a good answer" else "Saved as a bad answer")
        }
        adapter.notifyItemChanged(pos)
        if (Store.keepHistory) ChatRepo.save(chat)
    }

    private fun regenerate() {
        if (gen?.isActive == true) return
        val lastAi = chat.msgs.lastOrNull() ?: return
        if (lastAi.role != "ai") return
        val userIdx = chat.msgs.indexOfLast { it.role == "user" }
        if (userIdx < 0) return
        val prompt = chat.msgs[userIdx].text
        val slash = Tools.parseSlash(prompt)
        if (slash == null && !ready) return
        chat.msgs.removeAt(chat.msgs.lastIndex)
        adapter.notifyDataSetChanged()
        if (slash != null) { toolsThenGenerate(prompt, slash, userIdx); return }
        // The engine remembers the old answer, so reload it with the history before the last question.
        val history = chat.msgs.take(userIdx)
        val f = modelFile() ?: return
        b.loading.visibility = View.VISIBLE
        ready = false
        val system = buildSystem(history)
        lifecycleScope.launch {
            try {
                withContext(Dispatchers.Default) { Engine.load(this@ChatActivity, f.absolutePath, chat.id, system, true) }
                ready = true
                b.loading.visibility = View.GONE
                generate(prompt)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Throwable) {
                b.loading.visibility = View.GONE
                showBanner("Could not load this model: " + (e.message ?: "unknown error"), null)
            }
        }
    }

    private fun showOptions() {
        showSheet("Options", listOf(
            SheetRow(R.drawable.ic_plus, "New chat") {
                gen?.cancel()
                startActivity(Intent(this, ChatActivity::class.java))
                finish()
            },
            SheetRow(R.drawable.ic_chat, "Change personality") { showPersonas() },
            SheetRow(R.drawable.ic_note, "Save last answer to Notes") { saveLastToNotes() },
            SheetRow(R.drawable.ic_speaker, if (Voice.speaking) "Stop reading" else "Read last answer aloud") {
                if (Voice.speaking) Voice.stop()
                else {
                    val i = chat.msgs.indexOfLast { it.role == "ai" }
                    if (i >= 0) speakMsg(i) else toast("No answer to read yet")
                }
            },
            SheetRow(R.drawable.ic_bolt, "Chat commands and tools") {
                MaterialAlertDialogBuilder(this).setTitle("Commands").setMessage(Tools.helpText()).setPositiveButton("OK", null).show()
            },
            SheetRow(R.drawable.ic_share, "Export chat as text") { exportChat() },
            SheetRow(R.drawable.ic_trash, "Clear conversation") {
                confirm("Clear conversation?", "All messages in this chat will be removed.", "Clear") { clearChat() }
            },
        ))
    }

    private fun showPersonas() {
        showSheet("Personality", Personas.all().map { p ->
            SheetRow(Personas.icons[p.ico.coerceIn(0, Personas.icons.lastIndex)].res, p.name, p.desc, p.id == persona.id) {
                if (p.id != persona.id) {
                    gen?.cancel()
                    persona = p
                    chat.persona = p.id
                    Personas.selectedId = p.id
                    applyPersona()
                    loadModel(force = true)
                }
            }
        })
    }

    private fun exportChat() {
        if (chat.msgs.isEmpty()) { toast("Nothing to export yet"); return }
        shareText(chat.msgs.joinToString("\n\n") { (if (it.role == "user") "You: " else persona.name + ": ") + Attach.display(it.text) })
    }

    private fun clearChat() {
        gen?.cancel()
        chat.msgs.clear()
        chat.title = "New chat"
        adapter.notifyDataSetChanged()
        ChatRepo.delete(chat.id)
        refreshHero()
        loadModel(force = true, history = emptyList())
    }

    override fun onStop() {
        super.onStop()
        Voice.stop()
        if (chat.msgs.isNotEmpty() && Store.keepHistory) ChatRepo.save(chat)
    }
}
