package com.vethos.app.data

import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.IOException
import java.net.HttpURLConnection
import java.net.InetAddress
import java.net.SocketTimeoutException
import java.net.URL
import java.net.URLDecoder
import java.net.URLEncoder
import java.net.UnknownHostException
import java.nio.charset.Charset

/** URL reading and web search. Plain HTTPS only, no API keys, nothing is sent except the request itself. */
object Web {
    private const val UA = "Mozilla/5.0 (Linux; Android 13; Vethos) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Mobile Safari/537.36"
    private const val MAX_BYTES = 1_500_000

    class WebError(msg: String) : Exception(msg)
    class Page(val url: String, val title: String, val text: String)
    class Hit(val title: String, val url: String, val snippet: String)

    fun friendly(e: Throwable): String = when (e) {
        is WebError -> e.message ?: "Web error"
        is UnknownHostException -> "No internet connection (or the website does not exist)"
        is SocketTimeoutException -> "The website took too long to answer"
        is IOException -> "Network error: " + (e.message ?: "connection failed")
        else -> e.message ?: e.javaClass.simpleName
    }

    // ---------------------------------------------------------------- URL helpers

    /** Finds a link inside a message and removes punctuation that belongs to the sentence, not to the link. */
    fun normalizeUrl(raw: String): String {
        var u = raw.trim().trimStart('<', '(', '[', '"', '\'')
        while (u.isNotEmpty()) {
            val last = u.last()
            val strip = when (last) {
                '.', ',', ';', ':', '!', '?', '"', '\'', '>', ']', '}' -> true
                ')' -> u.count { it == ')' } > u.count { it == '(' }
                else -> false
            }
            if (strip) u = u.dropLast(1) else break
        }
        if (u.startsWith("http://", true)) u = "https://" + u.substring(7)
        else if (!u.startsWith("https://", true)) {
            if (Regex("^[\\w.-]+\\.[a-z]{2,}(/\\S*)?$", RegexOption.IGNORE_CASE).matches(u)) u = "https://$u"
            else throw WebError("That does not look like a web address")
        }
        return u
    }

    private fun checkHost(u: URL) {
        val h = u.host.lowercase()
        if (h.isEmpty() || h == "localhost" || h.endsWith(".local") || h.endsWith(".internal") || h.endsWith(".localhost")) {
            throw WebError("This address is not allowed")
        }
        if (u.port != -1 && u.port != 443) throw WebError("Only the normal https port is allowed")
        val addrs = try { InetAddress.getAllByName(h) } catch (e: UnknownHostException) {
            throw WebError("No internet connection (or the website does not exist)")
        }
        for (a in addrs) {
            val b = a.address
            val ula = b.size == 16 && (b[0].toInt() and 0xFE) == 0xFC
            val cgnat = b.size == 4 && (b[0].toInt() and 0xFF) == 100 && (b[1].toInt() and 0xC0) == 64
            if (a.isAnyLocalAddress || a.isLoopbackAddress || a.isLinkLocalAddress || a.isSiteLocalAddress || ula || cgnat) {
                throw WebError("This address is not allowed (private network)")
            }
        }
    }

    /** Opens the URL, follows up to 5 redirects by hand (every hop is checked again) and returns the open connection. */
    private fun open(start: String, accept: String): Pair<HttpURLConnection, String> {
        var url = start
        for (hop in 0..5) {
            val u = URL(url)
            if (!u.protocol.equals("https", true)) throw WebError("Only https:// pages can be opened")
            checkHost(u)
            val c = u.openConnection() as HttpURLConnection
            c.instanceFollowRedirects = false
            c.connectTimeout = 12_000
            c.readTimeout = 15_000
            c.setRequestProperty("User-Agent", UA)
            c.setRequestProperty("Accept", accept)
            c.setRequestProperty("Accept-Language", "en-US,en;q=0.9")
            val code = c.responseCode
            if (code in 300..399) {
                val loc = c.getHeaderField("Location")
                c.disconnect()
                if (loc.isNullOrBlank()) throw WebError("The website sent a bad redirect")
                var next = URL(u, loc).toString()
                if (next.startsWith("http://", true)) next = "https://" + next.substring(7)
                url = next
                continue
            }
            if (code !in 200..299) {
                c.disconnect()
                throw WebError("The website answered with HTTP $code")
            }
            return c to url
        }
        throw WebError("Too many redirects")
    }

    private fun readBody(c: HttpURLConnection): ByteArray {
        val out = ByteArrayOutputStream()
        val buf = ByteArray(16 * 1024)
        var total = 0
        c.inputStream.use { ins ->
            while (total < MAX_BYTES) {
                val n = ins.read(buf, 0, minOf(buf.size, MAX_BYTES - total))
                if (n < 0) break
                out.write(buf, 0, n)
                total += n
            }
        }
        return out.toByteArray()
    }

    private fun decode(bytes: ByteArray, contentType: String?): String {
        var cs = Regex("charset=([\\w-]+)", RegexOption.IGNORE_CASE).find(contentType ?: "")?.groupValues?.get(1)
        if (cs == null) {
            val head = String(bytes, 0, minOf(bytes.size, 3000), Charsets.ISO_8859_1)
            cs = Regex("<meta[^>]+charset=[\"']?([\\w-]+)", RegexOption.IGNORE_CASE).find(head)?.groupValues?.get(1)
        }
        val charset = try { Charset.forName(cs ?: "UTF-8") } catch (_: Exception) { Charsets.UTF_8 }
        return String(bytes, charset)
    }

    // ---------------------------------------------------------------- fetch

    fun fetch(raw: String, maxChars: Int = 3000): Page {
        val (c, finalUrl) = open(
            normalizeUrl(raw),
            "text/html,application/xhtml+xml,text/plain;q=0.9,application/json;q=0.8,*/*;q=0.5"
        )
        try {
            val type = (c.contentType ?: "").lowercase()
            val okType = type.isEmpty() || type.startsWith("text/") || type.contains("json") || type.contains("xml")
            if (!okType) throw WebError("This link is not a text page (" + type.substringBefore(';') + ")")
            val body = decode(readBody(c), c.contentType)
            val isHtml = type.contains("html") || body.trimStart().startsWith("<")
            val title = if (isHtml)
                decodeEntities(stripTags(Regex("(?is)<title[^>]*>(.*?)</title>").find(body)?.groupValues?.get(1) ?: "")).trim()
            else ""
            var text = if (isHtml) htmlToText(body) else body.trim()
            if (text.isBlank()) throw WebError("The page has no readable text (it may need JavaScript)")
            if (text.length > maxChars) text = text.take(maxChars) + "\n[...page cut]"
            return Page(finalUrl, title.ifEmpty { finalUrl }, text)
        } finally {
            c.disconnect()
        }
    }

    // ---------------------------------------------------------------- HTML to text

    private fun stripTags(s: String) = s.replace(Regex("(?s)<[^>]+>"), "")

    fun htmlToText(html: String): String {
        var s = html
        val main = Regex("(?is)<(article|main)\\b[^>]*>(.*)</\\1>").find(s)
        if (main != null && main.groupValues[2].length > 600) s = main.groupValues[2]
        s = s.replace(Regex("(?is)<(script|style|noscript|svg|head|nav|footer|iframe|template)\\b.*?</\\1>"), " ")
        s = s.replace(Regex("(?s)<!--.*?-->"), " ")
        s = s.replace(Regex("(?i)<br\\s*/?>|</(p|div|li|tr|h[1-6]|section|article|blockquote|pre|table|ul|ol)>"), "\n")
        s = s.replace(Regex("(?i)<li\\b[^>]*>"), "\n\u2022 ")
        s = s.replace(Regex("(?s)<[^>]+>"), " ")
        s = decodeEntities(s)
        s = s.replace(Regex("[ \\t\\u00A0]+"), " ")
        s = s.replace(Regex(" ?\\n ?"), "\n").replace(Regex("\\n{3,}"), "\n\n")
        return s.trim()
    }

    private val entities = mapOf(
        "nbsp" to " ", "amp" to "&", "lt" to "<", "gt" to ">", "quot" to "\"", "apos" to "'", "mdash" to "\u2014",
        "ndash" to "\u2013", "hellip" to "\u2026", "rsquo" to "\u2019", "lsquo" to "\u2018", "ldquo" to "\u201C",
        "rdquo" to "\u201D", "copy" to "\u00A9", "bull" to "\u2022", "middot" to "\u00B7", "laquo" to "\u00AB", "raquo" to "\u00BB"
    )

    fun decodeEntities(s: String): String {
        if (!s.contains('&')) return s
        return Regex("&(#x?[0-9a-fA-F]+|[a-zA-Z]+);").replace(s) { m ->
            val g = m.groupValues[1]
            when {
                g.startsWith("#x") || g.startsWith("#X") -> cp(g.substring(2).toIntOrNull(16), m.value)
                g.startsWith("#") -> cp(g.substring(1).toIntOrNull(), m.value)
                else -> entities[g.lowercase()] ?: m.value
            }
        }
    }

    private fun cp(v: Int?, fallback: String): String =
        if (v == null || v < 1 || v > 0x10FFFF || (v in 0xD800..0xDFFF)) fallback else String(Character.toChars(v))

    // ---------------------------------------------------------------- search

    fun search(q: String, max: Int = 5): List<Hit> {
        var first: Exception? = null
        try {
            val r = ddg(q, max)
            if (r.isNotEmpty()) return r
        } catch (e: Exception) {
            first = e
        }
        try {
            return wiki(q, max)
        } catch (e: Exception) {
            throw first ?: e
        }
    }

    private fun realUrl(h: String): String {
        var href = decodeEntities(h)
        if (href.startsWith("//")) href = "https:$href"
        val m = Regex("[?&]uddg=([^&]+)").find(href)
        if (m != null) href = try { URLDecoder.decode(m.groupValues[1], "UTF-8") } catch (_: Exception) { href }
        return href
    }

    private fun ddg(q: String, max: Int): List<Hit> {
        val (c, _) = open("https://html.duckduckgo.com/html/?q=" + URLEncoder.encode(q, "UTF-8"), "text/html")
        val html = try { decode(readBody(c), c.contentType) } finally { c.disconnect() }
        val out = ArrayList<Hit>()
        var title = ""
        var url = ""
        var snip = ""
        fun flush() {
            if (url.isNotEmpty() && url.startsWith("http") && !url.contains("duckduckgo.com")) out.add(Hit(title, url, snip))
            title = ""; url = ""; snip = ""
        }
        for (m in Regex("(?is)<a\\b([^>]*)>(.*?)</a>").findAll(html)) {
            val attrs = m.groupValues[1]
            if (attrs.contains("result__a")) {
                flush()
                if (out.size >= max) break
                val href = Regex("href=\"([^\"]+)\"").find(attrs)?.groupValues?.get(1) ?: continue
                url = realUrl(href)
                title = decodeEntities(stripTags(m.groupValues[2])).trim()
            } else if (attrs.contains("result__snippet") && url.isNotEmpty() && snip.isEmpty()) {
                snip = decodeEntities(stripTags(m.groupValues[2])).replace(Regex("\\s+"), " ").trim()
            }
        }
        if (out.size < max) flush()
        return out.take(max)
    }

    private fun wiki(q: String, max: Int): List<Hit> {
        val lang = if (q.any { it.code in 0x0600..0x06FF }) "ur" else "en"
        val (c, _) = open(
            "https://$lang.wikipedia.org/w/api.php?action=query&list=search&format=json&utf8=1&srlimit=$max&srsearch=" +
                URLEncoder.encode(q, "UTF-8"),
            "application/json"
        )
        val json = try { decode(readBody(c), c.contentType) } finally { c.disconnect() }
        val arr = JSONObject(json).optJSONObject("query")?.optJSONArray("search") ?: return emptyList()
        val out = ArrayList<Hit>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val t = o.optString("title")
            if (t.isEmpty()) continue
            val link = "https://$lang.wikipedia.org/wiki/" + URLEncoder.encode(t.replace(' ', '_'), "UTF-8")
            out.add(Hit(t, link, decodeEntities(stripTags(o.optString("snippet"))).trim()))
        }
        return out
    }
}
