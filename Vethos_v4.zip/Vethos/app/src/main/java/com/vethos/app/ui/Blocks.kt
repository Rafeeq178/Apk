package com.vethos.app.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.text.SpannableStringBuilder
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import com.vethos.app.R
import com.vethos.app.databinding.ViewCodeBinding

/**
 * Draws an AI answer: normal text + dark code blocks (```lang ... ```) with a "Copy" button on each block.
 * Works while the answer is still streaming (an unfinished code block is drawn as a code block too).
 */
object Blocks {
    sealed class Seg {
        class Text(val s: String) : Seg()
        class Code(val lang: String, val s: String) : Seg()
    }

    fun split(src: String): List<Seg> {
        val out = ArrayList<Seg>()
        var i = 0
        while (i < src.length) {
            val f = src.indexOf("```", i)
            if (f < 0) { addText(out, src.substring(i)); break }
            addText(out, src.substring(i, f))
            val afterFence = f + 3
            val nl = src.indexOf('\n', afterFence)
            if (nl < 0) { out.add(Seg.Code(src.substring(afterFence).trim(), "")); break }
            val lang = src.substring(afterFence, nl).trim()
            val end = src.indexOf("```", nl + 1)
            if (end < 0) {
                // still streaming: hide a half-typed closing fence
                out.add(Seg.Code(lang, src.substring(nl + 1).trimEnd('\n').trimEnd('`').trimEnd('\n')))
                break
            }
            out.add(Seg.Code(lang, src.substring(nl + 1, end).trimEnd('\n')))
            i = end + 3
        }
        return out
    }

    private fun addText(out: MutableList<Seg>, s: String) {
        val t = s.trim('\n')
        if (t.isNotBlank()) out.add(Seg.Text(t))
    }

    /** cursor: null = finished answer (no dot), true/false = streaming dot on/off. */
    fun bind(box: LinearLayout, src: String, cursor: Boolean?) {
        val ctx = box.context
        val segs = split(src).toMutableList()
        if (segs.isEmpty()) segs.add(Seg.Text(""))

        var same = box.childCount == segs.size
        if (same) {
            for (k in segs.indices) {
                val isCode = box.getChildAt(k).tag == "code"
                if ((segs[k] is Seg.Code) != isCode) { same = false; break }
            }
        }
        if (!same) {
            box.removeAllViews()
            segs.forEach { s -> box.addView(if (s is Seg.Code) makeCode(box) else makeText(ctx)) }
        }

        val codes = segs.filterIsInstance<Seg.Code>().map { it.lang to it.s }
        segs.forEachIndexed { k, s ->
            val v = box.getChildAt(k)
            val c = if (k == segs.lastIndex) cursor else null
            when (s) {
                is Seg.Code -> fillCode(v, s, c, codes)
                is Seg.Text -> fillText(v as TextView, s, c)
            }
        }
    }

    private fun makeText(ctx: Context): TextView = TextView(ctx).apply {
        tag = "text"
        textSize = 16f
        setLineSpacing(0f, 1.2f)
        setTextColor(ctx.getColor(R.color.v_text))
        layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
    }

    private fun makeCode(box: LinearLayout): View {
        val b = ViewCodeBinding.inflate(LayoutInflater.from(box.context), box, false)
        b.root.tag = "code"
        b.copy.setOnClickListener {
            val raw = b.code.tag as? String ?: ""
            (box.context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager)
                .setPrimaryClip(ClipData.newPlainText("Vethos code", raw))
            b.copy.text = "Copied"
            b.copy.postDelayed({ b.copy.text = "Copy" }, 1500)
        }
        return b.root
    }

    private fun fillText(tv: TextView, s: Seg.Text, cursor: Boolean?) {
        val key = "t|" + cursor + "|" + s.s
        if (tv.getTag(R.id.seg_key) == key) return
        tv.setTag(R.id.seg_key, key)
        tv.text = if (cursor == null) Md.render(s.s) else Md.withCursor(tv.context, s.s, cursor)
    }

    private fun fillCode(v: View, s: Seg.Code, cursor: Boolean?, all: List<Pair<String, String>>) {
        val b = ViewCodeBinding.bind(v)
        // "Run" shows only on finished html / svg blocks; it opens the offline runner with all css / js blocks of the answer
        b.runBtn.visibility = if (cursor == null && RunnerActivity.isRunnable(s.lang)) View.VISIBLE else View.GONE
        b.runBtn.setOnClickListener { RunnerActivity.openBlocks(v.context, all) }
        val key = "c|" + cursor + "|" + s.lang + "|" + s.s
        if (v.getTag(R.id.seg_key) == key) return
        v.setTag(R.id.seg_key, key)
        b.lang.text = s.lang.ifEmpty { "code" }
        b.code.tag = s.s
        b.code.text = if (cursor == null) s.s else Md.addCursor(b.root.context, SpannableStringBuilder(s.s), cursor)
    }
}
