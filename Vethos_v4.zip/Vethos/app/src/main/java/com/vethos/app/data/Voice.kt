package com.vethos.app.data

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale

/** Read-aloud (text to speech). Voice INPUT uses the system speech screen and lives in ChatActivity. */
object Voice {
    private var tts: TextToSpeech? = null
    private var ready = false
    private var queued: String? = null
    private var gen = 0
    private var left = 0
    private var onFinish: (() -> Unit)? = null

    @Volatile var speaking = false
        private set

    fun speak(ctx: Context, text: String, finish: (() -> Unit)? = null) {
        val clean = clean(text)
        stop()
        if (clean.isBlank()) { finish?.invoke(); return }
        onFinish = finish
        speaking = true
        val t = tts
        if (t != null && ready) { say(clean); return }
        queued = clean
        if (t == null) {
            tts = TextToSpeech(ctx.applicationContext) { status ->
                if (status == TextToSpeech.SUCCESS) {
                    ready = true
                    val q = queued
                    queued = null
                    if (q != null) say(q)
                } else {
                    tts = null
                    ready = false
                    queued = null
                    done()
                }
            }
        }
    }

    fun stop() {
        gen++
        queued = null
        try { tts?.stop() } catch (_: Throwable) { }
        if (speaking) done() else onFinish = null
    }

    private fun done() {
        speaking = false
        val f = onFinish
        onFinish = null
        f?.invoke()
    }

    private fun say(text: String) {
        val t = tts ?: return
        try {
            val r = t.setLanguage(Locale.forLanguageTag(Store.voiceLang))
            if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) t.setLanguage(Locale.getDefault())
            t.setSpeechRate(Store.ttsRate / 100f)
            val max = minOf(TextToSpeech.getMaxSpeechInputLength() - 100, 3500)
            val chunks = chunk(text, max)
            val g = ++gen
            left = chunks.size
            t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {}
                override fun onDone(utteranceId: String?) { part(utteranceId) }
                @Deprecated("Deprecated in Java")
                override fun onError(utteranceId: String?) { part(utteranceId) }
                override fun onError(utteranceId: String?, errorCode: Int) { part(utteranceId) }
            })
            chunks.forEachIndexed { i, c ->
                t.speak(c, if (i == 0) TextToSpeech.QUEUE_FLUSH else TextToSpeech.QUEUE_ADD, null, "g$g-$i")
            }
        } catch (_: Throwable) {
            done()
        }
    }

    private fun part(id: String?) {
        val g = id?.removePrefix("g")?.substringBefore('-')?.toIntOrNull() ?: return
        synchronized(this) {
            if (g != gen) return
            left--
            if (left <= 0) done()
        }
    }

    private fun clean(text: String): String {
        var s = text.replace(Regex("(?s)```.*?(```|$)"), " code block. ")
        s = s.replace(Regex("https?://\\S+"), " link ")
        s = s.replace(Regex("[*_`#>|]+"), " ")
        return s.replace(Regex("\\s+"), " ").trim()
    }

    private fun chunk(text: String, max: Int): List<String> {
        val out = ArrayList<String>()
        val cur = StringBuilder()
        for (part in text.split(Regex("(?<=[.!?\u06D4\u061F])\\s+"))) {
            var p = part
            while (p.length > max) {
                if (cur.isNotEmpty()) { out.add(cur.toString()); cur.setLength(0) }
                out.add(p.substring(0, max))
                p = p.substring(max)
            }
            if (cur.isNotEmpty() && cur.length + p.length + 1 > max) { out.add(cur.toString()); cur.setLength(0) }
            if (cur.isNotEmpty()) cur.append(' ')
            cur.append(p)
        }
        if (cur.isNotEmpty()) out.add(cur.toString())
        return out
    }
}
