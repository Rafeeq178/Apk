package com.vethos.app.ui

import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.res.ColorStateList
import android.os.Bundle
import android.widget.ImageView
import android.widget.LinearLayout
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.vethos.app.R
import com.vethos.app.data.Persona
import com.vethos.app.data.Personas
import com.vethos.app.databinding.ActivityPersonasBinding
import com.vethos.app.databinding.DialogPersonaBinding
import com.vethos.app.databinding.ItemPersonaBinding

/** My Offline Chatbots: create, edit, duplicate, delete, export and import personalities. */
class PersonasActivity : AppCompatActivity() {
    private lateinit var b: ActivityPersonasBinding
    private var pendingExport: String? = null

    private val saveFile = registerForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        val t = pendingExport
        pendingExport = null
        if (uri != null && t != null) writeTextUri(uri, t)
    }

    private val openFile = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri == null) return@registerForActivityResult
        try { doImport(readTextUri(uri, Personas.MAX_IMPORT_CHARS)) }
        catch (e: Exception) { toast(e.message ?: "Could not read this file") }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityPersonasBinding.inflate(layoutInflater)
        setContentView(b.root)
        b.btnMenu.setOnClickListener { finish() }
        b.btnNew.setOnClickListener { edit(null) }
        b.btnImport.setOnClickListener { importSheet() }
        b.btnExport.setOnClickListener { exportSheet("my-personalities", Personas.all().toList()) }
        render()
    }

    private fun render() {
        b.list.removeAllViews()
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundResource(R.drawable.bg_card)
        }
        val all = Personas.all()
        all.forEachIndexed { idx, p ->
            val r = ItemPersonaBinding.inflate(layoutInflater, card, false)
            val ic = Personas.icons[p.ico.coerceIn(0, Personas.icons.lastIndex)]
            r.icon.setImageResource(ic.res)
            r.icon.imageTintList = ColorStateList.valueOf(getColor(R.color.v_blue))
            r.title.text = p.name
            r.sub.text = p.desc
            r.trail.setImageResource(R.drawable.ic_more)
            r.trail.setBackgroundResource(0)
            r.trail.imageTintList = ColorStateList.valueOf(getColor(R.color.v_muted))
            r.trail.setPadding(dp(8), dp(8), dp(8), dp(8))
            (r.root.layoutParams as LinearLayout.LayoutParams).apply { topMargin = 0 }
            r.root.setBackgroundResource(0)
            r.root.setOnClickListener { menu(p) }
            card.addView(r.root)
            if (idx < all.lastIndex) card.addView(android.view.View(this).apply {
                setBackgroundColor(getColor(R.color.v_line))
            }, LinearLayout.LayoutParams(-1, 1).apply { marginStart = dp(76); marginEnd = dp(16) })
        }
        b.list.addView(card)
    }

    private fun menu(p: Persona) {
        val rows = ArrayList<SheetRow>()
        rows.add(SheetRow(R.drawable.ic_chat, "Start a chat") {
            startActivity(Intent(this, ChatActivity::class.java).putExtra("persona", p.id))
        })
        rows.add(SheetRow(R.drawable.ic_edit, "Edit") { edit(p) })
        rows.add(SheetRow(R.drawable.ic_copy, "Duplicate") { Personas.duplicate(p.id); render(); toast("Duplicated") })
        rows.add(SheetRow(R.drawable.ic_share, "Export") { exportSheet(p.name, listOf(p)) })
        if (Personas.all().size > 1) rows.add(SheetRow(R.drawable.ic_trash, "Delete") {
            confirm("Delete personality?", p.name, "Delete") { Personas.delete(p.id); render() }
        })
        showSheet(p.name, rows)
    }

    private fun exportSheet(title: String, list: List<Persona>) {
        val json = Personas.exportJson(list)
        showSheet("Export", listOf(
            SheetRow(R.drawable.ic_dl, "Save as file (.json)", "Keep a backup or move it to another phone") {
                pendingExport = json
                saveFile.launch(safeFileName(title, ".json"))
            },
            SheetRow(R.drawable.ic_share, "Share as text", "Send by WhatsApp, email or notes") {
                startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, json), "Share"))
            },
        ))
    }

    private fun importSheet() {
        showSheet("Import", listOf(
            SheetRow(R.drawable.ic_dl, "From a file", "Pick a .json file you exported") {
                openFile.launch(arrayOf("application/json", "text/plain", "*/*"))
            },
            SheetRow(R.drawable.ic_copy, "From the clipboard", "Paste text you copied") {
                val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                val t = cm.primaryClip?.takeIf { it.itemCount > 0 }?.getItemAt(0)?.coerceToText(this)?.toString().orEmpty()
                if (t.isBlank()) toast("The clipboard is empty") else doImport(t)
            },
        ))
    }

    private fun doImport(text: String) {
        try {
            val r = Personas.importJson(text)
            render()
            toast("Imported ${r.added}" + if (r.skipped > 0) ", skipped ${r.skipped} (duplicates or invalid)" else "")
        } catch (e: Exception) {
            toast(e.message ?: "Import failed")
        }
    }

    private fun edit(p: Persona?) {
        val d = DialogPersonaBinding.inflate(layoutInflater)
        d.name.setText(p?.name ?: "")
        d.desc.setText(p?.desc ?: "")
        d.prompt.setText(p?.prompt ?: "")
        var sel = (p?.ico ?: (Personas.all().size % Personas.icons.size)).coerceIn(0, Personas.icons.lastIndex)
        fun paintIcons() {
            d.icons.removeAllViews()
            Personas.icons.forEachIndexed { i, ic ->
                d.icons.addView(ImageView(this).apply {
                    setImageResource(ic.res)
                    setBackgroundResource(if (i == sel) R.drawable.bg_btn_primary else R.drawable.bg_chip)
                    imageTintList = ColorStateList.valueOf(getColor(if (i == sel) R.color.white else R.color.v_text))
                    setPadding(dp(11), dp(11), dp(11), dp(11))
                    setOnClickListener { sel = i; paintIcons() }
                }, LinearLayout.LayoutParams(dp(44), dp(44)).apply { marginEnd = dp(8) })
            }
        }
        paintIcons()
        val dlg = MaterialAlertDialogBuilder(this)
            .setTitle(if (p == null) "New personality" else "Edit personality")
            .setView(d.root)
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Save") { _, _ ->
                val name = d.name.text.toString().trim().take(40)
                val desc = d.desc.text.toString().trim().take(160)
                val prompt = d.prompt.text.toString().trim().take(4000).ifEmpty { "You are a helpful assistant." }
                if (name.isEmpty()) { toast("Give it a name"); return@setPositiveButton }
                if (p == null) Personas.add(name, desc, prompt, sel)
                else { p.name = name; p.desc = desc; p.prompt = prompt; p.ico = sel; Personas.save() }
                render()
            }
        dlg.show()
    }
}
