package com.vethos.app.ui

import android.os.Bundle
import android.widget.CheckBox
import android.widget.LinearLayout
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.vethos.app.R
import com.vethos.app.data.Tools
import com.vethos.app.data.Trigger
import com.vethos.app.data.Triggers

/** Automation rules: when a message matches, run a tool and give the result to the AI (or answer directly). */
class TriggersActivity : AppCompatActivity() {
    private lateinit var s: Screen

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        s = Screen(this, "Automation rules", listOf<Pair<Int, () -> Unit>>(R.drawable.ic_plus to { edit(null) }))
    }

    override fun onResume() { super.onResume(); render() }

    private fun render() {
        s.body.removeAllViews()
        s.hint("WHEN a message matches, THEN a tool runs and its result is given to the AI. Turn a rule off with its switch.", 4)
        val rules = Triggers.all().toList()
        val c = s.card(12)
        if (rules.isEmpty()) s.hint("No rules. Tap + to add one.", 6)
        rules.forEach { t ->
            val tool = Tools.byId(t.tool)?.label ?: t.tool
            val sub = (if (t.regex) "Pattern: " else "Words: ") + t.pattern.take(60) + "\n\u2192 " + tool + if (t.mode == 1) " (direct answer)" else " (helps the AI)"
            s.toggle(c, R.drawable.ic_bolt, t.name, sub, t.on) { v -> t.on = v; Triggers.save() }
            // second tap target: long-press the card row to edit
            val last = c.getChildAt(c.childCount - 1)
            last.setOnLongClickListener { edit(t); true }
        }
        s.hint("Tip: long-press a rule to edit or delete it.", 10)
        s.button("Reset to default rules", null, primary = false) {
            confirm("Reset rules?", "Your own rules will be removed.", "Reset") { Triggers.reset(); render() }
        }
    }

    private fun edit(t: Trigger?) {
        val tools = Tools.all.filter { it.id != "help" }
        var toolId = t?.tool ?: "fetch"
        var mode = t?.mode ?: 0
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(22), dp(8), dp(22), 0) }
        val name = s.input("Rule name").apply { setText(t?.name ?: "") }
        val pattern = s.input("Words (comma separated) or a regex").apply { setText(t?.pattern ?: "") }
        val rx = CheckBox(this).apply { text = "Pattern is a regex"; isChecked = t?.regex ?: false }
        val arg = s.input("Tool input, e.g. {input} or {match} or {1}").apply { setText(t?.arg ?: "{input}") }
        val toolBtn = s.button("", null, primary = false) {}
        s.body.removeView(toolBtn)
        val modeBtn = s.button("", null, primary = false) {}
        s.body.removeView(modeBtn)
        fun paint() {
            toolBtn.text = "Tool: " + (Tools.byId(toolId)?.label ?: "choose")
            modeBtn.text = if (mode == 1) "Answer directly (no AI)" else "Give result to the AI"
        }
        toolBtn.setOnClickListener {
            choose("Tool", tools.map { it.label }, tools.indexOfFirst { it.id == toolId }) { toolId = tools[it].id; paint() }
        }
        modeBtn.setOnClickListener {
            choose("What to do with the result", listOf("Give result to the AI", "Answer directly (no AI)"), mode) { mode = it; paint() }
        }
        paint()
        box.addView(name)
        box.addView(pattern, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })
        box.addView(rx)
        box.addView(arg, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(4) })
        box.addView(toolBtn, LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(10) })
        box.addView(modeBtn, LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(8) })
        val dlg = MaterialAlertDialogBuilder(this)
            .setTitle(if (t == null) "New rule" else "Edit rule")
            .setView(android.widget.ScrollView(this).apply { addView(box) })
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Save", null)
        if (t != null) dlg.setNeutralButton("Delete") { _, _ -> confirm("Delete rule?", t.name, "Delete") { Triggers.delete(t.id); render() } }
        val d = dlg.create()
        d.show()
        // validate without closing the dialog on error
        d.getButton(android.content.DialogInterface.BUTTON_POSITIVE).setOnClickListener {
            val err = Triggers.validate(name.text.toString().trim(), pattern.text.toString().trim(), rx.isChecked, toolId)
            if (err != null) { toast(err); return@setOnClickListener }
            if (t == null) {
                Triggers.add(Trigger(Triggers.newId(), name.text.toString().trim().take(40), pattern.text.toString().trim(), rx.isChecked,
                    toolId, arg.text.toString().trim(), mode, true))
            } else {
                t.name = name.text.toString().trim().take(40); t.pattern = pattern.text.toString().trim(); t.regex = rx.isChecked
                t.tool = toolId; t.arg = arg.text.toString().trim(); t.mode = mode
                Triggers.save()
            }
            d.dismiss()
            render()
        }
    }
}
