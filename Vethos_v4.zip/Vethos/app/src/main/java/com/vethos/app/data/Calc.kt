package com.vethos.app.data

import java.math.BigDecimal
import java.math.MathContext

/** A safe calculator: it only understands numbers, + - * / ^ % ! brackets and a few math functions. No code is ever executed. */
object Calc {
    class CalcError(msg: String) : Exception(msg)

    fun eval(input: String): String {
        var s = input.trim().lowercase()
        if (s.isEmpty()) throw CalcError("Nothing to calculate")
        if (s.length > 200) throw CalcError("Expression is too long")
        s = s.trimEnd('=', ' ', '?')
        s = s.replace("×", "*").replace("÷", "/").replace("−", "-").replace("**", "^")
        s = s.replace(Regex("(?<=[\\d)])\\s*x\\s*(?=[\\d(])"), "*")
        s = s.replace(Regex("(\\d+(?:\\.\\d+)?)\\s*%\\s*of\\s*"), "(\$1/100)*")
        val v = Parser(s).parse()
        if (v.isNaN() || v.isInfinite()) throw CalcError("Math error (result is too big or undefined)")
        return fmt(v)
    }

    fun fmt(d: Double): String {
        if (d == Math.rint(d) && Math.abs(d) < 1e15) return d.toLong().toString()
        val bd = BigDecimal(d).round(MathContext(12)).stripTrailingZeros()
        return if (Math.abs(d) >= 1e15 || Math.abs(d) < 1e-6) bd.toString() else bd.toPlainString()
    }

    private class Parser(val s: String) {
        var i = 0
        var depth = 0

        fun parse(): Double {
            val v = expr()
            ws()
            if (i < s.length) throw CalcError("Unexpected '${s[i]}'")
            return v
        }

        fun ws() { while (i < s.length && s[i].isWhitespace()) i++ }
        fun peek(): Char = if (i < s.length) s[i] else '\u0000'

        fun startsOperandAfter(k: Int): Boolean {
            var j = k
            while (j < s.length && s[j].isWhitespace()) j++
            if (j >= s.length) return false
            val ch = s[j]
            return ch.isDigit() || ch == '(' || ch == '.' || ch.isLetter()
        }

        fun expr(): Double {
            var v = term()
            while (true) {
                ws()
                val c = peek()
                if (c == '+') { i++; v += term() }
                else if (c == '-') { i++; v -= term() }
                else break
            }
            return v
        }

        fun term(): Double {
            var v = unary()
            while (true) {
                ws()
                val c = peek()
                if (c == '*') { i++; v *= unary() }
                else if (c == '/') {
                    i++
                    val d = unary()
                    if (d == 0.0) throw CalcError("Division by zero")
                    v /= d
                }
                else if (c == '%' && startsOperandAfter(i + 1)) {
                    i++
                    val d = unary()
                    if (d == 0.0) throw CalcError("Division by zero")
                    v %= d
                }
                else if (c == '(' || c.isLetter()) { v *= unary() } // 2(3+4), 2pi
                else break
            }
            return v
        }

        fun unary(): Double {
            ws()
            val c = peek()
            if (c == '-') { i++; return -unary() }
            if (c == '+') { i++; return unary() }
            return power()
        }

        fun power(): Double {
            var b = postfix()
            ws()
            if (peek() == '^') { i++; b = Math.pow(b, unary()) }
            return b
        }

        fun postfix(): Double {
            var v = primary()
            while (true) {
                ws()
                val c = peek()
                if (c == '!') { i++; v = fact(v) }
                else if (c == '%' && !startsOperandAfter(i + 1)) { i++; v /= 100.0 }
                else break
            }
            return v
        }

        fun primary(): Double {
            ws()
            val c = peek()
            if (c == '(') {
                depth++
                if (depth > 40) throw CalcError("Too many brackets")
                i++
                val v = expr()
                ws()
                if (peek() != ')') throw CalcError("Missing )")
                i++
                depth--
                return v
            }
            if (c.isDigit() || c == '.') return number()
            if (c.isLetter()) {
                val st = i
                while (i < s.length && (s[i].isLetter() || s[i].isDigit())) i++
                val name = s.substring(st, i)
                ws()
                if (peek() == '(') {
                    i++
                    depth++
                    if (depth > 40) throw CalcError("Too many brackets")
                    val args = ArrayList<Double>()
                    ws()
                    if (peek() == ')') {
                        i++
                    } else {
                        while (true) {
                            args.add(expr())
                            ws()
                            if (peek() == ',') { i++; continue }
                            if (peek() == ')') { i++; break }
                            throw CalcError("Missing )")
                        }
                    }
                    depth--
                    return call(name, args)
                }
                return when (name) {
                    "pi" -> Math.PI
                    "e" -> Math.E
                    "tau" -> 2 * Math.PI
                    else -> throw CalcError("Unknown word '$name'")
                }
            }
            throw CalcError(if (i >= s.length) "The expression is incomplete" else "Unexpected '$c'")
        }

        fun number(): Double {
            val st = i
            while (i < s.length && (s[i].isDigit() || s[i] == '.')) i++
            if (i < s.length && s[i] == 'e' && i + 1 < s.length) {
                val n1 = s[i + 1]
                val expOk = n1.isDigit() || ((n1 == '-' || n1 == '+') && i + 2 < s.length && s[i + 2].isDigit())
                if (expOk) {
                    i++
                    if (s[i] == '+' || s[i] == '-') i++
                    while (i < s.length && s[i].isDigit()) i++
                }
            }
            val t = s.substring(st, i)
            return t.toDoubleOrNull() ?: throw CalcError("Bad number '$t'")
        }

        fun fact(x: Double): Double {
            if (x < 0 || x != Math.floor(x) || x > 170) throw CalcError("Factorial needs a whole number from 0 to 170")
            var r = 1.0
            for (k in 2..x.toInt()) r *= k
            return r
        }

        fun call(n: String, a: List<Double>): Double {
            fun one(): Double {
                if (a.size != 1) throw CalcError("$n needs exactly 1 value")
                return a[0]
            }
            return when (n) {
                "sqrt" -> { val x = one(); if (x < 0) throw CalcError("Square root of a negative number"); Math.sqrt(x) }
                "cbrt" -> Math.cbrt(one())
                "abs" -> Math.abs(one())
                "sin" -> Math.sin(one())
                "cos" -> Math.cos(one())
                "tan" -> Math.tan(one())
                "asin" -> Math.asin(one())
                "acos" -> Math.acos(one())
                "atan" -> Math.atan(one())
                "sind" -> Math.sin(Math.toRadians(one()))
                "cosd" -> Math.cos(Math.toRadians(one()))
                "tand" -> Math.tan(Math.toRadians(one()))
                "ln" -> { val x = one(); if (x <= 0) throw CalcError("ln needs a positive number"); Math.log(x) }
                "log" -> { val x = one(); if (x <= 0) throw CalcError("log needs a positive number"); Math.log10(x) }
                "log2" -> { val x = one(); if (x <= 0) throw CalcError("log2 needs a positive number"); Math.log(x) / Math.log(2.0) }
                "exp" -> Math.exp(one())
                "floor" -> Math.floor(one())
                "ceil" -> Math.ceil(one())
                "round" -> Math.round(one()).toDouble()
                "fact" -> fact(one())
                "deg" -> Math.toDegrees(one())
                "rad" -> Math.toRadians(one())
                "pow" -> { if (a.size != 2) throw CalcError("pow needs 2 values"); Math.pow(a[0], a[1]) }
                "min" -> { if (a.isEmpty()) throw CalcError("min needs values"); a.minOrNull()!! }
                "max" -> { if (a.isEmpty()) throw CalcError("max needs values"); a.maxOrNull()!! }
                else -> throw CalcError("Unknown function '$n'")
            }
        }
    }
}
