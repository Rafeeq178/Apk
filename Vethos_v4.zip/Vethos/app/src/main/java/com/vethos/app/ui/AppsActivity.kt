package com.vethos.app.ui

import android.content.Intent
import android.os.Bundle
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.vethos.app.R
import com.vethos.app.data.AppsRepo
import com.vethos.app.data.Templates
import com.vethos.app.data.WebApp

/** Saved HTML apps: open, rename, duplicate, export, delete, import a .html file, or start from a template. */
class AppsActivity : AppCompatActivity() {
    private lateinit var s: Screen
    private var exporting: WebApp? = null

    private val importFile = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri == null) return@registerForActivityResult
        try {
            val text = readTextUri(uri)
            val name = displayName(uri).substringBeforeLast('.').ifEmpty { "Imported app" }
            val a = AppsRepo.create(name, text)
            toast("Imported")
            RunnerActivity.openApp(this, a.id)
        } catch (e: Exception) {
            toast(e.message ?: "Could not import this file")
        }
    }

    private val exportFile = registerForActivityResult(ActivityResultContracts.CreateDocument("text/html")) { uri ->
        val a = exporting
        if (uri != null && a != null) writeTextUri(uri, a.html)
        exporting = null
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        s = Screen(this, "Apps", listOf<Pair<Int, () -> Unit>>(
            R.drawable.ic_dl to { importFile.launch(arrayOf("text/html", "text/plain", "*/*")) },
            R.drawable.ic_plus to { newApp() },
        ))
    }

    override fun onResume() {
        super.onResume()
        render()
    }

    private fun newApp() {
        val names = Templates.items.map { it.first }
        choose("Start from", names, -1) { RunnerActivity.openCode(this, Templates.items[it].second) }
    }

    private fun render() {
        s.body.removeAllViews()
        s.hint("Small web apps that run fully offline. Ask the AI for one, then tap Run on its code block, or start from a template.", 4)
        s.button("New app", R.drawable.ic_plus) { newApp() }
        val list = AppsRepo.sorted()
        if (list.isEmpty()) {
            s.hint("No saved apps yet.", 20)
            return
        }
        s.section("YOUR APPS")
        val card = s.card(8)
        list.forEach { a ->
            s.row(card, R.drawable.ic_code, a.name, fmtKb(a.html.length) + " \u00B7 " + fmtDate(a.ts), onLong = { menu(a) }) {
                RunnerActivity.openApp(this, a.id)
            }
        }
    }

    private fun fmtKb(chars: Int) = if (chars < 1000) "$chars chars" else "${chars / 1000} KB"

    private fun menu(a: WebApp) {
        showSheet(a.name, listOf(
            SheetRow(R.drawable.ic_play, "Open") { RunnerActivity.openApp(this, a.id) },
            SheetRow(R.drawable.ic_edit, "Rename") {
                inputDialog("Rename app", a.name, "App name") { n ->
                    if (n.isNotBlank()) { a.name = n.trim().take(60); AppsRepo.save(a); render() }
                }
            },
            SheetRow(R.drawable.ic_copy, "Duplicate") { AppsRepo.create(a.name + " (copy)", a.html); render() },
            SheetRow(R.drawable.ic_dl, "Export as .html file") { exporting = a; exportFile.launch(safeFileName(a.name, ".html")) },
            SheetRow(R.drawable.ic_share, "Share code") {
                startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, a.html), "Share"))
            },
            SheetRow(R.drawable.ic_trash, "Delete") {
                confirm("Delete app?", a.name, "Delete") {
                    try { android.webkit.WebStorage.getInstance().deleteOrigin("https://${a.id}.vethos.local") } catch (_: Throwable) { }
                    AppsRepo.delete(a.id); render()
                }
            },
        ))
    }
}
