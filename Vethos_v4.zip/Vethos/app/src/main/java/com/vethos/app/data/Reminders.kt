package com.vethos.app.data

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.Calendar

data class Reminder(val id: Int, var text: String, var at: Long, var done: Boolean = false)

object RemindersRepo {
    private var cache: MutableList<Reminder>? = null
    private val file get() = File(Store.app.filesDir, "reminders.json")
    private val prefs get() = Store.app.getSharedPreferences("vethos", 0)

    @Synchronized
    fun all(): MutableList<Reminder> {
        cache?.let { return it }
        val out = mutableListOf<Reminder>()
        try {
            if (file.exists()) {
                val a = JSONArray(file.readText())
                for (i in 0 until a.length()) {
                    val o = a.getJSONObject(i)
                    out.add(Reminder(o.getInt("id"), o.optString("t"), o.optLong("at"), o.optBoolean("d")))
                }
            }
        } catch (_: Exception) { }
        cache = out
        return out
    }

    @Synchronized fun get(id: Int): Reminder? = all().firstOrNull { it.id == id }
    @Synchronized fun upcoming(): List<Reminder> = all().filter { !it.done }.sortedBy { it.at }
    @Synchronized fun finished(): List<Reminder> = all().filter { it.done }.sortedByDescending { it.at }

    @Synchronized
    fun add(text: String, at: Long): Reminder {
        val id = prefs.getInt("remId", 1000) + 1
        prefs.edit().putInt("remId", id).apply()
        val r = Reminder(id, text.trim().take(300).ifEmpty { "Reminder" }, at)
        all().add(r)
        persist()
        Scheduler.schedule(r)
        return r
    }

    @Synchronized
    fun delete(id: Int) {
        Scheduler.cancel(id)
        all().removeAll { it.id == id }
        persist()
    }

    @Synchronized fun markDone(id: Int) { get(id)?.let { it.done = true; persist() } }

    @Synchronized
    fun snooze(id: Int, minutes: Int) {
        val r = get(id) ?: return
        r.at = System.currentTimeMillis() + minutes * 60_000L
        r.done = false
        persist()
        Scheduler.schedule(r)
    }

    @Synchronized fun clearDone() { all().removeAll { it.done }; persist() }

    private fun persist() {
        val a = JSONArray()
        all().forEach { a.put(JSONObject().put("id", it.id).put("t", it.text).put("at", it.at).put("d", it.done)) }
        Disk.write(file, a.toString())
    }
}

/** Sets / cancels the Android alarms behind reminders and the daily brief. */
object Scheduler {
    const val ACTION_REMIND = "com.vethos.app.REMIND"
    const val ACTION_BRIEF = "com.vethos.app.BRIEF"
    private const val BRIEF_CODE = 1

    private fun am() = Store.app.getSystemService(Context.ALARM_SERVICE) as AlarmManager

    private fun pi(code: Int, action: String, id: Int): PendingIntent {
        val i = Intent(Store.app, AlarmReceiver::class.java).setAction(action).putExtra("id", id)
        return PendingIntent.getBroadcast(Store.app, code, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
    }

    /** Android 12+ lets the user switch exact alarms off; then reminders still work but can be a little late. */
    fun canExact(): Boolean = Build.VERSION.SDK_INT < 31 || am().canScheduleExactAlarms()

    private fun set(at: Long, p: PendingIntent, exact: Boolean) {
        val a = am()
        try {
            if (exact && canExact()) a.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, p)
            else a.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, p)
        } catch (_: SecurityException) {
            a.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, p)
        }
    }

    fun schedule(r: Reminder) {
        if (!r.done && r.at > System.currentTimeMillis()) set(r.at, pi(r.id, ACTION_REMIND, r.id), true)
    }

    fun cancel(id: Int) { am().cancel(pi(id, ACTION_REMIND, id)) }

    fun nextBrief(): Long {
        val c = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, Store.briefHour)
            set(Calendar.MINUTE, Store.briefMin)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        if (c.timeInMillis <= System.currentTimeMillis() + 5000) c.add(Calendar.DAY_OF_YEAR, 1)
        return c.timeInMillis
    }

    fun scheduleBrief() { set(nextBrief(), pi(BRIEF_CODE, ACTION_BRIEF, 0), false) }
    fun cancelBrief() { am().cancel(pi(BRIEF_CODE, ACTION_BRIEF, 0)) }

    /** After a reboot or an app update Android forgets alarms: set them again. Missed ones are shown right away. */
    fun rescheduleAll() {
        val now = System.currentTimeMillis()
        RemindersRepo.all().toList().forEach { r ->
            if (r.done) return@forEach
            if (r.at > now) schedule(r)
            else {
                Notify.reminder(Store.app, r, missed = true)
                RemindersRepo.markDone(r.id)
            }
        }
        if (Store.briefOn) scheduleBrief()
    }
}

/** Parses things like "10m drink water", "2h call", "18:30 gym", "tomorrow 9am study", "kal 7pm namaz". */
object TimeParse {
    class Parsed(val at: Long, val text: String)

    private const val UNIT = "days?|d|hours?|hrs?|h|minutes?|mins?|m|seconds?|secs?|s"
    private val durPrefix = Regex("^(?:in\\s+)?((?:\\d+\\s*(?:$UNIT)(?![a-z])\\s*(?:and\\s+)?)+)", RegexOption.IGNORE_CASE)
    private val durTok = Regex("(\\d+)\\s*($UNIT)(?![a-z])", RegexOption.IGNORE_CASE)
    private val dayWord = Regex("^(tomorrow|kal|today|aaj)(?![a-z])\\s*", RegexOption.IGNORE_CASE)
    private val clock = Regex(
        "^(?:at\\s+|@\\s*)?(?:(\\d{1,2}):(\\d{2})\\s*(am|pm)?|(\\d{1,2})\\s*(am|pm))(?![a-z0-9])\\s*",
        RegexOption.IGNORE_CASE
    )
    private val lead = Regex("^(to|that|about|ki|ko)\\s+", RegexOption.IGNORE_CASE)

    private fun clean(t: String): String = t.trim().replace(lead, "").trim().ifEmpty { "Reminder" }

    fun parse(input: String, now: Long = System.currentTimeMillis()): Parsed? {
        val t = input.trim()
        if (t.isEmpty()) return null

        val d = durPrefix.find(t)
        if (d != null) {
            var ms = 0L
            for (x in durTok.findAll(d.groupValues[1])) {
                val n = x.groupValues[1].toLongOrNull() ?: return null
                if (n > 100_000L) return null
                ms += n * when (x.groupValues[2].lowercase().first()) {
                    'd' -> 86_400_000L
                    'h' -> 3_600_000L
                    'm' -> 60_000L
                    else -> 1_000L
                }
            }
            if (ms <= 0L) return null
            return Parsed(now + ms, clean(t.substring(d.range.last + 1)))
        }

        var rest = t
        var dayOffset = -1
        val dw = dayWord.find(rest)
        if (dw != null) {
            val w = dw.groupValues[1].lowercase()
            dayOffset = if (w == "tomorrow" || w == "kal") 1 else 0
            rest = rest.substring(dw.range.last + 1)
        }

        var hour = -1
        var min = 0
        val ck = clock.find(rest)
        if (ck != null) {
            val g = ck.groupValues
            val h0: Int
            val mi: Int
            val ap: String
            if (g[1].isNotEmpty()) { h0 = g[1].toInt(); mi = g[2].toInt(); ap = g[3].lowercase() }
            else { h0 = g[4].toInt(); mi = 0; ap = g[5].lowercase() }
            var h = h0
            if (ap.isNotEmpty() && (h0 < 1 || h0 > 12)) return null
            if (ap == "pm" && h < 12) h += 12
            if (ap == "am" && h == 12) h = 0
            if (h > 23 || mi > 59) return null
            hour = h
            min = mi
            rest = rest.substring(ck.range.last + 1)
        }
        if (dayOffset < 0 && hour < 0) return null

        val cal = Calendar.getInstance().apply {
            timeInMillis = now
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
            set(Calendar.HOUR_OF_DAY, if (hour >= 0) hour else 9)
            set(Calendar.MINUTE, if (hour >= 0) min else 0)
        }
        if (dayOffset == 1) cal.add(Calendar.DAY_OF_YEAR, 1)
        else if (dayOffset < 0 && cal.timeInMillis <= now) cal.add(Calendar.DAY_OF_YEAR, 1)
        return Parsed(cal.timeInMillis, clean(rest))
    }
}
