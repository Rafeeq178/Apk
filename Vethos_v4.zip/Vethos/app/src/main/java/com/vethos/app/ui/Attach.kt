package com.vethos.app.ui

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import com.vethos.app.data.Summarizer
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.InputStream
import java.util.zip.ZipInputStream

/** Reads a picked file (text, code, .docx, .pptx, .pdf) so its content can be sent to the model with the question. */
object Attach {
    /** Offline models have a small context, so at most this much of a file goes to the model. */
    const val MAX_CHARS = 6000
    private const val MAX_BYTES = 2_000_000
    private const val MAX_PDF_BYTES = 25_000_000
    private const val MAX_KEPT = 400_000
    private const val MAX_PDF_PAGES = 80

    /** text = the whole file (up to 400k characters). truncated = longer than what the model can take at once. */
    class Picked(val name: String, val text: String, val truncated: Boolean)

    private val unsupported = setOf(
        "png", "jpg", "jpeg", "gif", "webp", "bmp", "heic", "mp3", "wav", "m4a", "mp4", "mkv", "avi",
        "zip", "rar", "7z", "apk", "gguf", "exe", "bin", "doc", "xls", "xlsx", "ppt"
    )

    fun read(ctx: Context, uri: Uri): Picked {
        val r = ctx.contentResolver
        var name = "file"
        r.query(uri, null, null, null, null)?.use { c ->
            if (c.moveToFirst()) {
                val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (i >= 0) c.getString(i)?.let { name = it }
            }
        }
        val ext = name.substringAfterLast('.', "").lowercase()
        if (ext in unsupported) {
            throw IllegalArgumentException("Offline model can't read .$ext files. Use text, code, .docx, .pptx or .pdf files.")
        }
        val ins = r.openInputStream(uri) ?: throw IllegalArgumentException("Could not open this file")
        val full: String = ins.use {
            when (ext) {
                "docx" -> readDocx(it)
                "pptx" -> readPptx(it)
                "pdf" -> readPdf(ctx, it)
                else -> readText(it)
            }
        }
        val text = full.replace("\u0000", "").trim()
        if (text.isEmpty()) {
            throw IllegalArgumentException(if (ext == "pdf") "This PDF has no selectable text (it may be a scan)" else "This file is empty")
        }
        return Picked(name, text.take(MAX_KEPT), text.length > MAX_CHARS)
    }

    private fun readCapped(ins: InputStream, cap: Int): ByteArray {
        val out = ByteArrayOutputStream()
        val buf = ByteArray(16 * 1024)
        var total = 0
        while (total < cap) {
            val n = ins.read(buf, 0, minOf(buf.size, cap - total))
            if (n < 0) break
            out.write(buf, 0, n)
            total += n
        }
        return out.toByteArray()
    }

    private fun readText(ins: InputStream): String {
        val bytes = readCapped(ins, MAX_BYTES)
        val head = minOf(bytes.size, 4096)
        for (k in 0 until head) {
            if (bytes[k].toInt() == 0) throw IllegalArgumentException("This looks like a binary file, not text")
        }
        return String(bytes, Charsets.UTF_8)
    }

    private fun unxml(s: String): String =
        s.replace("&lt;", "<").replace("&gt;", ">").replace("&quot;", "\"").replace("&apos;", "'").replace("&amp;", "&")

    private fun readDocx(ins: InputStream): String {
        ZipInputStream(ins).use { z ->
            var e = z.nextEntry
            while (e != null) {
                if (e.name == "word/document.xml") {
                    val xml = String(readCapped(z, 8_000_000), Charsets.UTF_8)
                    return unxml(
                        xml.replace("</w:p>", "\n").replace("<w:tab/>", "\t").replace("<w:br/>", "\n")
                            .replace(Regex("<[^>]+>"), "")
                    )
                }
                e = z.nextEntry
            }
        }
        throw IllegalArgumentException("Could not read this .docx file")
    }

    private fun readPptx(ins: InputStream): String {
        val slides = sortedMapOf<Int, String>()
        ZipInputStream(ins).use { z ->
            var e = z.nextEntry
            while (e != null) {
                val m = Regex("^ppt/slides/slide(\\d+)\\.xml$").find(e.name)
                if (m != null) {
                    val xml = String(readCapped(z, 2_000_000), Charsets.UTF_8)
                    val text = Regex("<a:t[^>]*>([^<]*)</a:t>|</a:p>").findAll(xml).joinToString("") {
                        if (it.value == "</a:p>") "\n" else unxml(it.groupValues[1]) + " "
                    }
                    slides[m.groupValues[1].toInt()] = text.trim()
                }
                e = z.nextEntry
            }
        }
        if (slides.isEmpty()) throw IllegalArgumentException("Could not read this .pptx file")
        return slides.entries.joinToString("\n\n") { "Slide ${it.key}:\n${it.value}" }
    }

    private fun readPdf(ctx: Context, ins: InputStream): String {
        val bytes = readCapped(ins, MAX_PDF_BYTES)
        if (bytes.size >= MAX_PDF_BYTES) throw IllegalArgumentException("This PDF is too large (max 25 MB)")
        try {
            com.tom_roush.pdfbox.android.PDFBoxResourceLoader.init(ctx.applicationContext)
            val doc = com.tom_roush.pdfbox.pdmodel.PDDocument.load(ByteArrayInputStream(bytes))
            try {
                if (doc.isEncrypted) throw IllegalArgumentException("This PDF is password protected")
                val st = com.tom_roush.pdfbox.text.PDFTextStripper()
                st.startPage = 1
                st.endPage = minOf(doc.numberOfPages, MAX_PDF_PAGES)
                st.sortByPosition = true
                return st.getText(doc)
            } finally {
                doc.close()
            }
        } catch (e: IllegalArgumentException) {
            throw e
        } catch (e: Exception) {
            throw IllegalArgumentException("Could not read this PDF: " + (e.message ?: "unknown error"))
        }
    }

    private fun isSummaryAsk(q: String): Boolean {
        val t = q.trim().lowercase()
        if (t.isEmpty()) return true
        return listOf("summar", "tl;dr", "overview", "main point", "key point", "khulasa", "mukhtasar", "short", "brief").any { t.contains(it) }
    }

    /** The text that goes to the model (and is saved in the chat). Long files are cut down smartly, not just from the top. */
    fun wrap(p: Picked, question: String): String {
        val ask = question.ifBlank { "Summarize this file and point out any problems." }
        val body = when {
            p.text.length <= MAX_CHARS -> p.text
            isSummaryAsk(question) -> Summarizer.condense(p.text, MAX_CHARS)
            else -> Summarizer.relevant(p.text, question, MAX_CHARS)
        }
        return "Attached file: ${p.name.replace('\n', ' ')}\n<<<FILE\n${body.replace("FILE>>>", "FILE>>")}\nFILE>>>\n\n$ask"
    }

    /** Same shape for tool results (web pages, search) so the chat bubble only shows a small label. */
    fun wrapTool(label: String, text: String, question: String): String =
        "Tool result: ${label.replace('\n', ' ')}\n<<<FILE\n${text.replace("FILE>>>", "FILE>>")}\nFILE>>>\n\n$question"

    private val shown = Regex("^(Attached file|Tool result): (.+)\\n<<<FILE\\n[\\s\\S]*?\\nFILE>>>\\n\\n")

    /** What the user sees in the chat bubble: file/tool name + their question, not the whole content. */
    fun display(t: String): String {
        val m = shown.find(t) ?: return t
        val icon = if (m.groupValues[1] == "Tool result") "\uD83D\uDD27 " else "\uD83D\uDCCE "
        return icon + m.groupValues[2] + "\n\n" + t.substring(m.range.last + 1)
    }
}
