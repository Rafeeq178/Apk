package com.vethos.app.data

import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID

data class Note(val id: String, var title: String, var body: String, var ts: Long, var pinned: Boolean = false)

object NotesRepo {
    private const val MAX_BODY = 20_000
    private var cache: MutableList<Note>? = null
    private val file get() = File(Store.app.filesDir, "notes.json")

    @Synchronized
    fun all(): MutableList<Note> {
        cache?.let { return it }
        val out = mutableListOf<Note>()
        try {
            if (file.exists()) {
                val a = JSONArray(file.readText())
                for (i in 0 until a.length()) {
                    val o = a.getJSONObject(i)
                    out.add(Note(o.getString("id"), o.optString("title"), o.optString("body"), o.optLong("ts"), o.optBoolean("pin")))
                }
            }
        } catch (_: Exception) { }
        cache = out
        return out
    }

    @Synchronized
    fun sorted(): List<Note> =
        all().sortedWith(compareByDescending<Note> { it.pinned }.thenByDescending { it.ts })

    @Synchronized
    fun search(q: String): List<Note> {
        val t = q.trim().lowercase()
        if (t.isEmpty()) return sorted()
        return sorted().filter { it.title.lowercase().contains(t) || it.body.lowercase().contains(t) }
    }

    fun titleOf(title: String, body: String): String =
        title.trim().ifEmpty { body.lineSequence().firstOrNull { it.isNotBlank() }?.trim()?.take(40) ?: "Note" }

    @Synchronized
    fun add(title: String, body: String): Note {
        val n = Note(UUID.randomUUID().toString(), titleOf(title, body), body.trim().take(MAX_BODY), System.currentTimeMillis())
        all().add(n)
        persist()
        return n
    }

    @Synchronized
    fun update(n: Note, title: String, body: String) {
        n.body = body.trim().take(MAX_BODY)
        n.title = titleOf(title, n.body)
        n.ts = System.currentTimeMillis()
        persist()
    }

    @Synchronized fun setPinned(n: Note, v: Boolean) { n.pinned = v; persist() }
    @Synchronized fun delete(id: String) { all().removeAll { it.id == id }; persist() }

    private fun persist() {
        val a = JSONArray()
        all().forEach { a.put(JSONObject().put("id", it.id).put("title", it.title).put("body", it.body).put("ts", it.ts).put("pin", it.pinned)) }
        Disk.write(file, a.toString())
    }
}
