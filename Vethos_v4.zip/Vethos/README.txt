VETHOS - native Android app (Kotlin, no WebView, no ads)

Termux build:
  1. pkg install git openjdk-17 gradle   (plus Android SDK + NDK + cmake)
  2. ./setup.sh          # clones llama.cpp and prepares its Android lib
  3. gradle assembleRelease
  APK: app/build/outputs/apk/release/

Needs Android 10+ (API 29), arm64 phone.

v2 changes
  - Settings crash fixed: the settings layout had a view with id "root", which clashes with ViewBinding's
    .root and caused "The specified child already has a parent". It is now called "content".
  - New UI matching the reference recordings (gradient background, pill nav, side drawer, personalities,
    new Library / Insights / Settings screens).
  - Chat: live typing animation with a blinking dot, thumbs / copy / share / regenerate actions,
    options sheet, personality sheet, voice input, export chat.
  - Settings that are saved but not yet applied by the engine: Creativity, Repetition penalty, CPU threads,
    Multi-thread, GPU, Context size (llama.android's sendUserPrompt only takes the prompt and max tokens).

v3 changes
  - Code blocks: ```lang ... ``` in an answer is now drawn as a dark code block with its own "Copy" button
    (also while the answer is still typing).
  - File attach (clip button): pick any text / code file (.txt .php .js .html .json .csv .kt .py ...) or .docx.
    The first 6000 characters go to the model together with your question. PDF / images can't be read by the
    offline text model. No storage permission needed (system file picker).
  - Permissions: notifications (Android 13+, asked once with a reason) + foreground service so model
    downloads keep running in the background and show progress in the notification bar.
    Microphone: voice input uses the system speech screen, so the app itself needs no mic permission.

v4 changes (this version)
  1. Personalities: edit (name, description, prompt, icon), new, duplicate, delete, export (.json file or shared text)
     and import (from a file or from the clipboard). Menu: drawer > My Offline Chatbots.
  2. Offline HTML/CSS/JS runner: Apps screen (drawer > Apps) with saved apps, templates, import/export .html.
     Every html code block in a chat answer now has a "Run" button. Live preview while typing, console with errors,
     the page runs with NO network and NO access to the app (safe for AI-written code).
  3. Tools layer, triggers and automation: slash commands in chat (/calc /note /notes /remind /search /fetch /time /brief /help),
     automation rules (Tools > Automation rules: WHEN message matches THEN run a tool), and an experimental switch that
     lets the AI call tools itself (notes and reminders always ask you first).
  4. URL fetch and web search: paste a link and the AI reads it; type "search: topic" or /search topic.
     Search uses DuckDuckGo with a Wikipedia fallback. Only https, private network addresses are blocked.
  5. Extra tools: Notes, Reminders (alarms survive reboot), safe Calculator, file summary for PDF / Word / PowerPoint / text
     (long files are condensed or matched to your question instead of just cutting the start), Voice (read answers aloud,
     auto-send voice input), Daily brief notification.
  New dependency: com.tom-roush:pdfbox-android (PDF text). New permissions: exact alarms + boot completed (reminders).
  Open Tools from the drawer or Settings > Tools, voice and automation.
