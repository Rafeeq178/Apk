package com.vethos.app.ui

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import androidx.fragment.app.Fragment
import com.vethos.app.R
import com.vethos.app.data.ChatRepo
import com.vethos.app.data.Store
import com.vethos.app.databinding.FragmentHomeBinding
import com.vethos.app.databinding.ItemFcardBinding
import com.vethos.app.databinding.ItemHistoryBinding
import java.io.File

class HomeFragment : Fragment() {
    private var _b: FragmentHomeBinding? = null
    private val b get() = _b!!

    override fun onCreateView(i: LayoutInflater, c: ViewGroup?, s: Bundle?): View =
        FragmentHomeBinding.inflate(i, c, false).also { _b = it }.root

    override fun onViewCreated(v: View, s: Bundle?) {
        val openHistory = View.OnClickListener { startActivity(Intent(requireContext(), HistoryActivity::class.java)) }
        b.btnHistory.setOnClickListener(openHistory)
        b.seeAll.setOnClickListener(openHistory)
        b.modelCard.setOnClickListener { (activity as MainActivity).select(1) }

        card(b.grid1, "Chat", R.drawable.ic_chat, "", false)
        card(b.grid1, "Write", R.drawable.ic_edit, "Help me write ", true)
        card(b.grid2, "Code", R.drawable.ic_code, "Write code to ", false)
        card(b.grid2, "Learn", R.drawable.ic_book, "Explain in simple words: ", true)
    }

    private fun card(parent: LinearLayout, title: String, icon: Int, preset: String, second: Boolean) {
        val c = ItemFcardBinding.inflate(layoutInflater, parent, false)
        c.icon.setImageResource(icon)
        c.title.text = title
        (c.root.layoutParams as LinearLayout.LayoutParams).apply {
            if (second) marginStart = requireContext().dp(6) else marginEnd = requireContext().dp(6)
        }
        c.root.setOnClickListener {
            startActivity(Intent(requireContext(), ChatActivity::class.java).putExtra("preset", preset))
        }
        parent.addView(c.root)
    }

    override fun onResume() {
        super.onResume()
        val name = Store.lastModel
        val f = name?.let { File(Store.modelsDir, it) }
        if (f != null && f.exists()) {
            b.modelName.text = f.name
            b.modelSub.text = fmtSize(f.length()) + " - tap to change"
        } else {
            b.modelName.text = "No model selected"
            b.modelSub.text = "Tap to download or add one"
        }
        b.recent.removeAllViews()
        val chats = ChatRepo.sorted().filter { it.msgs.isNotEmpty() }.take(3)
        if (chats.isEmpty()) {
            b.recent.addView(android.widget.TextView(requireContext()).apply {
                text = "Your chats will show up here"
                setTextColor(requireContext().getColor(R.color.v_muted))
                textSize = 14f
                setPadding(0, requireContext().dp(8), 0, 0)
            })
        }
        chats.forEach { chat ->
            val r = ItemHistoryBinding.inflate(layoutInflater, b.recent, false)
            r.title.text = chat.title
            r.sub.text = "${chat.msgs.size} messages - ${fmtDate(chat.ts)}"
            r.delete.visibility = View.GONE
            r.root.setOnClickListener {
                startActivity(Intent(requireContext(), ChatActivity::class.java).putExtra("id", chat.id))
            }
            b.recent.addView(r.root)
        }
    }

    override fun onDestroyView() { super.onDestroyView(); _b = null }
}
