package com.vethos.app

import android.app.Application
import androidx.appcompat.app.AppCompatDelegate
import com.vethos.app.data.Store

class VethosApp : Application() {
    override fun onCreate() {
        super.onCreate()
        Store.init(this)
        applyTheme()
    }

    companion object {
        fun applyTheme() {
            AppCompatDelegate.setDefaultNightMode(
                when (Store.theme) {
                    1 -> AppCompatDelegate.MODE_NIGHT_NO
                    2 -> AppCompatDelegate.MODE_NIGHT_YES
                    else -> AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM
                }
            )
        }
    }
}
