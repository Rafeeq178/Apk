package com.vethos.app.ui

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import androidx.fragment.app.Fragment
import com.vethos.app.R
import com.vethos.app.VethosApp
import com.vethos.app.data.ChatRepo
import com.vethos.app.data.Store
import com.vethos.app.databinding.FragmentSettingsBinding
import com.vethos.app.databinding.ItemSettingBinding

class SettingsFragment : Fragment() {
    private var _b: FragmentSettingsBinding? = null
    private val b get() = _b!!

    override fun onCreateView(i: LayoutInflater, c: ViewGroup?, s: Bundle?): View =
        FragmentSettingsBinding.inflate(i, c, false).also { _b = it }.root

    override fun onViewCreated(v: View, s: Bundle?) = build()

    private fun section(title: String): LinearLayout {
        val ctx = requireContext()
        b.root.addView(TextView(ctx).apply {
            text = title
            setTextColor(ctx.getColor(R.color.v_muted))
            textSize = 13f
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            setPadding(ctx.dp(6), ctx.dp(22), 0, ctx.dp(8))
        })
        val card = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundResource(R.drawable.bg_card)
        }
        b.root.addView(card)
        return card
    }

    private fun item(card: LinearLayout, title: String, value: String, onClick: (() -> Unit)?) {
        val ctx = requireContext()
        if (card.childCount > 0) card.addView(View(ctx).apply {
            setBackgroundColor(ctx.getColor(R.color.v_line))
        }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 1).apply {
            marginStart = ctx.dp(16); marginEnd = ctx.dp(16)
        })
        val r = ItemSettingBinding.inflate(layoutInflater, card, false)
        r.title.text = title
        r.value.text = value
        if (onClick == null) r.root.isClickable = false else r.root.setOnClickListener { onClick() }
        card.addView(r.root)
    }

    private fun build() {
        val ctx = requireContext()
        while (b.root.childCount > 1) b.root.removeViewAt(1)

        val model = section("MODEL")
        item(model, "Active model", Store.lastModel ?: "None") { (activity as MainActivity).select(1) }
        item(model, "Hugging Face token", if (Store.hfToken.isBlank()) "Not set" else "Set") {
            ctx.inputDialog("Hugging Face token", Store.hfToken, "hf_... (only for gated models)") { Store.hfToken = it; build() }
        }

        val chat = section("CHAT")
        val lens = listOf(128, 256, 512, 1024, 2048)
        item(chat, "Response length", Store.maxTokens.toString() + " tokens") {
            ctx.choose("Response length", lens.map { "$it tokens" }, lens.indexOf(Store.maxTokens)) { Store.maxTokens = lens[it]; build() }
        }
        item(chat, "System prompt", Store.systemPrompt.take(24) + "...") {
            ctx.inputDialog("System prompt", Store.systemPrompt, "How the assistant should behave", true) {
                if (it.isNotBlank()) Store.systemPrompt = it.trim(); build()
            }
        }
        item(chat, "Best / Bad examples", (Store.steer("best").size + Store.steer("bad").size).toString() + " saved") {
            ctx.confirm("Clear saved examples?", "Vethos will forget which answers you liked or disliked.", "Clear") { Store.clearSteer(); build() }
        }

        val look = section("APPEARANCE")
        val themes = listOf("System", "Light", "Dark")
        item(look, "Theme", themes[Store.theme]) {
            ctx.choose("Theme", themes, Store.theme) { Store.theme = it; VethosApp.applyTheme() }
        }

        val data = section("DATA")
        item(data, "Clear chat history", ChatRepo.all().size.toString() + " chats") {
            ctx.confirm("Clear all chats?", "This can't be undone.", "Clear") { ChatRepo.clear(); build() }
        }

        val about = section("ABOUT")
        item(about, "Version", "1.0.0", null)
        item(about, "Privacy", "Offline, no ads, no tracking", null)
    }

    override fun onDestroyView() { super.onDestroyView(); _b = null }
}
