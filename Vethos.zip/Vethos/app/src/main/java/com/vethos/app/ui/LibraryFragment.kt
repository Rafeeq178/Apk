package com.vethos.app.ui

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.fragment.app.Fragment
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.vethos.app.R
import com.vethos.app.data.Catalog
import com.vethos.app.data.Dl
import com.vethos.app.data.Downloads
import com.vethos.app.data.Engine
import com.vethos.app.data.Store
import com.vethos.app.databinding.FragmentLibraryBinding
import com.vethos.app.databinding.ItemModelBinding
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.io.File

class LibraryFragment : Fragment() {
    private var _b: FragmentLibraryBinding? = null
    private val b get() = _b!!

    private val picker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) Downloads.importFrom(requireContext(), uri)
    }

    override fun onCreateView(i: LayoutInflater, c: ViewGroup?, s: Bundle?): View =
        FragmentLibraryBinding.inflate(i, c, false).also { _b = it }.root

    override fun onViewCreated(v: View, s: Bundle?) {
        b.btnImport.setOnClickListener { picker.launch(arrayOf("*/*")) }
        b.btnUrl.setOnClickListener {
            requireContext().inputDialog("Hugging Face link", "", "https://huggingface.co/.../model.gguf") { url ->
                val n = Downloads.fileNameFor(url)
                if (n == null) requireContext().toast("Paste a direct link to a .gguf file")
                else Downloads.start(url, n)
            }
        }
        viewLifecycleOwner.lifecycleScope.launch {
            viewLifecycleOwner.repeatOnLifecycle(Lifecycle.State.STARTED) {
                Downloads.state.collect { render(it); delay(350) }
            }
        }
    }

    private fun header(text: String) {
        b.list.addView(TextView(requireContext()).apply {
            this.text = text
            setTextColor(requireContext().getColor(R.color.v_text))
            textSize = 18f
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            setPadding(0, requireContext().dp(24), 0, 0)
        })
    }

    private fun hint(text: String) {
        b.list.addView(TextView(requireContext()).apply {
            this.text = text
            setTextColor(requireContext().getColor(R.color.v_muted))
            textSize = 14f
            setPadding(0, requireContext().dp(8), 0, 0)
        })
    }

    /** progress: null = hidden, -1 = indeterminate, 0..1000 = value */
    private fun row(
        title: String, sub: String, action: String?, active: Boolean = false, progress: Int? = null,
        onAction: (() -> Unit)? = null, onDelete: (() -> Unit)? = null,
    ) {
        val r = ItemModelBinding.inflate(layoutInflater, b.list, false)
        r.title.text = title
        r.sub.text = sub
        if (action == null) r.action.visibility = View.GONE else {
            r.action.text = action
            if (active) {
                r.action.setBackgroundResource(R.drawable.bg_btn_light)
                r.action.setTextColor(requireContext().getColor(R.color.v_blue))
            }
            r.action.setOnClickListener { onAction?.invoke() }
        }
        if (onDelete == null) r.delete.visibility = View.GONE else r.delete.setOnClickListener { onDelete() }
        if (progress != null) {
            r.bar.visibility = View.VISIBLE
            r.bar.max = 1000
            if (progress < 0) r.bar.isIndeterminate = true else r.bar.progress = progress
        }
        b.list.addView(r.root)
    }

    private fun render(dl: Map<String, Dl>) {
        if (_b == null) return
        b.list.removeAllViews()
        val models = Store.models()
        val names = models.map { it.name }.toSet()
        if (Store.lastModel == null && models.isNotEmpty()) Store.lastModel = models.first().name

        header("Your models")
        if (models.isEmpty()) hint("No models yet. Download one below or add a .gguf from your phone.")
        models.forEach { f ->
            val isActive = Store.lastModel == f.name
            row(f.name, fmtSize(f.length()), if (isActive) "Active" else "Use", active = isActive,
                onAction = { Store.lastModel = f.name; requireContext().toast("Model selected"); render(Downloads.state.value) },
                onDelete = {
                    requireContext().confirm("Delete model?", f.name, "Delete") {
                        if (Store.lastModel == f.name) { Store.lastModel = null; Engine.unload() }
                        f.delete(); Downloads.clearFinished(f.name); render(Downloads.state.value)
                    }
                })
        }

        val busy = dl.values.filter { it.state != 2 }
        if (busy.isNotEmpty()) {
            header("Downloading")
            busy.forEach { d ->
                val pct = if (d.total > 0) (d.done * 1000 / d.total).toInt() else -1
                val sub = when {
                    d.state == 1 -> d.err + if (d.done > 0) " - " + fmtSize(d.done) + " saved" else ""
                    d.total > 0 -> fmtSize(d.done) + " / " + fmtSize(d.total) + " (" + (pct / 10) + "%)"
                    else -> fmtSize(d.done) + " downloaded"
                }
                val canResume = Downloads.urls.containsKey(d.name)
                row(d.name, sub,
                    if (d.state == 0) "Pause" else if (canResume) "Resume" else "Dismiss",
                    progress = if (d.state == 0) pct else null,
                    onAction = {
                        if (d.state == 0) Downloads.pause(d.name)
                        else if (canResume) Downloads.start(Downloads.urls[d.name]!!, d.name)
                        else Downloads.clearFinished(d.name)
                    },
                    onDelete = { Downloads.cancel(d.name, true) })
            }
        }

        val rec = Catalog.items.filter { it.file !in names && dl[it.file] == null }
        if (rec.isNotEmpty()) {
            header("Recommended")
            rec.forEach { m ->
                row(m.name, m.desc + " - " + m.size, "Download", onAction = { Downloads.start(m.url, m.file) })
            }
        }
    }

    override fun onResume() { super.onResume(); if (_b != null) render(Downloads.state.value) }
    override fun onDestroyView() { super.onDestroyView(); _b = null }
}
