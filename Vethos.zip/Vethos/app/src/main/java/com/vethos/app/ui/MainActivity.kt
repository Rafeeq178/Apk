package com.vethos.app.ui

import android.content.Intent
import android.content.res.ColorStateList
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import com.vethos.app.R
import com.vethos.app.databinding.ActivityMainBinding
import com.vethos.app.databinding.ItemNavBinding

class MainActivity : AppCompatActivity() {
    private lateinit var b: ActivityMainBinding
    private val navItems = mutableListOf<ItemNavBinding>()
    private var current = -1

    private class Tab(val label: String, val icon: Int, val make: () -> Fragment)
    private val tabs = listOf(
        Tab("Home", R.drawable.ic_home) { HomeFragment() },
        Tab("Library", R.drawable.ic_lib) { LibraryFragment() },
        Tab("Insights", R.drawable.ic_ins) { InsightsFragment() },
        Tab("Settings", R.drawable.ic_set) { SettingsFragment() },
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityMainBinding.inflate(layoutInflater)
        setContentView(b.root)
        tabs.forEachIndexed { i, t ->
            val n = ItemNavBinding.inflate(layoutInflater, b.nav, false)
            n.icon.setImageResource(t.icon)
            n.label.text = t.label
            n.root.setOnClickListener { select(i) }
            b.nav.addView(n.root)
            navItems.add(n)
        }
        select(intent.getIntExtra("tab", savedInstanceState?.getInt("tab") ?: 0))
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        select(intent.getIntExtra("tab", 0))
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putInt("tab", current)
    }

    fun select(i: Int) {
        if (i == current && supportFragmentManager.findFragmentById(R.id.container) != null) return
        current = i
        supportFragmentManager.beginTransaction().replace(R.id.container, tabs[i].make()).commit()
        navItems.forEachIndexed { idx, n ->
            val on = idx == i
            n.root.setBackgroundResource(if (on) R.drawable.bg_nav_sel else 0)
            val c = getColor(if (on) R.color.v_blue else R.color.v_nav_off)
            n.icon.imageTintList = ColorStateList.valueOf(c)
            n.label.setTextColor(c)
        }
    }
}
