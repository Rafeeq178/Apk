package com.vethos.app.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.SystemClock
import android.view.View
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.vethos.app.R
import com.vethos.app.data.Chat
import com.vethos.app.data.ChatRepo
import com.vethos.app.data.Engine
import com.vethos.app.data.Msg
import com.vethos.app.data.Store
import com.vethos.app.databinding.ActivityChatBinding
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.UUID

class ChatActivity : AppCompatActivity() {
    private lateinit var b: ActivityChatBinding
    private lateinit var chat: Chat
    private lateinit var adapter: ChatAdapter
    private var gen: Job? = null
    private var ready = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityChatBinding.inflate(layoutInflater)
        setContentView(b.root)

        chat = ChatRepo.get(intent.getStringExtra("id"))
            ?: Chat(UUID.randomUUID().toString(), "New chat", System.currentTimeMillis(), mutableListOf())
        adapter = ChatAdapter(chat.msgs, ::copy, ::feedback)
        b.rv.layoutManager = LinearLayoutManager(this)
        b.rv.adapter = adapter
        b.title.text = chat.title

        b.btnBack.setOnClickListener { finish() }
        b.btnNew.setOnClickListener {
            gen?.cancel()
            startActivity(Intent(this, ChatActivity::class.java))
            finish()
        }
        b.send.setOnClickListener { if (gen?.isActive == true) gen?.cancel() else send(null) }

        intent.getStringExtra("preset")?.takeIf { it.isNotEmpty() }?.let {
            b.input.setText(it); b.input.setSelection(it.length)
        }
        listOf("Explain how neural networks learn", "Write a short email asking for a day off", "Give me 5 healthy dinner ideas")
            .forEach { q ->
                b.sugs.addView(TextView(this).apply {
                    text = q
                    setBackgroundResource(R.drawable.bg_chip)
                    setTextColor(getColor(R.color.v_text2))
                    textSize = 14f
                    setPadding(dp(16), dp(12), dp(16), dp(12))
                    setOnClickListener { send(q) }
                }, android.widget.LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })
            }

        refreshHero()
        scrollBottom()
        loadModel()
    }

    private fun refreshHero() {
        val empty = chat.msgs.isEmpty() && !adapter.thinking
        b.hero.visibility = if (empty) View.VISIBLE else View.GONE
        b.rv.visibility = if (empty) View.INVISIBLE else View.VISIBLE
    }

    private fun scrollBottom() = b.rv.post {
        if (adapter.itemCount > 0) b.rv.scrollToPosition(adapter.itemCount - 1)
    }

    private fun showBanner(text: String, onClick: (() -> Unit)?) {
        b.banner.text = text
        b.banner.visibility = View.VISIBLE
        b.banner.setOnClickListener { onClick?.invoke() }
    }

    private fun loadModel() {
        val f = Store.lastModel?.let { File(Store.modelsDir, it) }
        if (f == null || !f.exists()) {
            b.sub.text = "No model"
            showBanner("No model yet. Tap here to open the Library.") {
                startActivity(
                    Intent(this, MainActivity::class.java).putExtra("tab", 1)
                        .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                )
                finish()
            }
            return
        }
        b.sub.text = f.name
        b.loading.visibility = View.VISIBLE
        val system = buildSystem()
        lifecycleScope.launch {
            try {
                withContext(Dispatchers.Default) { Engine.load(this@ChatActivity, f.absolutePath, chat.id, system) }
                ready = true
            } catch (e: CancellationException) {
                throw e
            } catch (e: Throwable) {
                showBanner("Could not load this model: " + (e.message ?: "unknown error"), null)
            } finally {
                b.loading.visibility = View.GONE
            }
        }
    }

    private fun buildSystem(): String {
        val sb = StringBuilder(Store.systemPrompt)
        val best = Store.steer("best")
        if (best.isNotEmpty()) sb.append("\n\nExamples of answers the user liked:\n").append(best.joinToString("\n---\n"))
        val bad = Store.steer("bad")
        if (bad.isNotEmpty()) sb.append("\n\nAvoid answers like these (the user disliked them):\n").append(bad.joinToString("\n---\n"))
        if (chat.msgs.isNotEmpty()) {
            sb.append("\n\nEarlier in this conversation:\n")
            chat.msgs.takeLast(8).forEach {
                sb.append(if (it.role == "user") "User: " else "Assistant: ").append(it.text.take(400)).append('\n')
            }
        }
        return sb.toString()
    }

    private fun send(preset: String?) {
        val t = (preset ?: b.input.text.toString()).trim()
        if (t.isEmpty()) return
        if (!ready) { toast(if (b.loading.visibility == View.VISIBLE) "Model is still loading..." else "Select a model first"); return }
        if (gen?.isActive == true) return
        b.input.setText("")
        chat.msgs.add(Msg("user", t))
        if (chat.title == "New chat") { chat.title = t.take(40); b.title.text = chat.title }
        adapter.notifyItemInserted(chat.msgs.lastIndex)
        generate(t)
    }

    private fun generate(prompt: String) {
        adapter.thinking = true
        adapter.notifyItemInserted(chat.msgs.size)
        refreshHero(); scrollBottom(); setBusy(true)
        gen = lifecycleScope.launch {
            var ai: Msg? = null
            val sb = StringBuilder()
            var last = 0L
            try {
                Engine.send(this@ChatActivity, prompt, Store.maxTokens).collect { tok ->
                    val m = ai ?: Msg("ai", "").also {
                        ai = it
                        adapter.thinking = false
                        adapter.streaming = true
                        chat.msgs.add(it)
                        adapter.notifyDataSetChanged()
                    }
                    sb.append(tok)
                    m.text = sb.toString()
                    val now = SystemClock.uptimeMillis()
                    if (now - last > 80) {
                        last = now
                        adapter.notifyItemChanged(chat.msgs.lastIndex)
                        scrollBottom()
                    }
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Throwable) {
                toast("Error: " + (e.message ?: "generation failed"))
            } finally {
                ai?.text = sb.toString()
                adapter.thinking = false
                adapter.streaming = false
                adapter.notifyDataSetChanged()
                setBusy(false)
                ChatRepo.save(chat)
                scrollBottom()
            }
        }
    }

    private fun setBusy(busy: Boolean) {
        b.send.setImageResource(if (busy) R.drawable.ic_stop else R.drawable.ic_send)
    }

    private fun copy(m: Msg) {
        (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager)
            .setPrimaryClip(ClipData.newPlainText("Vethos", m.text))
        toast("Copied")
    }

    private fun feedback(pos: Int, v: Int) {
        val m = chat.msgs.getOrNull(pos) ?: return
        m.fb = if (m.fb == v) 0 else v
        if (m.fb != 0) {
            val q = chat.msgs.take(pos).lastOrNull { it.role == "user" }?.text ?: ""
            Store.addSteer(if (v > 0) "best" else "bad", "Q: " + q.take(200) + "\nA: " + m.text.take(300))
            toast(if (v > 0) "Saved as a good answer" else "Saved as a bad answer")
        }
        adapter.notifyItemChanged(pos)
        ChatRepo.save(chat)
    }

    override fun onStop() {
        super.onStop()
        if (chat.msgs.isNotEmpty()) ChatRepo.save(chat)
    }
}
