package com.vethos.app.ui

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import androidx.fragment.app.Fragment
import com.vethos.app.data.ChatRepo
import com.vethos.app.data.Store
import com.vethos.app.databinding.FragmentInsightsBinding
import com.vethos.app.databinding.ItemStatBinding

class InsightsFragment : Fragment() {
    private var _b: FragmentInsightsBinding? = null
    private val b get() = _b!!

    override fun onCreateView(i: LayoutInflater, c: ViewGroup?, s: Bundle?): View =
        FragmentInsightsBinding.inflate(i, c, false).also { _b = it }.root

    override fun onResume() {
        super.onResume()
        b.row1.removeAllViews(); b.row2.removeAllViews()
        val chats = ChatRepo.all().filter { it.msgs.isNotEmpty() }
        val msgs = chats.sumOf { it.msgs.size }
        val aiChars = chats.sumOf { c -> c.msgs.filter { it.role == "ai" }.sumOf { it.text.length } }
        val models = Store.models()
        stat(b.row1, chats.size.toString(), "Chats", false)
        stat(b.row1, msgs.toString(), "Messages", true)
        stat(b.row2, "~" + (aiChars / 4).toString(), "Tokens generated", false)
        stat(b.row2, fmtSize(models.sumOf { it.length() }), "Storage - " + models.size + " model(s)", true)
    }

    private fun stat(parent: LinearLayout, value: String, label: String, second: Boolean) {
        val s = ItemStatBinding.inflate(layoutInflater, parent, false)
        s.value.text = value
        s.label.text = label
        (s.root.layoutParams as LinearLayout.LayoutParams).apply {
            if (second) marginStart = requireContext().dp(6) else marginEnd = requireContext().dp(6)
        }
        parent.addView(s.root)
    }

    override fun onDestroyView() { super.onDestroyView(); _b = null }
}
