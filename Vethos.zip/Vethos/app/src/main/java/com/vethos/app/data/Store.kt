package com.vethos.app.data

import android.content.Context
import org.json.JSONArray
import java.io.File

object Store {
    lateinit var app: Context
    fun init(c: Context) { app = c.applicationContext }

    private val prefs get() = app.getSharedPreferences("vethos", 0)

    val modelsDir: File get() = File(app.filesDir, "models").apply { mkdirs() }
    fun models(): List<File> =
        modelsDir.listFiles { f -> f.isFile && f.name.endsWith(".gguf") }?.sortedBy { it.name } ?: emptyList()

    var lastModel: String?
        get() = prefs.getString("lastModel", null)
        set(v) = prefs.edit().putString("lastModel", v).apply()

    var maxTokens: Int
        get() = prefs.getInt("maxTokens", 512)
        set(v) = prefs.edit().putInt("maxTokens", v).apply()

    var systemPrompt: String
        get() = prefs.getString("system", "You are Vethos, a helpful, concise assistant running offline on the user's phone.")!!
        set(v) = prefs.edit().putString("system", v).apply()

    /** 0 = system, 1 = light, 2 = dark */
    var theme: Int
        get() = prefs.getInt("theme", 0)
        set(v) = prefs.edit().putInt("theme", v).apply()

    var hfToken: String
        get() = prefs.getString("hfToken", "")!!
        set(v) = prefs.edit().putString("hfToken", v.trim()).apply()

    // Best / Bad answer examples (max 3 each) that steer future chats
    fun steer(kind: String): List<String> {
        val a = JSONArray(prefs.getString("steer_$kind", "[]"))
        return List(a.length()) { a.getString(it) }
    }
    fun addSteer(kind: String, text: String) {
        val l = (steer(kind) + text).takeLast(3)
        prefs.edit().putString("steer_$kind", JSONArray(l).toString()).apply()
    }
    fun clearSteer() = prefs.edit().remove("steer_best").remove("steer_bad").apply()
}
