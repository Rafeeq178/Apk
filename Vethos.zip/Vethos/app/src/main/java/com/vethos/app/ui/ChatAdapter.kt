package com.vethos.app.ui

import android.content.res.ColorStateList
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.vethos.app.R
import com.vethos.app.data.Msg
import com.vethos.app.databinding.ItemChatAiBinding
import com.vethos.app.databinding.ItemChatThinkingBinding
import com.vethos.app.databinding.ItemChatUserBinding

class ChatAdapter(
    private val msgs: MutableList<Msg>,
    private val onCopy: (Msg) -> Unit,
    private val onFeedback: (Int, Int) -> Unit,
) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    var thinking = false
    var streaming = false

    override fun getItemCount() = msgs.size + if (thinking) 1 else 0

    override fun getItemViewType(p: Int) = when {
        p >= msgs.size -> 2
        msgs[p].role == "user" -> 0
        else -> 1
    }

    private class UserVH(val b: ItemChatUserBinding) : RecyclerView.ViewHolder(b.root)
    private class AiVH(val b: ItemChatAiBinding) : RecyclerView.ViewHolder(b.root)
    private class ThinkVH(val tv: TextView) : RecyclerView.ViewHolder(tv) {
        private var n = 0
        private val tick = object : Runnable {
            override fun run() {
                n = (n + 1) % 4
                tv.text = "Thinking" + ".".repeat(n)
                tv.postDelayed(this, 400)
            }
        }
        init {
            tv.addOnAttachStateChangeListener(object : View.OnAttachStateChangeListener {
                override fun onViewAttachedToWindow(v: View) { tv.postDelayed(tick, 400) }
                override fun onViewDetachedFromWindow(v: View) { tv.removeCallbacks(tick) }
            })
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, type: Int): RecyclerView.ViewHolder {
        val inf = LayoutInflater.from(parent.context)
        return when (type) {
            0 -> UserVH(ItemChatUserBinding.inflate(inf, parent, false))
            1 -> AiVH(ItemChatAiBinding.inflate(inf, parent, false))
            else -> ThinkVH(ItemChatThinkingBinding.inflate(inf, parent, false).root as TextView)
        }
    }

    override fun onBindViewHolder(h: RecyclerView.ViewHolder, p: Int) {
        when (h) {
            is UserVH -> h.b.text.text = msgs[p].text
            is AiVH -> {
                val m = msgs[p]
                val ctx = h.itemView.context
                h.b.text.text = m.text
                h.b.actions.visibility = if (streaming && p == msgs.lastIndex) View.GONE else View.VISIBLE
                val off = ColorStateList.valueOf(ctx.getColor(R.color.v_muted))
                val on = ColorStateList.valueOf(ctx.getColor(R.color.v_blue))
                h.b.up.imageTintList = if (m.fb == 1) on else off
                h.b.down.imageTintList = if (m.fb == -1) on else off
                h.b.copy.setOnClickListener { onCopy(m) }
                h.b.up.setOnClickListener { val i = h.bindingAdapterPosition; if (i >= 0) onFeedback(i, 1) }
                h.b.down.setOnClickListener { val i = h.bindingAdapterPosition; if (i >= 0) onFeedback(i, -1) }
            }
            else -> Unit
        }
    }
}
