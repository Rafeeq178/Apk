package com.vethos.app.data

import android.content.Context
import com.arm.aichat.AiChat
import com.arm.aichat.InferenceEngine
import kotlinx.coroutines.flow.Flow

/**
 * Thin wrapper over llama.cpp's Android AI-chat library (com.arm.aichat).
 * If the upstream API changes, this is the only file that needs editing.
 */
object Engine {
    private var engine: InferenceEngine? = null
    var loadedPath: String? = null
        private set
    var chatId: String? = null
        private set

    private fun get(ctx: Context): InferenceEngine =
        engine ?: AiChat.getInferenceEngine(ctx.applicationContext).also { engine = it }

    /** Loads the model and system prompt. A chat only needs a fresh load when the model or chat changed. */
    suspend fun load(ctx: Context, path: String, chat: String, system: String) {
        val e = get(ctx)
        if (loadedPath == path && chatId == chat) return
        if (loadedPath != null) {
            try { e.cleanUp() } catch (_: Throwable) { }
            loadedPath = null; chatId = null
        }
        e.loadModel(path)
        e.setSystemPrompt(system)
        loadedPath = path
        chatId = chat
    }

    fun send(ctx: Context, prompt: String, maxTokens: Int): Flow<String> =
        get(ctx).sendUserPrompt(prompt, maxTokens)

    /** Forget the loaded model (e.g. user deleted it or switched model). */
    fun unload() {
        try { engine?.cleanUp() } catch (_: Throwable) { }
        loadedPath = null; chatId = null
    }
}
