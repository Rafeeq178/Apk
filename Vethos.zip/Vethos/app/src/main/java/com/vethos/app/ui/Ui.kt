package com.vethos.app.ui

import android.content.Context
import android.text.format.DateFormat
import android.view.ViewGroup
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.Toast
import com.google.android.material.dialog.MaterialAlertDialogBuilder

fun Context.dp(v: Int) = (v * resources.displayMetrics.density).toInt()
fun Context.toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

fun fmtSize(b: Long): String =
    if (b >= (1L shl 30)) "%.2f GB".format(b / 1073741824.0) else "%d MB".format(b / 1048576)

fun fmtDate(ts: Long): String = DateFormat.format("d MMM, h:mm a", ts).toString()

fun Context.confirm(title: String, msg: String, ok: String, onOk: () -> Unit) {
    MaterialAlertDialogBuilder(this).setTitle(title).setMessage(msg)
        .setNegativeButton("Cancel", null).setPositiveButton(ok) { _, _ -> onOk() }.show()
}

fun Context.inputDialog(title: String, initial: String, hint: String, multiline: Boolean = false, onOk: (String) -> Unit) {
    val et = EditText(this).apply {
        setText(initial); setHint(hint); setSelection(initial.length)
        if (multiline) { minLines = 4; maxLines = 8; gravity = android.view.Gravity.TOP }
    }
    val box = FrameLayout(this).apply {
        setPadding(dp(22), dp(8), dp(22), 0)
        addView(et, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
    }
    MaterialAlertDialogBuilder(this).setTitle(title).setView(box)
        .setNegativeButton("Cancel", null).setPositiveButton("Save") { _, _ -> onOk(et.text.toString()) }.show()
}

fun Context.choose(title: String, items: List<String>, checked: Int, onPick: (Int) -> Unit) {
    MaterialAlertDialogBuilder(this).setTitle(title)
        .setSingleChoiceItems(items.toTypedArray(), checked) { d, i -> onPick(i); d.dismiss() }
        .setNegativeButton("Cancel", null).show()
}
