VETHOS - native Android app (Kotlin, no WebView, no ads)

Termux build:
  1. pkg install git openjdk-17 gradle   (plus Android SDK + NDK + cmake)
  2. ./setup.sh          # clones llama.cpp and prepares its Android lib
  3. gradle assembleRelease
  APK: app/build/outputs/apk/release/

Needs Android 13+ (API 33), arm64 phone.
