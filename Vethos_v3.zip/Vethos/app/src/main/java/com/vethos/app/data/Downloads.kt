package com.vethos.app.data

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLDecoder

/** state: 0 running, 1 failed/paused (resumable), 2 done */
data class Dl(val name: String, val done: Long, val total: Long, val state: Int, val err: String = "")

object Downloads {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val jobs = HashMap<String, Job>()
    val state = MutableStateFlow<Map<String, Dl>>(emptyMap())
    val urls = HashMap<String, String>()

    /** Foreground service = download keeps running in the background + progress notification. */
    private fun ensureService() {
        try {
            androidx.core.content.ContextCompat.startForegroundService(
                Store.app, android.content.Intent(Store.app, DownloadService::class.java)
            )
        } catch (_: Throwable) { }
    }

    private fun put(d: Dl) { state.value = state.value + (d.name to d) }
    private fun drop(name: String) { state.value = state.value - name }

    /** Accepts a HuggingFace file URL (resolve or blob). Returns the target file name, or null if invalid. */
    fun fileNameFor(url: String): String? {
        val clean = url.trim().substringBefore('?')
        if (!clean.startsWith("http")) return null
        val n = URLDecoder.decode(clean.substringAfterLast('/'), "UTF-8")
        return if (n.endsWith(".gguf", true)) n else null
    }

    fun normalize(url: String) = url.trim().replace("/blob/", "/resolve/")

    fun start(rawUrl: String, name: String) {
        if (jobs[name]?.isActive == true) return
        val url = normalize(rawUrl)
        urls[name] = url
        if (state.value[name]?.state != 0) put(Dl(name, 0, -1, 0))
        ensureService()
        jobs[name] = scope.launch {
            val dest = File(Store.modelsDir, name)
            val part = File(Store.modelsDir, "$name.part")
            try {
                var have = if (part.exists()) part.length() else 0L
                put(Dl(name, have, -1, 0))
                var u = url
                var conn: HttpURLConnection? = null
                var hops = 0
                while (conn == null && hops < 6) {
                    hops++
                    val c = URL(u).openConnection() as HttpURLConnection
                    c.instanceFollowRedirects = false
                    c.connectTimeout = 20000; c.readTimeout = 30000
                    c.setRequestProperty("User-Agent", "Vethos/1.0")
                    if (have > 0) c.setRequestProperty("Range", "bytes=$have-")
                    val tok = Store.hfToken
                    if (tok.isNotBlank() && URL(u).host.endsWith("huggingface.co"))
                        c.setRequestProperty("Authorization", "Bearer $tok")
                    val code = c.responseCode
                    if (code in 300..399) {
                        u = URL(URL(u), c.getHeaderField("Location")).toString()
                        c.disconnect()
                    } else conn = c
                }
                val c = conn ?: error("Too many redirects")
                val code = c.responseCode
                if (code == 416 && have > 0) { finish(part, dest, name); return@launch }
                if (code != 200 && code != 206) {
                    error("HTTP $code" + if (code == 401 || code == 403) " - this model needs a Hugging Face token (Settings)" else "")
                }
                if (code == 200 && have > 0) { have = 0; part.delete() }
                val len = c.contentLengthLong
                val total = if (len > 0) have + len else -1L
                var done = have
                var lastUi = 0L
                c.inputStream.use { ins ->
                    FileOutputStream(part, have > 0).use { out ->
                        val buf = ByteArray(256 * 1024)
                        while (true) {
                            ensureActive()
                            val n = ins.read(buf)
                            if (n < 0) break
                            out.write(buf, 0, n)
                            done += n
                            val now = System.currentTimeMillis()
                            if (now - lastUi > 300) { lastUi = now; put(Dl(name, done, total, 0)) }
                        }
                    }
                }
                finish(part, dest, name)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                put(Dl(name, if (part.exists()) part.length() else 0, -1, 1, e.message ?: "Download failed"))
            }
        }
    }

    private fun finish(part: File, dest: File, name: String) {
        if (!isGguf(part)) {
            part.delete()
            put(Dl(name, 0, -1, 1, "Not a valid .gguf file"))
            return
        }
        dest.delete()
        part.renameTo(dest)
        put(Dl(name, dest.length(), dest.length(), 2))
    }

    /** Stop. If delete = true also remove the partial file. */
    fun cancel(name: String, delete: Boolean) {
        jobs[name]?.cancel()
        if (delete) File(Store.modelsDir, "$name.part").delete()
        drop(name)
    }

    fun clearFinished(name: String) = drop(name)

    /** Stop but keep the partial file so it can be resumed. */
    fun pause(name: String) {
        jobs[name]?.cancel()
        val part = File(Store.modelsDir, "$name.part")
        put(Dl(name, if (part.exists()) part.length() else 0, state.value[name]?.total ?: -1, 1, "Paused"))
    }

    /** Import a .gguf picked from phone storage (progress shown like a download). */
    fun importFrom(ctx: Context, uri: Uri) {
        val resolver = ctx.applicationContext.contentResolver
        var name = "model.gguf"
        resolver.query(uri, null, null, null, null)?.use {
            if (it.moveToFirst()) {
                val i = it.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (i >= 0) name = it.getString(i)
            }
        }
        if (!name.endsWith(".gguf", true)) {
            put(Dl(name, 0, -1, 1, "Pick a .gguf model file")); return
        }
        val n = name
        put(Dl(n, 0, -1, 0))
        ensureService()
        jobs[n] = scope.launch {
            val part = File(Store.modelsDir, "$n.part")
            try {
                val total = resolver.openFileDescriptor(uri, "r")?.use { it.statSize } ?: -1L
                put(Dl(n, 0, total, 0))
                var done = 0L; var lastUi = 0L
                resolver.openInputStream(uri)!!.use { ins ->
                    FileOutputStream(part).use { out ->
                        val buf = ByteArray(256 * 1024)
                        while (true) {
                            ensureActive()
                            val r = ins.read(buf)
                            if (r < 0) break
                            out.write(buf, 0, r); done += r
                            val now = System.currentTimeMillis()
                            if (now - lastUi > 300) { lastUi = now; put(Dl(n, done, total, 0)) }
                        }
                    }
                }
                finish(part, File(Store.modelsDir, n), n)
            } catch (e: CancellationException) {
                part.delete(); throw e
            } catch (e: Exception) {
                part.delete(); put(Dl(n, 0, -1, 1, e.message ?: "Import failed"))
            }
        }
    }

    private fun isGguf(f: File): Boolean = try {
        f.inputStream().use { val b = ByteArray(4); it.read(b) == 4 && String(b) == "GGUF" }
    } catch (_: Exception) { false }
}
