package com.vethos.app.ui

import android.animation.ObjectAnimator
import android.content.res.ColorStateList
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.vethos.app.R
import com.vethos.app.data.Msg
import com.vethos.app.databinding.ItemChatAiBinding
import com.vethos.app.databinding.ItemChatThinkingBinding
import com.vethos.app.databinding.ItemChatUserBinding

class ChatAdapter(
    private val msgs: MutableList<Msg>,
    private val onCopy: (Msg) -> Unit,
    private val onFeedback: (Int, Int) -> Unit,
    private val onShare: (Msg) -> Unit,
    private val onRegen: () -> Unit,
) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    var thinking = false
    var streaming = false

    /** Raw text (and blink state) of the message that is being typed (animated by ChatActivity). */
    private var liveRaw: String? = null
    private var liveOn = true

    override fun getItemCount() = msgs.size + if (thinking) 1 else 0

    override fun getItemViewType(p: Int) = when {
        p >= msgs.size -> 2
        msgs[p].role == "user" -> 0
        else -> 1
    }

    class UserVH(val b: ItemChatUserBinding) : RecyclerView.ViewHolder(b.root)
    class AiVH(val b: ItemChatAiBinding) : RecyclerView.ViewHolder(b.root)
    class ThinkVH(val tv: TextView) : RecyclerView.ViewHolder(tv.parent as View) {
        private var anim: ObjectAnimator? = null
        init {
            tv.addOnAttachStateChangeListener(object : View.OnAttachStateChangeListener {
                override fun onViewAttachedToWindow(v: View) {
                    anim?.cancel()
                    anim = ObjectAnimator.ofFloat(tv, View.ALPHA, 1f, 0.25f).apply {
                        duration = 550
                        repeatMode = ObjectAnimator.REVERSE
                        repeatCount = ObjectAnimator.INFINITE
                        start()
                    }
                }
                override fun onViewDetachedFromWindow(v: View) { anim?.cancel(); tv.alpha = 1f }
            })
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, type: Int): RecyclerView.ViewHolder {
        val inf = LayoutInflater.from(parent.context)
        return when (type) {
            0 -> UserVH(ItemChatUserBinding.inflate(inf, parent, false))
            1 -> AiVH(ItemChatAiBinding.inflate(inf, parent, false))
            else -> ThinkVH(ItemChatThinkingBinding.inflate(inf, parent, false).dots)
        }
    }

    override fun onBindViewHolder(h: RecyclerView.ViewHolder, p: Int) {
        when (h) {
            is UserVH -> h.b.text.text = Attach.display(msgs[p].text)
            is AiVH -> {
                val m = msgs[p]
                val ctx = h.itemView.context
                val live = streaming && p == msgs.lastIndex
                if (live) Blocks.bind(h.b.content, liveRaw ?: "", liveOn) else Blocks.bind(h.b.content, m.text, null)
                h.b.actions.visibility = if (live) View.GONE else View.VISIBLE
                h.b.regen.visibility = if (p == msgs.lastIndex) View.VISIBLE else View.GONE
                val off = ColorStateList.valueOf(ctx.getColor(R.color.v_muted))
                val on = ColorStateList.valueOf(ctx.getColor(R.color.v_blue))
                h.b.up.imageTintList = if (m.fb == 1) on else off
                h.b.down.imageTintList = if (m.fb == -1) on else off
                h.b.copy.setOnClickListener { onCopy(m) }
                h.b.share.setOnClickListener { onShare(m) }
                h.b.regen.setOnClickListener { onRegen() }
                h.b.up.setOnClickListener { val i = h.bindingAdapterPosition; if (i >= 0) onFeedback(i, 1) }
                h.b.down.setOnClickListener { val i = h.bindingAdapterPosition; if (i >= 0) onFeedback(i, -1) }
            }
            else -> Unit
        }
    }

    /** Pushes the next animation frame of the streaming message straight into its view. */
    fun updateLive(rv: RecyclerView, raw: String, on: Boolean) {
        liveRaw = raw
        liveOn = on
        val h = rv.findViewHolderForAdapterPosition(msgs.lastIndex) as? AiVH ?: return
        Blocks.bind(h.b.content, raw, on)
    }

    fun endLive() { liveRaw = null }
}
