package com.vethos.app.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.SystemClock
import android.speech.RecognizerIntent
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.vethos.app.R
import com.vethos.app.data.Chat
import com.vethos.app.data.ChatRepo
import com.vethos.app.data.Engine
import com.vethos.app.data.Msg
import com.vethos.app.data.Persona
import com.vethos.app.data.Personas
import com.vethos.app.data.Store
import com.vethos.app.databinding.ActivityChatBinding
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.UUID

class ChatActivity : AppCompatActivity() {
    private lateinit var b: ActivityChatBinding
    private lateinit var chat: Chat
    private lateinit var persona: Persona
    private lateinit var adapter: ChatAdapter
    private var gen: Job? = null
    private var typer: Job? = null
    private var ready = false
    private var pendingSend: String? = null
    private var attached: Attach.Picked? = null

    // live typing state
    private val target = StringBuilder()
    private var shown = 0
    private var generating = false
    private var autoFollow = true

    private val speech = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val t = r.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
        if (r.resultCode == RESULT_OK && !t.isNullOrBlank()) {
            b.input.setText(t); b.input.setSelection(t.length)
        }
    }

    private val pickFile = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) attachFile(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityChatBinding.inflate(layoutInflater)
        setContentView(b.root)

        val existing = ChatRepo.get(intent.getStringExtra("id"))
        chat = existing ?: Chat(UUID.randomUUID().toString(), "New chat", System.currentTimeMillis(), mutableListOf())
        persona = if (existing != null) {
            Personas.get(existing.persona) ?: Personas.current()
        } else {
            Personas.get(intent.getStringExtra("persona")) ?: Personas.current()
        }
        chat.persona = persona.id
        if (existing == null) Personas.selectedId = persona.id

        adapter = ChatAdapter(chat.msgs, ::copy, ::feedback, ::share) { regenerate() }
        val lm = LinearLayoutManager(this)
        b.rv.layoutManager = lm
        b.rv.adapter = adapter
        b.rv.itemAnimator = null
        b.rv.addOnScrollListener(object : RecyclerView.OnScrollListener() {
            override fun onScrollStateChanged(rv: RecyclerView, state: Int) {
                if (state == RecyclerView.SCROLL_STATE_DRAGGING) autoFollow = false
                else if (state == RecyclerView.SCROLL_STATE_IDLE && !rv.canScrollVertically(1)) autoFollow = true
            }
        })
        applyPersona()

        b.btnBack.setOnClickListener { finish() }
        b.btnHistory.setOnClickListener { startActivity(Intent(this, HistoryActivity::class.java)) }
        b.btnMore.setOnClickListener { showOptions() }
        b.btnAttach.setOnClickListener { pickFile.launch(arrayOf("*/*")) }
        b.attachClose.setOnClickListener { attached = null; b.attachBar.visibility = View.GONE }
        b.btnMic.setOnClickListener { listen() }
        b.send.setOnClickListener { if (gen?.isActive == true) gen?.cancel() else send(null) }

        val preset = intent.getStringExtra("preset")?.takeIf { it.isNotEmpty() }
        if (preset != null) {
            if (intent.getBooleanExtra("autosend", false)) pendingSend = preset
            else { b.input.setText(preset); b.input.setSelection(preset.length) }
        }

        listOf("Help me plan my day", "Explain inflation in simple words", "Give me 5 ideas for a small online business")
            .forEach { q ->
                b.sugs.addView(TextView(this).apply {
                    text = q
                    setBackgroundResource(R.drawable.bg_chip_sug)
                    setTextColor(getColor(R.color.v_text))
                    textSize = 15f
                    elevation = dp(1).toFloat()
                    setPadding(dp(18), dp(12), dp(18), dp(12))
                    setOnClickListener { send(q) }
                }, LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(12) })
            }

        refreshHero()
        scrollBottom()
        loadModel()
    }

    private fun applyPersona() {
        b.title.text = persona.name
        b.heroTitle.text = persona.name
        b.heroSub.text = persona.desc
        val ic = Personas.icons[persona.ico.coerceIn(0, Personas.icons.lastIndex)]
        b.heroIcon.setImageResource(ic.res)
    }

    private fun refreshHero() {
        val empty = chat.msgs.isEmpty() && !adapter.thinking
        b.hero.visibility = if (empty) View.VISIBLE else View.GONE
        b.rv.visibility = if (empty) View.INVISIBLE else View.VISIBLE
    }

    private fun scrollBottom() = b.rv.post {
        if (adapter.itemCount > 0) b.rv.scrollToPosition(adapter.itemCount - 1)
    }

    private fun showBanner(text: String, onClick: (() -> Unit)?) {
        b.banner.text = text
        b.banner.visibility = View.VISIBLE
        b.banner.setOnClickListener { onClick?.invoke() }
    }

    private fun modelFile(): File? = Store.lastModel?.let { File(Store.modelsDir, it) }?.takeIf { it.exists() }

    private fun loadModel(force: Boolean = false, history: List<Msg> = chat.msgs) {
        val f = modelFile()
        if (f == null) {
            b.sub.text = "No model"
            showBanner("No model yet. Tap here to open the Library.") {
                startActivity(
                    Intent(this, MainActivity::class.java).putExtra("tab", 1)
                        .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                )
                finish()
            }
            return
        }
        b.sub.text = f.name.removeSuffix(".gguf")
        b.banner.visibility = View.GONE
        b.loading.visibility = View.VISIBLE
        ready = false
        val system = buildSystem(history)
        lifecycleScope.launch {
            try {
                withContext(Dispatchers.Default) { Engine.load(this@ChatActivity, f.absolutePath, chat.id, system, force) }
                ready = true
                pendingSend?.let { pendingSend = null; send(it) }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Throwable) {
                showBanner("Could not load this model: " + (e.message ?: "unknown error"), null)
            } finally {
                b.loading.visibility = View.GONE
            }
        }
    }

    private fun buildSystem(history: List<Msg>): String {
        val sb = StringBuilder(persona.prompt.ifBlank { Store.systemPrompt })
        val best = Store.steer("best")
        if (best.isNotEmpty()) sb.append("\n\nExamples of answers the user liked:\n").append(best.joinToString("\n---\n"))
        val bad = Store.steer("bad")
        if (bad.isNotEmpty()) sb.append("\n\nAvoid answers like these (the user disliked them):\n").append(bad.joinToString("\n---\n"))
        val mem = Store.memory
        if (history.isNotEmpty() && mem > 0) {
            sb.append("\n\nEarlier in this conversation:\n")
            history.takeLast(mem).forEach {
                sb.append(if (it.role == "user") "User: " else "Assistant: ").append(Attach.display(it.text).take(400)).append('\n')
            }
        }
        return sb.toString()
    }

    private fun listen() {
        try {
            speech.launch(
                Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                    .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    .putExtra(RecognizerIntent.EXTRA_LANGUAGE, Store.voiceLang)
            )
        } catch (e: Exception) {
            toast("Voice input isn't available on this phone")
        }
    }

    private fun attachFile(uri: android.net.Uri) {
        lifecycleScope.launch {
            try {
                val p = withContext(Dispatchers.IO) { Attach.read(this@ChatActivity, uri) }
                attached = p
                b.attachName.text = p.name + if (p.truncated) "  (first ${Attach.MAX_CHARS} characters used)" else ""
                b.attachBar.visibility = View.VISIBLE
            } catch (e: CancellationException) {
                throw e
            } catch (e: Throwable) {
                toast(e.message ?: "Could not read this file")
            }
        }
    }

    private fun send(preset: String?) {
        val q = (preset ?: b.input.text.toString()).trim()
        val file = attached
        if (q.isEmpty() && file == null) return
        if (!ready) {
            if (b.loading.visibility == View.VISIBLE) { pendingSend = q; b.input.setText("") }
            else toast("Select a model first")
            return
        }
        if (gen?.isActive == true) return
        b.input.setText("")
        val prompt = if (file != null) Attach.wrap(file, q) else q
        attached = null
        b.attachBar.visibility = View.GONE
        chat.msgs.add(Msg("user", prompt))
        if (chat.title == "New chat") chat.title = (if (q.isNotEmpty()) q else "File: " + file?.name).take(40)
        adapter.notifyItemInserted(chat.msgs.lastIndex)
        generate(prompt)
    }

    private fun generate(prompt: String) {
        adapter.thinking = true
        adapter.notifyItemInserted(chat.msgs.size)
        refreshHero(); scrollBottom(); setBusy(true)
        autoFollow = true
        target.setLength(0); shown = 0; generating = true
        val t0 = SystemClock.uptimeMillis()
        gen = lifecycleScope.launch {
            var ai: Msg? = null
            var tFirst = 0L
            var cancelled = false
            try {
                Engine.send(this@ChatActivity, prompt, Store.maxTokens).collect { tok ->
                    if (ai == null) {
                        tFirst = SystemClock.uptimeMillis()
                        Store.lastFirst = (tFirst - t0) / 1000f
                        val m = Msg("ai", "")
                        ai = m
                        adapter.thinking = false
                        adapter.streaming = true
                        chat.msgs.add(m)
                        adapter.notifyDataSetChanged()
                        startTyper()
                    }
                    target.append(tok)
                    ai!!.text = target.toString()
                }
                generating = false
                typer?.join() // let the typing animation finish
            } catch (e: CancellationException) {
                cancelled = true
                throw e
            } catch (e: Throwable) {
                toast("Error: " + (e.message ?: "generation failed"))
            } finally {
                generating = false
                typer?.cancel()
                ai?.text = target.toString()
                if (!cancelled && ai != null && tFirst > 0) {
                    val secs = (SystemClock.uptimeMillis() - tFirst) / 1000f
                    if (secs > 0.3f) Store.lastTps = (target.length / 4f) / secs
                }
                adapter.thinking = false
                adapter.streaming = false
                adapter.endLive()
                adapter.notifyDataSetChanged()
                setBusy(false)
                refreshHero()
                if (Store.keepHistory) ChatRepo.save(chat)
                scrollBottom()
            }
        }
    }

    /** Reveals the received text a few characters per frame, with a blinking dot at the end. */
    private fun startTyper() {
        typer?.cancel()
        typer = lifecycleScope.launch {
            var lastShown = -1
            var lastOn = true
            while (true) {
                delay(22)
                val backlog = target.length - shown
                if (backlog > 0) shown += minOf(backlog, 1 + backlog / 10)
                if (!generating && shown >= target.length) break
                val on = shown < target.length || (SystemClock.uptimeMillis() / 450) % 2 == 0L
                if (shown != lastShown || on != lastOn) {
                    lastShown = shown; lastOn = on
                    adapter.updateLive(b.rv, target.substring(0, shown), on)
                    if (autoFollow && b.rv.canScrollVertically(1)) b.rv.scrollBy(0, 400)
                }
            }
        }
    }

    private fun setBusy(busy: Boolean) {
        b.send.setImageResource(if (busy) R.drawable.ic_stop else R.drawable.ic_send)
    }

    private fun copy(m: Msg) {
        (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager)
            .setPrimaryClip(ClipData.newPlainText("Vethos", m.text))
        toast("Copied")
    }

    private fun share(m: Msg) = shareText(m.text)

    private fun shareText(text: String) {
        startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, text), "Share"))
    }

    private fun feedback(pos: Int, v: Int) {
        val m = chat.msgs.getOrNull(pos) ?: return
        m.fb = if (m.fb == v) 0 else v
        if (m.fb != 0) {
            val q = chat.msgs.take(pos).lastOrNull { it.role == "user" }?.text ?: ""
            Store.addSteer(if (v > 0) "best" else "bad", "Q: " + q.take(200) + "\nA: " + m.text.take(300))
            toast(if (v > 0) "Saved as a good answer" else "Saved as a bad answer")
        }
        adapter.notifyItemChanged(pos)
        if (Store.keepHistory) ChatRepo.save(chat)
    }

    private fun regenerate() {
        if (gen?.isActive == true || !ready) return
        val lastAi = chat.msgs.lastOrNull() ?: return
        if (lastAi.role != "ai") return
        val userIdx = chat.msgs.indexOfLast { it.role == "user" }
        if (userIdx < 0) return
        val prompt = chat.msgs[userIdx].text
        chat.msgs.removeAt(chat.msgs.lastIndex)
        adapter.notifyDataSetChanged()
        // The engine remembers the old answer, so reload it with the history before the last question.
        val history = chat.msgs.take(userIdx)
        val f = modelFile() ?: return
        b.loading.visibility = View.VISIBLE
        ready = false
        val system = buildSystem(history)
        lifecycleScope.launch {
            try {
                withContext(Dispatchers.Default) { Engine.load(this@ChatActivity, f.absolutePath, chat.id, system, true) }
                ready = true
                b.loading.visibility = View.GONE
                generate(prompt)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Throwable) {
                b.loading.visibility = View.GONE
                showBanner("Could not load this model: " + (e.message ?: "unknown error"), null)
            }
        }
    }

    private fun showOptions() {
        showSheet("Options", listOf(
            SheetRow(R.drawable.ic_plus, "New chat") {
                gen?.cancel()
                startActivity(Intent(this, ChatActivity::class.java))
                finish()
            },
            SheetRow(R.drawable.ic_chat, "Change personality") { showPersonas() },
            SheetRow(R.drawable.ic_share, "Export chat as text") { exportChat() },
            SheetRow(R.drawable.ic_trash, "Clear conversation") {
                confirm("Clear conversation?", "All messages in this chat will be removed.", "Clear") { clearChat() }
            },
        ))
    }

    private fun showPersonas() {
        showSheet("Personality", Personas.all().map { p ->
            SheetRow(Personas.icons[p.ico.coerceIn(0, Personas.icons.lastIndex)].res, p.name, p.desc, p.id == persona.id) {
                if (p.id != persona.id) {
                    gen?.cancel()
                    persona = p
                    chat.persona = p.id
                    Personas.selectedId = p.id
                    applyPersona()
                    loadModel(force = true)
                }
            }
        })
    }

    private fun exportChat() {
        if (chat.msgs.isEmpty()) { toast("Nothing to export yet"); return }
        shareText(chat.msgs.joinToString("\n\n") { (if (it.role == "user") "You: " else persona.name + ": ") + Attach.display(it.text) })
    }

    private fun clearChat() {
        gen?.cancel()
        chat.msgs.clear()
        chat.title = "New chat"
        adapter.notifyDataSetChanged()
        ChatRepo.delete(chat.id)
        refreshHero()
        loadModel(force = true, history = emptyList())
    }

    override fun onStop() {
        super.onStop()
        if (chat.msgs.isNotEmpty() && Store.keepHistory) ChatRepo.save(chat)
    }
}
