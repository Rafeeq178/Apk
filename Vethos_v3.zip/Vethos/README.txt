VETHOS - native Android app (Kotlin, no WebView, no ads)

Termux build:
  1. pkg install git openjdk-17 gradle   (plus Android SDK + NDK + cmake)
  2. ./setup.sh          # clones llama.cpp and prepares its Android lib
  3. gradle assembleRelease
  APK: app/build/outputs/apk/release/

Needs Android 10+ (API 29), arm64 phone.

v2 changes
  - Settings crash fixed: the settings layout had a view with id "root", which clashes with ViewBinding's
    .root and caused "The specified child already has a parent". It is now called "content".
  - New UI matching the reference recordings (gradient background, pill nav, side drawer, personalities,
    new Library / Insights / Settings screens).
  - Chat: live typing animation with a blinking dot, thumbs / copy / share / regenerate actions,
    options sheet, personality sheet, voice input, export chat.
  - Settings that are saved but not yet applied by the engine: Creativity, Repetition penalty, CPU threads,
    Multi-thread, GPU, Context size (llama.android's sendUserPrompt only takes the prompt and max tokens).

v3 changes
  - Code blocks: ```lang ... ``` in an answer is now drawn as a dark code block with its own "Copy" button
    (also while the answer is still typing).
  - File attach (clip button): pick any text / code file (.txt .php .js .html .json .csv .kt .py ...) or .docx.
    The first 6000 characters go to the model together with your question. PDF / images can't be read by the
    offline text model. No storage permission needed (system file picker).
  - Permissions: notifications (Android 13+, asked once with a reason) + foreground service so model
    downloads keep running in the background and show progress in the notification bar.
    Microphone: voice input uses the system speech screen, so the app itself needs no mic permission.
